<?php

function_exists('ddtrace_init') && ddtrace_init(__DIR__);
