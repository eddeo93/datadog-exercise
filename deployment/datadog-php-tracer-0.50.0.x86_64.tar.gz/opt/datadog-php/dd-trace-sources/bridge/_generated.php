<?php
namespace {
function _ddtrace_config_string($value, $default)
{
    if (false === $value || null === $value) {
        return $default;
    }
    return trim($value);
}
function _ddtrace_config_bool($value, $default)
{
    if (false === $value || null === $value) {
        return $default;
    }
    $value = strtolower($value);
    if ($value === '1' || $value === 'true') {
        return true;
    } elseif ($value === '0' || $value === 'false') {
        return false;
    } else {
        return $default;
    }
}
function _ddtrace_config_float($value, $default, $min = null, $max = null)
{
    if (false === $value || null === $value) {
        return $default;
    }
    $value = strtolower($value);
    if (is_numeric($value)) {
        $floatValue = (double) $value;
    } else {
        $floatValue = (double) $default;
    }
    if (null !== $min && $floatValue < $min) {
        $floatValue = $min;
    }
    if (null !== $max && $floatValue > $max) {
        $floatValue = $max;
    }
    return $floatValue;
}
function _ddtrace_config_json($value, $default)
{
    if (false === $value || null === $value) {
        return $default;
    }
    $parsed = \json_decode($value, true);
    if (null === $parsed) {
        return $default;
    }
    return $parsed;
}
function _ddtrace_config_indexed_array($value, $default)
{
    if (false === $value || null === $value) {
        return $default;
    }
    return array_map(function ($entry) {
        return trim($entry);
    }, explode(',', $value));
}
function _ddtrace_config_associative_array($value, $default)
{
    if (false === $value || null === $value) {
        return $default;
    }
    $result = array();
    $elements = explode(',', $value);
    foreach ($elements as $element) {
        $keyAndValue = explode(':', $element);
        if (count($keyAndValue) !== 2) {
            continue;
        }
        $keyFragment = trim($keyAndValue[0]);
        $valueFragment = trim($keyAndValue[1]);
        if (empty($keyFragment)) {
            continue;
        }
        $result[$keyFragment] = $valueFragment;
    }
    return $result;
}
function ddtrace_config_env()
{
    return \_ddtrace_config_string(\getenv('DD_ENV'), null);
}
function ddtrace_config_service_version()
{
    return \_ddtrace_config_string(\getenv('DD_VERSION'), null);
}
function ddtrace_config_debug_enabled()
{
    return \_ddtrace_config_bool(\getenv('DD_TRACE_DEBUG'), false);
}
function ddtrace_config_analytics_enabled()
{
    return \_ddtrace_config_bool(\getenv('DD_TRACE_ANALYTICS_ENABLED'), false);
}
function ddtrace_config_priority_sampling_enabled()
{
    return \ddtrace_config_distributed_tracing_enabled() && \_ddtrace_config_bool(\getenv('DD_PRIORITY_SAMPLING'), true);
}
function ddtrace_config_hostname_reporting_enabled()
{
    return \_ddtrace_config_bool(\getenv('DD_TRACE_REPORT_HOSTNAME'), false);
}
function ddtrace_config_url_resource_name_enabled()
{
    return \_ddtrace_config_bool(\getenv('DD_TRACE_URL_AS_RESOURCE_NAMES_ENABLED'), true);
}
function ddtrace_config_path_fragment_regex()
{
    return \_ddtrace_config_indexed_array(\getenv('DD_TRACE_RESOURCE_URI_FRAGMENT_REGEX'), array());
}
function ddtrace_config_path_mapping_incoming()
{
    return \_ddtrace_config_indexed_array(\getenv('DD_TRACE_RESOURCE_URI_MAPPING_INCOMING'), array());
}
function ddtrace_config_path_mapping_outgoing()
{
    return \_ddtrace_config_indexed_array(\getenv('DD_TRACE_RESOURCE_URI_MAPPING_OUTGOING'), array());
}
function ddtrace_config_http_client_split_by_domain_enabled()
{
    return \_ddtrace_config_bool(\getenv('DD_TRACE_HTTP_CLIENT_SPLIT_BY_DOMAIN'), false);
}
function ddtrace_config_autofinish_span_enabled()
{
    return \_ddtrace_config_bool(\getenv('DD_AUTOFINISH_SPANS'), false);
}
function ddtrace_config_sampling_rate()
{
    $deprecated = \_ddtrace_config_float(\getenv('DD_SAMPLING_RATE'), 1.0, 0.0, 1.0);
    return \_ddtrace_config_float(\getenv('DD_TRACE_SAMPLE_RATE'), $deprecated, 0.0, 1.0);
}
function ddtrace_config_sampling_rules()
{
    $json = \_ddtrace_config_json(\getenv('DD_TRACE_SAMPLING_RULES'), array());
    $normalized = array();
    foreach ($json as &$rule) {
        if (!is_array($rule) || !isset($rule['sample_rate'])) {
            continue;
        }
        $service = isset($rule['service']) ? strval($rule['service']) : '.*';
        $name = isset($rule['name']) ? strval($rule['name']) : '.*';
        $rate = isset($rule['sample_rate']) ? floatval($rule['sample_rate']) : 1.0;
        $normalized[] = array('service' => $service, 'name' => $name, 'sample_rate' => $rate);
    }
    return $normalized;
}
function ddtrace_config_global_tags()
{
    $rawValue = \getenv('DD_TAGS');
    if (false === $rawValue) {
        $rawValue = \getenv('DD_TRACE_GLOBAL_TAGS');
    }
    return \_ddtrace_config_associative_array($rawValue, array());
}
function ddtrace_config_service_mapping()
{
    return \_ddtrace_config_associative_array(\getenv('DD_SERVICE_MAPPING'), array());
}
}

namespace DDTrace\Private_ {
use DDTrace\Http\Urls;
class Constants
{
    public static function getDefaultUriPathNormalizeRegexes()
    {
        return array('/^\\d+$/', '/^[0-9a-f]{8}-?[0-9a-f]{4}-?[1-5][0-9a-f]{3}-?[89ab][0-9a-f]{3}-?[0-9a-f]{12}$/', '/^[0-9a-f]{8,128}$/');
    }
}
function util_uri_normalize_outgoing_path($uriPath)
{
    return _util_uri_apply_rules($uriPath, false);
}
function util_uri_normalize_incoming_path($uriPath)
{
    return _util_uri_apply_rules($uriPath, true);
}
function _util_uri_apply_rules($uriPath, $incoming)
{
    if ('/' === $uriPath || '' === $uriPath || null === $uriPath) {
        return '/';
    }
    $uriPath = strstr($uriPath, '?', true) ?: $uriPath;
    if ($uriPath[0] !== '/' && 1 !== \preg_match('/^[a-z][a-zA-Z0-9+\\-.]+:\\/\\//', $uriPath)) {
        $uriPath = '/' . $uriPath;
    }
    $fragmentRegexes = \ddtrace_config_path_fragment_regex();
    $incomingMappings = \ddtrace_config_path_mapping_incoming();
    $outgoingMappings = \ddtrace_config_path_mapping_outgoing();
    $legacyMappings = getenv('DD_TRACE_RESOURCE_URI_MAPPING');
    if (empty($fragmentRegexes) && empty($incomingMappings) && empty($outgoingMappings) && !empty($legacyMappings)) {
        $normalizer = new Urls(explode(',', $legacyMappings));
        return $normalizer->normalize($uriPath);
    }
    $result = $uriPath;
    foreach ($incoming ? $incomingMappings : $outgoingMappings as $rawMapping) {
        $normalizedMapping = trim($rawMapping);
        if ('' === $normalizedMapping) {
            continue;
        }
        $regex = '/\\/' . str_replace('*', '[^\\/?#]+', str_replace('/', '\\/', $normalizedMapping)) . '/';
        $replacement = '/' . str_replace('*', '?', $normalizedMapping);
        $result = preg_replace($regex, $replacement, $result);
    }
    $fragments = explode('/', $result);
    $defaultPlusConfiguredfragmentRegexes = array_merge(Constants::getDefaultUriPathNormalizeRegexes(), $fragmentRegexes);
    foreach ($defaultPlusConfiguredfragmentRegexes as $fragmentRegex) {
        $regexWithSlash = '/' . trim($fragmentRegex, '/ ') . '/';
        foreach ($fragments as &$fragment) {
            $matchResult = @preg_match($regexWithSlash, $fragment);
            if (1 === $matchResult) {
                $fragment = '?';
            }
        }
    }
    return implode('/', $fragments);
}
}

namespace DDTrace\Contracts {
use DDTrace\Exceptions\InvalidReferencesSet;
use DDTrace\Exceptions\InvalidSpanOption;
use DDTrace\Exceptions\UnsupportedFormat;
use DDTrace\StartSpanOptions;
interface Tracer
{
    public function limited();
    public function getScopeManager();
    public function getActiveSpan();
    public function startActiveSpan($operationName, $options = array());
    public function startSpan($operationName, $options = array());
    public function inject(SpanContext $spanContext, $format, &$carrier);
    public function extract($format, $carrier);
    public function flush();
    public function setPrioritySampling($prioritySampling);
    public function getPrioritySampling();
    public function startRootSpan($operationName, $options = array());
    public function getRootScope();
    public function getSafeRootSpan();
    public function getTracesAsArray();
    public function getTracesCount();
}
}

namespace DDTrace\Contracts {
interface Span
{
    public function getOperationName();
    public function getContext();
    public function finish($finishTime = null);
    public function overwriteOperationName($newOperationName);
    public function setResource($resource);
    public function setTag($key, $value, $setIfFinished = false);
    public function getTag($key);
    public function log(array $fields = array(), $timestamp = null);
    public function addBaggageItem($key, $value);
    public function getBaggageItem($key);
    public function getAllBaggageItems();
    public function setError($error);
    public function setRawError($message, $type);
    public function hasError();
    public function getStartTime();
    public function getDuration();
    public function getTraceId();
    public function getSpanId();
    public function getParentId();
    public function getResource();
    public function getService();
    public function getType();
    public function isFinished();
    public function getAllTags();
    public function hasTag($name);
    public function setMetric($key, $value);
    public function getMetrics();
    public function setTraceAnalyticsCandidate($value = true);
    public function isTraceAnalyticsCandidate();
}
}

namespace DDTrace\Contracts {
interface Scope
{
    public function close();
    public function getSpan();
}
}

namespace DDTrace\Contracts {
interface ScopeManager
{
    const DEFAULT_FINISH_SPAN_ON_CLOSE = true;
    public function activate(Span $span, $finishSpanOnClose = self::DEFAULT_FINISH_SPAN_ON_CLOSE);
    public function getActive();
    public function close();
}
}

namespace DDTrace\Contracts {
use IteratorAggregate;
interface SpanContext extends IteratorAggregate
{
    public function getBaggageItem($key);
    public function withBaggageItem($key, $value);
    public function getAllBaggageItems();
    public function getPropagatedPrioritySampling();
    public function setPropagatedPrioritySampling($propagatedPrioritySampling);
    public function isHostRoot();
    public function getTraceId();
    public function getSpanId();
    public function getParentId();
    public function isDistributedTracingActivationContext();
}
}

namespace DDTrace\Log {
trait LoggingTrait
{
    protected static function logDebug($message, array $context = array())
    {
        Logger::get()->debug($message, $context);
    }
    protected static function logWarning($message, array $context = array())
    {
        Logger::get()->warning($message, $context);
    }
    protected static function logError($message, array $context = array())
    {
        Logger::get()->error($message, $context);
    }
    protected static function isLogDebugActive()
    {
        return Logger::get()->isLevelActive(LogLevel::DEBUG);
    }
}
}

namespace DDTrace\Data {
use DDTrace\Contracts\SpanContext as SpanContextInterface;
abstract class SpanContext implements SpanContextInterface
{
    public $traceId;
    public $spanId;
    public $parentId;
    public $isDistributedTracingActivationContext;
    public $propagatedPrioritySampling;
    public $origin;
    public $parentContext;
    public $baggageItems;
}
}

namespace DDTrace\Data {
use DDTrace\Time;
use DDTrace\Data\SpanContext as SpanContextData;
use DDTrace\Contracts\Span as SpanInterface;
abstract class Span implements SpanInterface
{
    public $operationName;
    public $context;
    public $resource;
    public $service;
    public $type;
    public $startTime;
    public $duration;
    public $tags = array();
    public $hasError = false;
    public $metrics = array();
    public $isTraceAnalyticsCandidate = false;
}
}

namespace DDTrace\Sampling {
use DDTrace\Contracts\Span;
interface Sampler
{
    public function getPrioritySampling(Span $span);
}
}

namespace DDTrace {
use DDTrace\Contracts\Tracer as TracerInterface;
interface Transport
{
    public function send(TracerInterface $tracer);
    public function setHeader($key, $value);
}
}

namespace DDTrace {
use ArrayIterator;
use DDTrace\Contracts\SpanContext as SpanContextInterface;
use DDTrace\Data\SpanContext as SpanContextData;
final class SpanContext extends SpanContextData
{
    public function __construct($traceId, $spanId, $parentId = null, array $baggageItems = array(), $isDistributedTracingActivationContext = false)
    {
        $this->traceId = $traceId;
        $this->spanId = $spanId;
        $this->parentId = $parentId ?: null;
        $this->baggageItems = $baggageItems;
        $this->isDistributedTracingActivationContext = $isDistributedTracingActivationContext;
    }
    public static function createAsChild(SpanContextInterface $parentContext)
    {
        $activeSpanId = dd_trace_peek_span_id();
        $instance = new self($parentContext->getTraceId(), dd_trace_push_span_id(), $activeSpanId, $parentContext->getAllBaggageItems(), false);
        $instance->parentContext = $parentContext;
        $instance->setPropagatedPrioritySampling($parentContext->getPropagatedPrioritySampling());
        if (property_exists($instance, 'origin') && !empty($parentContext->origin)) {
            $instance->origin = $parentContext->origin;
        }
        return $instance;
    }
    public static function createAsRoot(array $baggageItems = array())
    {
        $nextId = dd_trace_push_span_id();
        return new self($nextId, $nextId, null, $baggageItems, false);
    }
    public function getTraceId()
    {
        return $this->traceId;
    }
    public function getSpanId()
    {
        return $this->spanId;
    }
    public function getParentId()
    {
        return $this->parentId;
    }
    public function getIterator()
    {
        return new ArrayIterator($this->baggageItems);
    }
    public function getPropagatedPrioritySampling()
    {
        return $this->propagatedPrioritySampling;
    }
    public function setPropagatedPrioritySampling($propagatedPrioritySampling)
    {
        $this->propagatedPrioritySampling = $propagatedPrioritySampling;
    }
    public function getBaggageItem($key)
    {
        return array_key_exists($key, $this->baggageItems) ? $this->baggageItems[$key] : null;
    }
    public function withBaggageItem($key, $value)
    {
        return new self($this->traceId, $this->spanId, $this->parentId, array_merge($this->baggageItems, array($key => $value)));
    }
    public function getAllBaggageItems()
    {
        return $this->baggageItems;
    }
    public function isEqual(SpanContextInterface $spanContext)
    {
        if ($spanContext instanceof SpanContextData) {
            return $this->traceId === $spanContext->traceId && $this->spanId === $spanContext->spanId && $this->parentId === $spanContext->parentId && $this->baggageItems === $spanContext->baggageItems;
        }
        return $this->traceId === $spanContext->getTraceId() && $this->spanId === $spanContext->getSpanId() && $this->parentId === $spanContext->getParentId() && $this->baggageItems === $spanContext->getAllBaggageItems();
    }
    public function isDistributedTracingActivationContext()
    {
        return $this->isDistributedTracingActivationContext;
    }
    public function isHostRoot()
    {
        return $this->parentContext === null || $this->parentContext->isDistributedTracingActivationContext();
    }
}
}

namespace DDTrace {
use DDTrace\Data\Span as DataSpan;
use DDTrace\Exceptions\InvalidSpanArgument;
use DDTrace\SpanContext;
use DDTrace\Http\Urls;
use DDTrace\Processing\TraceAnalyticsProcessor;
use Exception;
use InvalidArgumentException;
use Throwable;
final class Span extends DataSpan
{
    private static $metricNames = array(Tag::ANALYTICS_KEY => true);
    private static $specialTags = array(Tag::ANALYTICS_KEY => true, Tag::ERROR => true, Tag::ERROR_MSG => true, Tag::SERVICE_NAME => true, Tag::RESOURCE_NAME => true, Tag::SPAN_TYPE => true, Tag::HTTP_URL => true, Tag::HTTP_STATUS_CODE => true, Tag::MANUAL_KEEP => true, Tag::MANUAL_DROP => true, Tag::SERVICE_VERSION => true);
    public function __construct($operationName, SpanContext $context, $service, $resource, $startTime = null)
    {
        $this->context = $context;
        $this->operationName = (string) $operationName;
        $this->service = (string) $service;
        $this->resource = null === $resource ? null : (string) $resource;
        $this->startTime = $startTime ?: Time::now();
    }
    public function getTraceId()
    {
        return $this->context->traceId;
    }
    public function getSpanId()
    {
        return $this->context->spanId;
    }
    public function getParentId()
    {
        return $this->context->parentId;
    }
    public function overwriteOperationName($operationName)
    {
        $this->operationName = $operationName;
    }
    public function getResource()
    {
        return $this->resource;
    }
    public function getService()
    {
        return $this->service;
    }
    public function getType()
    {
        return $this->type;
    }
    public function getStartTime()
    {
        return $this->startTime;
    }
    public function getDuration()
    {
        return $this->duration;
    }
    public function setTag($key, $value, $setIfFinished = false)
    {
        if ($this->duration !== null && !$setIfFinished) {
            return;
        }
        if ($key !== (string) $key) {
            throw InvalidSpanArgument::forTagKey($key);
        }
        if (is_object($value) && $key !== Tag::ERROR) {
            return;
        }
        if (array_key_exists($key, self::$specialTags)) {
            if ($key === Tag::ERROR) {
                $this->setError($value);
                return;
            }
            if ($key === Tag::ERROR_MSG) {
                $this->tags[$key] = (string) $value;
                $this->setError(true);
                return;
            }
            if ($key === Tag::SERVICE_NAME) {
                $this->service = $value;
                return;
            }
            if ($key === Tag::MANUAL_KEEP) {
                GlobalTracer::get()->setPrioritySampling(Sampling\PrioritySampling::USER_KEEP);
                return;
            }
            if ($key === Tag::MANUAL_DROP) {
                GlobalTracer::get()->setPrioritySampling(Sampling\PrioritySampling::USER_REJECT);
                return;
            }
            if ($key === Tag::RESOURCE_NAME) {
                $this->resource = (string) $value;
                return;
            }
            if ($key === Tag::SPAN_TYPE) {
                $this->type = $value;
                return;
            }
            if ($key === Tag::HTTP_URL) {
                $value = Urls::sanitize((string) $value);
            }
            if ($key === Tag::HTTP_STATUS_CODE && $value >= 500) {
                $this->hasError = true;
                if (!isset($this->tags[Tag::ERROR_TYPE])) {
                    $this->tags[Tag::ERROR_TYPE] = 'Internal Server Error';
                }
            }
            if ($key === Tag::SERVICE_VERSION) {
                $this->setTag(Tag::VERSION, $value);
            }
            if (array_key_exists($key, self::$metricNames)) {
                $this->setMetric($key, $value);
                return;
            }
        }
        $this->tags[$key] = (string) $value;
    }
    public function getTag($key)
    {
        if (array_key_exists($key, $this->tags)) {
            return $this->tags[$key];
        }
        return null;
    }
    public function getAllTags()
    {
        return $this->tags;
    }
    public function hasTag($name)
    {
        return array_key_exists($name, $this->getAllTags());
    }
    public function setMetric($key, $value)
    {
        if ($key === Tag::ANALYTICS_KEY) {
            TraceAnalyticsProcessor::normalizeAnalyticsValue($this->metrics, $value);
            return;
        }
        $this->metrics[$key] = $value;
    }
    public function getMetrics()
    {
        return $this->metrics;
    }
    public function setResource($resource)
    {
        $this->resource = (string) $resource;
    }
    public function setError($error)
    {
        if ($error instanceof Exception || $error instanceof Throwable) {
            $this->hasError = true;
            $this->tags[Tag::ERROR_MSG] = $error->getMessage();
            $this->tags[Tag::ERROR_TYPE] = get_class($error);
            $this->tags[Tag::ERROR_STACK] = $error->getTraceAsString();
            return;
        }
        if (is_bool($error)) {
            $this->hasError = $error;
            return;
        }
        if (is_null($error)) {
            $this->hasError = false;
        }
        throw InvalidSpanArgument::forError($error);
    }
    public function setRawError($message, $type)
    {
        $this->hasError = true;
        $this->tags[Tag::ERROR_MSG] = $message;
        $this->tags[Tag::ERROR_TYPE] = $type;
    }
    public function hasError()
    {
        return $this->hasError;
    }
    public function finish($finishTime = null)
    {
        if ($this->duration !== null) {
            return;
        }
        $this->duration = ($finishTime ?: Time::now()) - $this->startTime;
        dd_trace_pop_span_id();
    }
    public function finishWithError($error)
    {
        $this->setError($error);
        $this->finish();
    }
    public function isFinished()
    {
        return $this->duration !== null;
    }
    public function getOperationName()
    {
        return $this->operationName;
    }
    public function getContext()
    {
        return $this->context;
    }
    public function log(array $fields = array(), $timestamp = null)
    {
        foreach ($fields as $key => $value) {
            if ($key === Tag::LOG_EVENT && $value === Tag::ERROR) {
                $this->setError(true);
            } elseif ($key === Tag::LOG_ERROR || $key === Tag::LOG_ERROR_OBJECT) {
                $this->setError($value);
            } elseif ($key === Tag::LOG_MESSAGE) {
                $this->tags[Tag::ERROR_MSG] = (string) $value;
            } elseif ($key === Tag::LOG_STACK) {
                $this->setTag(Tag::ERROR_STACK, $value);
            }
        }
    }
    public function addBaggageItem($key, $value)
    {
        $this->context = $this->context->withBaggageItem($key, $value);
    }
    public function getBaggageItem($key)
    {
        return $this->context->getBaggageItem($key);
    }
    public function getAllBaggageItems()
    {
        return $this->context->baggageItems;
    }
    public function setTraceAnalyticsCandidate($value = true)
    {
        $this->isTraceAnalyticsCandidate = $value;
        return $this;
    }
    public function isTraceAnalyticsCandidate()
    {
        return $this->isTraceAnalyticsCandidate;
    }
}
}

namespace DDTrace {
use DDTrace\Encoders\Json;
use DDTrace\Encoders\SpanEncoder;
use DDTrace\Encoders\MessagePack;
use DDTrace\Log\LoggingTrait;
use DDTrace\Propagators\CurlHeadersMap;
use DDTrace\Propagators\Noop as NoopPropagator;
use DDTrace\Propagators\TextMap;
use DDTrace\Sampling\ConfigurableSampler;
use DDTrace\Sampling\Sampler;
use DDTrace\Transport\Http;
use DDTrace\Transport\Noop as NoopTransport;
use DDTrace\Exceptions\UnsupportedFormat;
use DDTrace\Contracts\Scope as ScopeInterface;
use DDTrace\Contracts\Span as SpanInterface;
use DDTrace\Contracts\SpanContext as SpanContextInterface;
use DDTrace\Contracts\Tracer as TracerInterface;
final class Tracer implements TracerInterface
{
    use LoggingTrait;
    const VERSION = '0.50.0';
    private $traces = array();
    private $transport;
    private $sampler;
    private $propagators;
    private $config = array('service_name' => PHP_SAPI, 'enabled' => true, 'global_tags' => array());
    private $scopeManager;
    private $rootScope;
    private $prioritySampling = Sampling\PrioritySampling::UNKNOWN;
    private $serviceVersion;
    private $environment;
    public function __construct(Transport $transport = null, array $propagators = null, array $config = array())
    {
        $encoder = getenv('DD_TRACE_ENCODER') === 'json' ? new Json() : new MessagePack();
        $this->transport = $transport ?: new Http($encoder);
        $textMapPropagator = new TextMap($this);
        $this->propagators = $propagators ?: array(Format::TEXT_MAP => $textMapPropagator, Format::HTTP_HEADERS => $textMapPropagator, Format::CURL_HTTP_HEADERS => new CurlHeadersMap($this));
        $this->config = array_merge($this->config, $config);
        $this->reset();
        $this->config['global_tags'] = array_merge($this->config['global_tags'], \ddtrace_config_global_tags());
        $this->serviceVersion = \ddtrace_config_service_version();
        $this->environment = \ddtrace_config_env();
    }
    public function limited()
    {
        return dd_trace_tracer_is_limited();
    }
    public function reset()
    {
        $this->scopeManager = new ScopeManager();
        $this->sampler = new ConfigurableSampler();
        $this->traces = array();
    }
    public static function noop()
    {
        return new self(new NoopTransport(), array(Format::BINARY => new NoopPropagator(), Format::TEXT_MAP => new NoopPropagator(), Format::HTTP_HEADERS => new NoopPropagator()), array('enabled' => false));
    }
    public function startSpan($operationName, $options = array())
    {
        if (!$this->config['enabled']) {
            return NoopSpan::create();
        }
        if (!$options instanceof StartSpanOptions) {
            $options = StartSpanOptions::create($options);
        }
        $reference = $this->findParent($options->getReferences());
        if ($reference === null) {
            $context = SpanContext::createAsRoot();
        } else {
            $context = SpanContext::createAsChild($reference->getContext());
        }
        $span = new Span($operationName, $context, $this->config['service_name'], array_key_exists('resource', $this->config) ? $this->config['resource'] : null, $options->getStartTime());
        $tags = $options->getTags() + $this->getGlobalTags();
        if ($context->getParentId() === null) {
            $tags[Tag::PID] = getmypid();
        }
        foreach ($tags as $key => $value) {
            $span->setTag($key, $value);
        }
        $this->record($span);
        return $span;
    }
    private function getGlobalTags()
    {
        $tags = $this->config['global_tags'];
        if (null !== $this->serviceVersion) {
            $tags[Tag::VERSION] = $this->serviceVersion;
        }
        if (null !== $this->environment) {
            $tags[Tag::ENV] = $this->environment;
        }
        return $tags;
    }
    public function startRootSpan($operationName, $options = array())
    {
        return $this->rootScope = $this->startActiveSpan($operationName, $options);
    }
    public function getRootScope()
    {
        return $this->rootScope;
    }
    public function startActiveSpan($operationName, $options = array())
    {
        if (!$options instanceof StartSpanOptions) {
            $options = StartSpanOptions::create($options);
        }
        $parentService = null;
        if (($activeSpan = $this->getActiveSpan()) !== null) {
            $options = $options->withParent($activeSpan);
            $tags = $options->getTags();
            if (!array_key_exists(Tag::SERVICE_NAME, $tags)) {
                $parentService = $activeSpan->getService();
            }
        }
        $span = $this->startSpan($operationName, $options);
        if ($parentService !== null) {
            $span->setTag(Tag::SERVICE_NAME, $parentService);
        }
        return $this->scopeManager->activate($span, $options->shouldFinishSpanOnClose());
    }
    private function findParent(array $references)
    {
        foreach ($references as $reference) {
            if ($reference->isType(Reference::CHILD_OF)) {
                return $reference;
            }
        }
        return null;
    }
    public function inject(SpanContextInterface $spanContext, $format, &$carrier)
    {
        if (!array_key_exists($format, $this->propagators)) {
            throw UnsupportedFormat::forFormat($format);
        }
        $this->enforcePrioritySamplingOnRootSpan();
        $this->propagators[$format]->inject($spanContext, $carrier);
    }
    public function extract($format, $carrier)
    {
        if (array_key_exists($format, $this->propagators)) {
            return $this->propagators[$format]->extract($carrier);
        }
        throw UnsupportedFormat::forFormat($format);
    }
    public function flush()
    {
        if (!$this->config['enabled']) {
            return;
        }
        if (\ddtrace_config_hostname_reporting_enabled()) {
            $this->addHostnameToRootSpan();
        }
        if ('cli' !== PHP_SAPI && \ddtrace_config_url_resource_name_enabled()) {
            $this->addUrlAsResourceNameToRootSpan();
        }
        if (self::isLogDebugActive()) {
            self::logDebug('Flushing {count} traces, {spanCount} spans', array('count' => $this->getTracesCount(), 'spanCount' => dd_trace_closed_spans_count()));
        }
        $this->enforcePrioritySamplingOnRootSpan();
        $this->transport->send($this);
    }
    public function getScopeManager()
    {
        return $this->scopeManager;
    }
    public function getActiveSpan()
    {
        if (null !== ($activeScope = $this->scopeManager->getActive())) {
            return $activeScope->getSpan();
        }
        return null;
    }
    public function getTracesAsArray()
    {
        $tracesToBeSent = array();
        $autoFinishSpans = \ddtrace_config_autofinish_span_enabled();
        $serviceMappings = \ddtrace_config_service_mapping();
        $root = $this->getSafeRootSpan();
        if ($root) {
            $meta = \DDTrace\additional_trace_meta();
            foreach ($meta as $tag => $value) {
                $root->setTag($tag, $value, true);
            }
        }
        foreach ($this->traces as $trace) {
            $traceToBeSent = array();
            foreach ($trace as $span) {
                if ($span->getResource() === null) {
                    $span->setResource($span->getOperationName());
                }
                if ($span->duration === null) {
                    if (!$autoFinishSpans) {
                        $traceToBeSent = null;
                        break;
                    }
                    $span->duration = Time::now() - $span->startTime;
                }
                $encodedSpan = SpanEncoder::encode($span);
                $traceToBeSent[] = $encodedSpan;
            }
            if ($traceToBeSent === null) {
                continue;
            }
            $tracesToBeSent[] = $traceToBeSent;
            if (isset($traceToBeSent[0]['trace_id'])) {
                unset($this->traces[(string) $traceToBeSent[0]['trace_id']]);
            }
        }
        $internalSpans = dd_trace_serialize_closed_spans();
        $globalTags = $this->getGlobalTags();
        if ($globalTags) {
            foreach ($internalSpans as &$internalSpan) {
                if (empty($internalSpan['resource'])) {
                    $internalSpan['resource'] = $internalSpan['name'];
                }
                foreach ($globalTags as $globalTagName => $globalTagValue) {
                    if (isset($internalSpan['meta'][$globalTagName])) {
                        continue;
                    }
                    $internalSpan['meta'][$globalTagName] = $globalTagValue;
                }
            }
        }
        if (!empty($internalSpans)) {
            $tracesToBeSent[0] = isset($tracesToBeSent[0]) ? array_merge($tracesToBeSent[0], $internalSpans) : $internalSpans;
        }
        if (isset($tracesToBeSent[0])) {
            foreach ($tracesToBeSent[0] as &$serviceSpan) {
                if (!empty($serviceSpan['service']) && !empty($serviceMappings[$serviceSpan['service']])) {
                    $serviceSpan['service'] = $serviceMappings[$serviceSpan['service']];
                }
            }
        }
        return $tracesToBeSent;
    }
    private function addHostnameToRootSpan()
    {
        $hostname = gethostname();
        if ($hostname !== false) {
            $span = $this->getRootScope()->getSpan();
            if ($span !== null) {
                $span->setTag(Tag::HOSTNAME, $hostname);
            }
        }
    }
    private function addUrlAsResourceNameToRootSpan()
    {
        $scope = $this->getRootScope();
        if (null === $scope) {
            return;
        }
        $span = $scope->getSpan();
        if (null !== $span->getResource()) {
            return;
        }
        if (!isset($_SERVER['REQUEST_METHOD'])) {
            return;
        }
        $resourceName = $_SERVER['REQUEST_METHOD'];
        if (isset($_SERVER['REQUEST_URI'])) {
            $resourceName .= ' ' . \DDtrace\Private_\util_uri_normalize_incoming_path($_SERVER['REQUEST_URI']);
        }
        $span->setTag(Tag::RESOURCE_NAME, $resourceName, true);
    }
    private function record(Span $span)
    {
        if (!array_key_exists($span->context->traceId, $this->traces)) {
            $this->traces[$span->context->traceId] = array();
        }
        $this->traces[$span->context->traceId][$span->context->spanId] = $span;
        if (\ddtrace_config_debug_enabled()) {
            self::logDebug('New span {operation} {resource} recorded.', array('operation' => $span->operationName, 'resource' => $span->resource));
        }
    }
    private function setPrioritySamplingFromSpan(Span $span)
    {
        if (!\ddtrace_config_priority_sampling_enabled()) {
            return;
        }
        if (!$span->getContext()->isHostRoot()) {
            return;
        }
        $this->prioritySampling = $span->getContext()->getPropagatedPrioritySampling();
        if (null === $this->prioritySampling) {
            $this->prioritySampling = $this->sampler->getPrioritySampling($span);
        }
    }
    public function setPrioritySampling($prioritySampling)
    {
        $this->prioritySampling = $prioritySampling;
    }
    public function getPrioritySampling()
    {
        return $this->prioritySampling;
    }
    public function getSafeRootSpan()
    {
        $rootScope = $this->getRootScope();
        if (empty($rootScope)) {
            return null;
        }
        return $rootScope->getSpan();
    }
    public static function version()
    {
        return self::VERSION;
    }
    public function getTracesCount()
    {
        return count($this->traces);
    }
    private function enforcePrioritySamplingOnRootSpan()
    {
        if ($this->prioritySampling !== Sampling\PrioritySampling::UNKNOWN) {
            return;
        }
        $rootScope = $this->getRootScope();
        if (null === $rootScope) {
            return;
        }
        $rootSpan = $rootScope->getSpan();
        if (null === $rootSpan) {
            return;
        }
        $this->setPrioritySamplingFromSpan($rootSpan);
    }
}
}

namespace DDTrace\Obfuscation {
final class WildcardToRegex
{
    const REPLACEMENT_CHARACTER = '?';
    public static function convert($wildcardPattern)
    {
        $wildcardPattern = $replacement = trim($wildcardPattern);
        if (false !== strpos($replacement, '$*')) {
            $replacement = str_replace('%', '%%', $replacement);
            $replacementCount = 0;
            $replacement = str_replace('$*', '%s', $replacement, $replacementCount);
            $sprintfArgs = array($replacement);
            for ($i = 1; $i <= $replacementCount; $i++) {
                $sprintfArgs[] = '${' . $i . '}';
            }
            $replacement = call_user_func_array('sprintf', $sprintfArgs);
        }
        $replacement = str_replace('*', self::REPLACEMENT_CHARACTER, $replacement);
        return array('|^' . str_replace(array('\\$\\*', '\\*'), array('(.+)', '.+'), preg_quote($wildcardPattern, '|')) . '$|', $replacement);
    }
}
}

namespace DDTrace {
use DDTrace\Contracts\Tracer as TracerInterface;
class StartSpanOptionsFactory
{
    public static function createForWebRequest(TracerInterface $tracer, array $options = array(), array $headers = array())
    {
        if (\ddtrace_config_distributed_tracing_enabled() && ($spanContext = $tracer->extract(Format::HTTP_HEADERS, $headers))) {
            $options[Reference::CHILD_OF] = $spanContext;
        }
        return StartSpanOptions::create($options);
    }
}
}

namespace DDTrace {
class Time
{
    public static function now()
    {
        return (int) (microtime(true) * 1000 * 1000);
    }
    public static function fromMicrotime($microtime)
    {
        return (int) $microtime * 1000 * 1000;
    }
    public static function isValid($time)
    {
        return $time === (int) $time && ctype_digit((string) $time) && strlen((string) $time) === 16;
    }
}
}

namespace DDTrace\Transport {
use DDTrace\Contracts\Tracer;
use DDTrace\Encoder;
use DDTrace\GlobalTracer;
use DDTrace\Log\LoggingTrait;
use DDTrace\Sampling\PrioritySampling;
use DDTrace\Transport;
use DDTrace\Util\ContainerInfo;
final class Http implements Transport
{
    use LoggingTrait;
    const AGENT_HOST_ENV = 'DD_AGENT_HOST';
    const TRACE_AGENT_URL_ENV = 'DD_TRACE_AGENT_URL';
    const AGENT_REQUEST_BODY_LIMIT = 10485760;
    const TRACE_AGENT_PORT_ENV = 'DD_TRACE_AGENT_PORT';
    const AGENT_TIMEOUT_ENV = 'DD_TRACE_AGENT_TIMEOUT';
    const AGENT_CONNECT_TIMEOUT_ENV = 'DD_TRACE_AGENT_CONNECT_TIMEOUT';
    const DEFAULT_AGENT_HOST = 'localhost';
    const DEFAULT_TRACE_AGENT_PORT = '8126';
    const DEFAULT_TRACE_AGENT_PATH = '/v0.3/traces';
    const PRIORITY_SAMPLING_TRACE_AGENT_PATH = '/v0.4/traces';
    const DEFAULT_AGENT_CONNECT_TIMEOUT = 100;
    const DEFAULT_AGENT_TIMEOUT = 500;
    private $encoder;
    private $headers = array();
    private $config;
    public function __construct(Encoder $encoder, array $config = array())
    {
        $this->configure($config);
        $this->encoder = $encoder;
        $this->setHeader('Datadog-Meta-Lang', 'php');
        $this->setHeader('Datadog-Meta-Lang-Version', \PHP_VERSION);
        $this->setHeader('Datadog-Meta-Lang-Interpreter', \PHP_SAPI);
        $this->setHeader('Datadog-Meta-Tracer-Version', DD_TRACE_VERSION);
        $containerInfo = new ContainerInfo();
        if ($containerId = $containerInfo->getContainerId()) {
            $this->setHeader('Datadog-Container-Id', $containerId);
        }
    }
    private function configure($config)
    {
        $host = getenv(self::AGENT_HOST_ENV) ?: self::DEFAULT_AGENT_HOST;
        $port = getenv(self::TRACE_AGENT_PORT_ENV) ?: self::DEFAULT_TRACE_AGENT_PORT;
        $traceAgentUrl = getenv(self::TRACE_AGENT_URL_ENV) ?: "http://{$host}:{$port}";
        $path = self::DEFAULT_TRACE_AGENT_PATH;
        $endpoint = "{$traceAgentUrl}{$path}";
        $this->config = array_merge(array('endpoint' => $endpoint, 'connect_timeout' => getenv(self::AGENT_CONNECT_TIMEOUT_ENV) ?: self::DEFAULT_AGENT_CONNECT_TIMEOUT, 'timeout' => getenv(self::AGENT_TIMEOUT_ENV) ?: self::DEFAULT_AGENT_TIMEOUT), $config);
    }
    public function send(Tracer $tracer)
    {
        $tracesCount = $tracer->getTracesCount();
        $tracesPayload = $this->encoder->encodeTraces($tracer);
        if ($tracesCount === 0) {
            self::logDebug('No finished traces to be sent to the agent');
        }
        $endpoint = $this->isPrioritySamplingUsed() ? str_replace(self::DEFAULT_TRACE_AGENT_PATH, self::PRIORITY_SAMPLING_TRACE_AGENT_PATH, $this->config['endpoint']) : $this->config['endpoint'];
        self::logDebug('About to send trace(s) to the agent');
        $this->sendRequest($endpoint, $this->headers, $tracesPayload, $tracesCount);
    }
    public function setHeader($key, $value)
    {
        $this->headers[(string) $key] = (string) $value;
    }
    public function getConfig()
    {
        return $this->config;
    }
    private function sendRequest($url, array $headers, $body, $tracesCount)
    {
        $bodySize = strlen($body);
        if ($bodySize > self::AGENT_REQUEST_BODY_LIMIT) {
            self::logError('Agent request payload of {bytes} bytes exceeds 10MB limit; dropping request', array('bytes' => $bodySize));
            return;
        }
        $curlHeaders = array();
        if (!isset($headers['Expect'])) {
            $curlHeaders[] = 'Expect:';
        }
        foreach ($headers as $key => $value) {
            $curlHeaders[] = "{$key}: {$value}";
        }
        $bgsEnabled = \dd_trace_env_config('DD_TRACE_BGS_ENABLED') && \dd_trace_env_config('DD_TRACE_BETA_SEND_TRACES_VIA_THREAD');
        if ($bgsEnabled && $this->encoder->getContentType() === 'application/msgpack' && \dd_trace_send_traces_via_thread($tracesCount, $curlHeaders, $body)) {
            return;
        }
        if ($this->isLogDebugActive() && function_exists('dd_tracer_circuit_breaker_info')) {
            self::logDebug('circuit breaker status: closed => {closed}, total_failures => {total_failures},' . 'consecutive_failures => {consecutive_failures}, opened_timestamp => {opened_timestamp}, ' . 'last_failure_timestamp=> {last_failure_timestamp}', dd_tracer_circuit_breaker_info());
        }
        if (function_exists('dd_tracer_circuit_breaker_can_try') && !dd_tracer_circuit_breaker_can_try()) {
            self::logError('Reporting of spans skipped due to open circuit breaker');
            return;
        }
        $curlHeaders = \array_merge($curlHeaders, array('Content-Type: ' . $this->encoder->getContentType(), 'X-Datadog-Trace-Count: ' . $tracesCount));
        $handle = curl_init($url);
        curl_setopt($handle, CURLOPT_POST, true);
        curl_setopt($handle, CURLOPT_POSTFIELDS, $body);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_TIMEOUT_MS, $this->config['timeout']);
        curl_setopt($handle, CURLOPT_CONNECTTIMEOUT_MS, $this->config['connect_timeout']);
        $isDebugEnabled = \ddtrace_config_debug_enabled();
        if ($isDebugEnabled) {
            $verbose = \fopen('php://temp', 'w+b');
            \curl_setopt($handle, \CURLOPT_VERBOSE, true);
            \curl_setopt($handle, \CURLOPT_STDERR, $verbose);
        }
        curl_setopt($handle, CURLOPT_HTTPHEADER, $curlHeaders);
        if (($response = curl_exec($handle)) === false) {
            $curlTimedout = \version_compare(\PHP_VERSION, '5.5', '<') ? \CURLE_OPERATION_TIMEOUTED : \CURLE_OPERATION_TIMEDOUT;
            $errno = \curl_errno($handle);
            $extra = '';
            if ($errno === $curlTimedout) {
                $timeout = $this->config['timeout'];
                $connectTimeout = $this->config['connect_timeout'];
                $extra = " (TIMEOUT_MS={$timeout}, CONNECTTIMEOUT_MS={$connectTimeout})";
            }
            self::logError('Reporting of spans failed: {num} / {error}{extra}', array('error' => curl_error($handle), 'num' => $errno, 'extra' => $extra));
            if ($isDebugEnabled && isset($verbose)) {
                @\rewind($verbose);
                $verboseLog = @\stream_get_contents($verbose);
                if ($verboseLog !== false) {
                    self::logError($verboseLog);
                } else {
                    self::logError('Error while retrieving curl error log');
                }
            }
            function_exists('dd_tracer_circuit_breaker_register_error') && dd_tracer_circuit_breaker_register_error();
            return;
        }
        $statusCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
        curl_close($handle);
        if ($statusCode === 415) {
            self::logError('Reporting of spans failed, upgrade your client library');
            function_exists('dd_tracer_circuit_breaker_register_error') && dd_tracer_circuit_breaker_register_error();
            return;
        }
        if ($statusCode !== 200) {
            self::logError('Reporting of spans failed, status code {code}: {response}', array('code' => $statusCode, 'response' => $response));
            function_exists('dd_tracer_circuit_breaker_register_error') && dd_tracer_circuit_breaker_register_error();
            return;
        }
        function_exists('dd_tracer_circuit_breaker_register_success') && dd_tracer_circuit_breaker_register_success();
        self::logDebug('Traces successfully sent to the agent');
    }
    private function isPrioritySamplingUsed()
    {
        $tracer = GlobalTracer::get();
        return \ddtrace_config_priority_sampling_enabled() && $tracer->getPrioritySampling() !== PrioritySampling::UNKNOWN;
    }
}
}

namespace DDTrace\Transport {
use DDTrace\Contracts\Tracer;
use DDTrace\Encoder;
use DDTrace\Transport;
final class Stream implements Transport
{
    private $encoder;
    private $stream;
    private $headers = array();
    public function __construct(Encoder $encoder, $stream = null)
    {
        $this->encoder = $encoder;
        $this->stream = $stream ?: fopen('php://output', 'w');
    }
    public function send(Tracer $tracer)
    {
        fwrite($this->stream, '{"headers": ');
        fwrite($this->stream, json_encode($this->headers));
        fwrite($this->stream, ', "traces": ');
        fwrite($this->stream, $this->encoder->encodeTraces($tracer));
        fwrite($this->stream, '}');
        fwrite($this->stream, PHP_EOL);
    }
    public function setHeader($key, $value)
    {
        $this->headers[(string) $key] = (string) $value;
    }
}
}

namespace DDTrace {
class Type
{
    const CACHE = 'cache';
    const HTTP_CLIENT = 'http';
    const WEB_SERVLET = 'web';
    const CLI = 'cli';
    const SQL = 'sql';
    const MESSAGE_CONSUMER = 'queue';
    const MESSAGE_PRODUCER = 'queue';
    const CASSANDRA = 'cassandra';
    const ELASTICSEARCH = 'elasticsearch';
    const MEMCACHED = 'memcached';
    const MONGO = 'mongodb';
    const REDIS = 'redis';
}
}

namespace DDTrace {
use DDTrace\Contracts\Tracer as TracerInterface;
interface Encoder
{
    public function encodeTraces(TracerInterface $tracer);
    public function getContentType();
}
}

namespace DDTrace\Util {
final class Runtime
{
    public static function isAutoloaderRegistered($class, $method)
    {
        $class = trim($class, '\\');
        $autoloaders = spl_autoload_functions();
        foreach ($autoloaders as $autoloader) {
            if (!is_array($autoloader) || count($autoloader) !== 2) {
                continue;
            }
            $registeredAutoloader = $autoloader[0];
            $registeredMethod = $autoloader[1];
            if (is_string($registeredAutoloader)) {
                $compareClass = trim($registeredAutoloader, '\\');
            } elseif (is_object($registeredAutoloader)) {
                $compareClass = trim(get_class($registeredAutoloader), '\\');
            } else {
                continue;
            }
            if ($compareClass === $class && $registeredMethod === $method) {
                return true;
            }
        }
        return false;
    }
}
}

namespace DDTrace\Util {
final class Versions
{
    public static function phpVersionMatches($version)
    {
        return self::versionMatches($version, PHP_VERSION);
    }
    public static function versionMatches($expected, $specimen)
    {
        $expectedFragments = self::asIntArray($expected);
        $specimenFragments = self::asIntArray($specimen);
        if (empty($expectedFragments) || empty($specimenFragments)) {
            return false;
        }
        $count = count($expectedFragments);
        for ($i = 0; $i < $count; $i++) {
            if ($specimenFragments[$i] !== $expectedFragments[$i]) {
                return false;
            }
        }
        return true;
    }
    private static function asIntArray($versionAsString)
    {
        return array_values(array_filter(array_map(function ($fragment) {
            return is_numeric($fragment) ? (int) $fragment : null;
        }, explode('.', $versionAsString))));
    }
}
}

namespace DDTrace\Util {
class ObjectKVStore
{
    private static $KEY_PREFIX = '__dd_store_';
    public static function put($instance, $key, $value)
    {
        if (self::isIncompleteInfo($instance, $key)) {
            return;
        }
        $scopedKey = self::getScopedKeyName($key);
        $instance->{$scopedKey} = $value;
    }
    public static function get($instance, $key, $default = null)
    {
        if (self::isIncompleteInfo($instance, $key)) {
            return $default;
        }
        $scopedKey = self::getScopedKeyName($key);
        return property_exists($instance, $scopedKey) ? $instance->{$scopedKey} : $default;
    }
    public static function propagate($instance_source, $instance_destination, $key)
    {
        self::put($instance_destination, $key, self::get($instance_source, $key));
    }
    private static function getScopedKeyName($key)
    {
        return self::$KEY_PREFIX . $key;
    }
    private static function isIncompleteInfo($instance, $key)
    {
        return empty($instance) || !is_object($instance) || empty($key) || !is_string($key);
    }
}
}

namespace DDTrace\Util {
class ArrayKVStore
{
    private static $resource_registry = array();
    public static function putForResource($resource, $key, $value)
    {
        if (self::notEnoughResourceInfo($resource, $key)) {
            return;
        }
        self::$resource_registry[self::getResourceKey($resource)][$key] = $value;
    }
    public static function getForResource($resource, $key, $default = null)
    {
        if (self::notEnoughResourceInfo($resource, $key)) {
            return $default;
        }
        $resourceKey = self::getResourceKey($resource);
        return isset(self::$resource_registry[$resourceKey][$key]) ? self::$resource_registry[$resourceKey][$key] : $default;
    }
    public static function deleteResource($resource)
    {
        $resourceKey = self::getResourceKey($resource);
        unset(self::$resource_registry[$resourceKey]);
    }
    public static function clear()
    {
        self::$resource_registry = array();
    }
    private static function notEnoughResourceInfo($resource, $key)
    {
        return !is_resource($resource) || empty($key) || !is_string($key);
    }
    private static function getResourceKey($resource)
    {
        return intval($resource);
    }
}
}

namespace DDTrace\Util {
use DDTrace\Integrations\Integration;
use DDTrace\GlobalTracer;
final class CodeTracer
{
    private static $instance;
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    public function tracePublicMethod($className, $method, \Closure $limitedTracerCallHook = null, \Closure $preCallHook = null, \Closure $postCallHook = null, Integration $integration = null, $isTraceAnalyticsCandidate = false)
    {
        dd_trace($className, $method, array('instrument_when_limited' => $limitedTracerCallHook ? 1 : 0, 'innerhook' => function () use($className, $method, $limitedTracerCallHook, $preCallHook, $postCallHook, $integration, $isTraceAnalyticsCandidate) {
            $tracer = GlobalTracer::get();
            if ($tracer->limited()) {
                if ($limitedTracerCallHook) {
                    $limitedTracerCallHook(func_get_args());
                }
                return dd_trace_forward_call();
            }
            $args = func_get_args();
            $scope = $tracer->startActiveSpan($className . '.' . $method);
            $span = $scope->getSpan();
            if ($integration && $isTraceAnalyticsCandidate) {
                $integration->addTraceAnalyticsIfEnabledLegacy($span);
            }
            if (null !== $preCallHook) {
                $preCallHook($span, $args);
            }
            $returnVal = null;
            $thrownException = null;
            try {
                $returnVal = dd_trace_forward_call();
            } catch (\Exception $e) {
                $span->setError($e);
                $thrownException = $e;
            }
            if (null !== $postCallHook) {
                $postCallHook($span, $returnVal);
            }
            $scope->close();
            if (null !== $thrownException) {
                throw $thrownException;
            }
            return $returnVal;
        }));
    }
}
}

namespace DDTrace\Util {
class ContainerInfo
{
    private $cgroupProcFile;
    const LINE_RE = '/^(\\d+):([^:]*):.*\\/([0-9a-f]{64})$/';
    public function __construct($cgroupProcFile = '/proc/self/cgroup')
    {
        $this->cgroupProcFile = $cgroupProcFile;
    }
    public function getContainerId()
    {
        if (!@file_exists($this->cgroupProcFile)) {
            return null;
        }
        $file = null;
        try {
            $file = fopen($this->cgroupProcFile, 'r');
            while (!feof($file)) {
                $line = fgets($file);
                $matches = array();
                preg_match(self::LINE_RE, trim($line), $matches);
                if (count($matches) > 3) {
                    return $matches[3];
                }
            }
        } catch (\Exception $e) {
        }
        if ($file) {
            fclose($file);
        }
        return null;
    }
}
}

namespace DDTrace\Processing {
use DDTrace\Data\Span as DataSpan;
use DDTrace\Tag;
final class TraceAnalyticsProcessor
{
    public static function normalizeAnalyticsValue(&$metrics, $value)
    {
        if (true === $value) {
            $metrics[Tag::ANALYTICS_KEY] = 1.0;
        } elseif (false === $value) {
            unset($metrics[Tag::ANALYTICS_KEY]);
        } elseif (is_numeric($value) && 0 <= $value && $value <= 1) {
            $metrics[Tag::ANALYTICS_KEY] = (double) $value;
        }
    }
}
}

namespace DDTrace {
class Tag
{
    const ENV = 'env';
    const SPAN_TYPE = 'span.type';
    const SERVICE_NAME = 'service.name';
    const MANUAL_KEEP = 'manual.keep';
    const MANUAL_DROP = 'manual.drop';
    const PID = 'system.pid';
    const RESOURCE_NAME = 'resource.name';
    const DB_STATEMENT = 'sql.query';
    const ERROR = 'error';
    const ERROR_MSG = 'error.msg';
    const ERROR_TYPE = 'error.type';
    const ERROR_STACK = 'error.stack';
    const HTTP_METHOD = 'http.method';
    const HTTP_STATUS_CODE = 'http.status_code';
    const HTTP_URL = 'http.url';
    const LOG_EVENT = 'event';
    const LOG_ERROR = 'error';
    const LOG_ERROR_OBJECT = 'error.object';
    const LOG_MESSAGE = 'message';
    const LOG_STACK = 'stack';
    const TARGET_HOST = 'out.host';
    const TARGET_PORT = 'out.port';
    const BYTES_OUT = 'net.out.bytes';
    const ANALYTICS_KEY = '_dd1.sr.eausr';
    const HOSTNAME = '_dd.hostname';
    const ORIGIN = '_dd.origin';
    const VERSION = 'version';
    const SERVICE_VERSION = 'service.version';
    const ELASTICSEARCH_BODY = 'elasticsearch.body';
    const ELASTICSEARCH_METHOD = 'elasticsearch.method';
    const ELASTICSEARCH_PARAMS = 'elasticsearch.params';
    const ELASTICSEARCH_URL = 'elasticsearch.url';
    const MONGODB_BSON_ID = 'mongodb.bson.id';
    const MONGODB_COLLECTION = 'mongodb.collection';
    const MONGODB_DATABASE = 'mongodb.db';
    const MONGODB_PROFILING_LEVEL = 'mongodb.profiling_level';
    const MONGODB_READ_PREFERENCE = 'mongodb.read_preference';
    const MONGODB_SERVER = 'mongodb.server';
    const MONGODB_TIMEOUT = 'mongodb.timeout';
    const MONGODB_QUERY = 'mongodb.query';
    const REDIS_RAW_COMMAND = 'redis.raw_command';
}
}

namespace DDTrace {
use DDTrace\Contracts\Scope as ScopeInterface;
use DDTrace\Contracts\Span as SpanInterface;
final class Scope implements ScopeInterface
{
    private $span;
    private $scopeManager;
    private $finishSpanOnClose;
    public function __construct(ScopeManager $scopeManager, SpanInterface $span, $finishSpanOnClose)
    {
        $this->scopeManager = $scopeManager;
        $this->span = $span;
        $this->finishSpanOnClose = $finishSpanOnClose;
    }
    public function close()
    {
        if ($this->finishSpanOnClose) {
            $this->span->finish();
        }
        $this->scopeManager->deactivate($this);
    }
    public function getSpan()
    {
        return $this->span;
    }
}
}

namespace DDTrace {
use DDTrace\Contracts\Span as SpanInterface;
use DDTrace\Contracts\SpanContext as SpanContextInterface;
use DDTrace\Exceptions\InvalidReferenceArgument;
final class Reference
{
    const CHILD_OF = 'child_of';
    const FOLLOWS_FROM = 'follows_from';
    private $type;
    private $context;
    private function __construct($type, SpanContextInterface $context)
    {
        $this->type = $type;
        $this->context = $context;
    }
    public static function create($type, $context)
    {
        if (empty($type)) {
            throw InvalidReferenceArgument::forEmptyType();
        }
        return new self($type, self::extractContext($context));
    }
    public function getContext()
    {
        return $this->context;
    }
    public function isType($type)
    {
        return $this->type === $type;
    }
    private static function extractContext($context)
    {
        if ($context instanceof SpanContextInterface) {
            return $context;
        }
        if ($context instanceof SpanInterface) {
            return $context->getContext();
        }
        throw InvalidReferenceArgument::forInvalidContext($context);
    }
}
}

namespace DDTrace\Sampling {
use DDTrace\Contracts\Span;
class AlwaysKeepSampler implements Sampler
{
    public function getPrioritySampling(Span $span)
    {
        return PrioritySampling::AUTO_KEEP;
    }
}
}

namespace DDTrace\Sampling {
class PrioritySampling
{
    const USER_REJECT = -1;
    const AUTO_REJECT = 0;
    const AUTO_KEEP = 1;
    const USER_KEEP = 2;
    const UNKNOWN = null;
    public static function parse($value)
    {
        if (!is_numeric($value)) {
            return self::UNKNOWN;
        }
        $intValue = intval($value);
        return in_array($intValue, array(self::USER_REJECT, self::AUTO_KEEP, self::AUTO_REJECT, self::USER_KEEP)) ? $intValue : self::UNKNOWN;
    }
}
}

namespace DDTrace\Sampling {
use DDTrace\Contracts\Span;
final class ConfigurableSampler implements Sampler
{
    public function getPrioritySampling(Span $span)
    {
        $samplingRules = \ddtrace_config_sampling_rules();
        foreach ($samplingRules as $rule) {
            if ($this->ruleMatches($span, $rule)) {
                $rate = $rule['sample_rate'];
                $prioritySampling = $this->computePrioritySampling($rate);
                $span->setMetric('_dd.rule_psr', $rate);
                return $prioritySampling;
            }
        }
        return $this->fallbackToPrioritySampling($span);
    }
    public function fallbackToPrioritySampling(Span $span)
    {
        return $this->computePrioritySampling(\ddtrace_config_sampling_rate());
    }
    private function ruleMatches(Span $span, array $rule)
    {
        $serviceName = $span->getService();
        $serviceNameMatches = $serviceName === \null || preg_match('/' . $rule['service'] . '/', $serviceName);
        $operationName = $span->getOperationName();
        $operationNameMatches = $operationName === \null || preg_match('/' . $rule['name'] . '/', $operationName);
        return $serviceNameMatches && $operationNameMatches;
    }
    private function computePrioritySampling($rate)
    {
        if ($rate === 1.0) {
            return PrioritySampling::AUTO_KEEP;
        } elseif ($rate === 0.0) {
            return PrioritySampling::AUTO_REJECT;
        }
        $shouldKeep = mt_rand(1, mt_getrandmax()) <= $rate * mt_getrandmax();
        return $shouldKeep ? PrioritySampling::AUTO_KEEP : PrioritySampling::AUTO_REJECT;
    }
}
}

namespace DDTrace {
use DDTrace\Contracts\SpanContext as SpanContextInterface;
interface Propagator
{
    const DEFAULT_BAGGAGE_HEADER_PREFIX = 'ot-baggage-';
    const DEFAULT_TRACE_ID_HEADER = 'x-datadog-trace-id';
    const DEFAULT_PARENT_ID_HEADER = 'x-datadog-parent-id';
    const DEFAULT_SAMPLING_PRIORITY_HEADER = 'x-datadog-sampling-priority';
    const DEFAULT_ORIGIN_HEADER = 'x-datadog-origin';
    public function inject(SpanContextInterface $spanContext, &$carrier);
    public function extract($carrier);
}
}

namespace DDTrace {
use DDTrace\Http\Request;
use DDTrace\Integrations\IntegrationsLoader;
use DDTrace\Integrations\Web\WebIntegration;
final class Bootstrap
{
    private static $bootstrapped = false;
    public static function tracerOnce()
    {
        if (self::$bootstrapped) {
            return;
        }
        self::$bootstrapped = true;
        $tracer = self::resetTracer();
        \DDTrace\hook_method('DDTrace\\Bootstrap', 'flushTracerShutdown', null, function () {
            $tracer = GlobalTracer::get();
            $scopeManager = $tracer->getScopeManager();
            $scopeManager->close();
            if (!\dd_trace_env_config('DD_TRACE_AUTO_FLUSH_ENABLED')) {
                $tracer->flush();
            }
        });
        if (\dd_trace_env_config('DD_TRACE_GENERATE_ROOT_SPAN')) {
            self::initRootSpan($tracer);
            register_shutdown_function(function () {
                register_shutdown_function(function () {
                    Bootstrap::flushTracerShutdown();
                });
            });
        }
    }
    public static function flushTracerShutdown()
    {
        dd_trace_disable_in_request();
        return mt_rand();
    }
    public static function tracerAndIntegrations()
    {
        self::tracerOnce();
        IntegrationsLoader::load();
    }
    public static function resetTracer()
    {
        $tracer = new Tracer();
        GlobalTracer::set($tracer);
        return $tracer;
    }
    private static function initRootSpan(Tracer $tracer)
    {
        $options = array('start_time' => Time::now());
        if ('cli' === PHP_SAPI) {
            $operationName = isset($_SERVER['argv'][0]) ? basename($_SERVER['argv'][0]) : 'cli.command';
            $span = $tracer->startRootSpan($operationName, StartSpanOptions::create($options))->getSpan();
            $span->setTag(Tag::SPAN_TYPE, Type::CLI);
        } else {
            $operationName = 'web.request';
            $span = $tracer->startRootSpan($operationName, StartSpanOptionsFactory::createForWebRequest($tracer, $options, Request::getHeaders()))->getSpan();
            $span->setTag(Tag::SPAN_TYPE, Type::WEB_SERVLET);
            if (isset($_SERVER['REQUEST_METHOD'])) {
                $span->setTag(Tag::HTTP_METHOD, $_SERVER['REQUEST_METHOD']);
            }
            if (isset($_SERVER['REQUEST_URI'])) {
                $span->setTag(Tag::HTTP_URL, $_SERVER['REQUEST_URI']);
            }
            $span->setTag(Tag::HTTP_STATUS_CODE, 200);
        }
        $integration = WebIntegration::getInstance();
        $integration->addTraceAnalyticsIfEnabledLegacy($span);
        $span->setTag(Tag::SERVICE_NAME, \ddtrace_config_app_name($operationName));
        $rootSpan = $span;
        \DDTrace\hook_function('header', null, function ($args) use($rootSpan) {
            if (isset($args[2])) {
                $parsedHttpStatusCode = $args[2];
            } elseif (isset($args[0])) {
                $parsedHttpStatusCode = Bootstrap::parseStatusCode($args[0]);
            }
            if (isset($parsedHttpStatusCode)) {
                $rootSpan->setTag(Tag::HTTP_STATUS_CODE, $parsedHttpStatusCode);
            }
        });
        \DDTrace\hook_function('http_response_code', null, function ($args) use($rootSpan) {
            if (isset($args[0]) && \is_numeric($code = $args[0])) {
                $rootSpan->setTag(Tag::HTTP_STATUS_CODE, $code);
            }
        });
    }
    public static function parseStatusCode($headersLine)
    {
        if (empty($headersLine) || !is_string($headersLine) || substr(strtoupper($headersLine), 0, 5) !== 'HTTP/') {
            return null;
        }
        $parts = explode(' ', $headersLine);
        if (count($parts) < 2 || !is_numeric($parts[1])) {
            return null;
        }
        return (int) $parts[1];
    }
}
}

namespace DDTrace\Encoders {
use DDTrace\Span;
use DDTrace\Data\Span as DataSpan;
use DDTrace\GlobalTracer;
use DDTrace\Log\LoggingTrait;
use DDTrace\Sampling\PrioritySampling;
use DDTrace\Tag;
final class SpanEncoder
{
    use LoggingTrait;
    public static function encode(DataSpan $span)
    {
        self::logSpanDetailsIfDebug($span);
        $arraySpan = array('trace_id' => (int) $span->context->traceId, 'span_id' => (int) $span->context->spanId, 'name' => $span->operationName, 'resource' => $span->resource, 'service' => $span->service, 'start' => (int) ($span->startTime . '000'), 'error' => $span->hasError ? 1 : 0);
        if ($span->type !== null) {
            $arraySpan['type'] = $span->type;
        }
        if ($span->duration !== null) {
            $arraySpan['duration'] = (int) ($span->duration . '000');
        }
        if ($span->context->parentId !== null) {
            $arraySpan['parent_id'] = (int) $span->context->parentId;
        }
        $tags = $span->tags;
        if (!empty($span->context->origin) && $span->context->isHostRoot()) {
            $tags[Tag::ORIGIN] = $span->context->origin;
        }
        if (!empty($tags)) {
            $arraySpan['meta'] = $tags;
        }
        $metrics = array();
        foreach ($span->metrics as $metricName => $metricValue) {
            $metrics[$metricName] = $metricValue;
        }
        if ($span->context->isHostRoot()) {
            $prioritySampling = GlobalTracer::get()->getPrioritySampling();
            if ($prioritySampling !== PrioritySampling::UNKNOWN) {
                $metrics['_sampling_priority_v1'] = $prioritySampling;
            }
            if (\dd_trace_env_config('DD_TRACE_MEASURE_COMPILE_TIME')) {
                $metrics['php.compilation.total_time_ms'] = (double) dd_trace_compile_time_microseconds() / 1000;
            }
        }
        if (!empty($metrics)) {
            $arraySpan['metrics'] = $metrics;
        }
        return $arraySpan;
    }
    private static function logSpanDetailsIfDebug(Span $span)
    {
        if (!self::isLogDebugActive()) {
            return;
        }
        $lengths = array();
        foreach ($span->getAllTags() as $tagName => $tagValue) {
            $lengths[] = "{$tagName}:" . strlen($tagValue);
        }
        self::logDebug('Encoding span \'{id}\' op: \'{operation}\' serv: \'{service}\' res: \'{resource}\' type \'{type}\'', array('id' => $span->getSpanId(), 'operation' => $span->getOperationName(), 'service' => $span->getService(), 'resource' => $span->getResource(), 'type' => $span->getType()));
        self::logDebug('Tags for span {id} \'tag:chars_count\' are: {lengths}', array('id' => $span->getSpanId(), 'lengths' => implode(',', $lengths)));
    }
}
}

namespace DDTrace\Encoders {
use DDTrace\Contracts\Tracer;
use DDTrace\Encoder;
use DDTrace\Log\LoggingTrait;
final class MessagePack implements Encoder
{
    use LoggingTrait;
    public function encodeTraces(Tracer $tracer)
    {
        $messagePack = dd_trace_serialize_msgpack($tracer->getTracesAsArray());
        if (false === $messagePack) {
            self::logDebug('Failed to MessagePack-encode trace');
            return '';
        }
        return $messagePack;
    }
    public function getContentType()
    {
        return 'application/msgpack';
    }
}
}

namespace DDTrace\Exceptions {
use InvalidArgumentException;
final class InvalidReferenceArgument extends InvalidArgumentException
{
    public static function forEmptyType()
    {
        return new self('Reference type can not be an empty string');
    }
    public static function forInvalidContext($context)
    {
        return new self(sprintf('Reference expects \\DDTrace\\Contracts\\Span or \\DDTrace\\Contracts\\SpanContext as context, got %s', is_object($context) ? get_class($context) : gettype($context)));
    }
}
}

namespace DDTrace\Exceptions {
use UnexpectedValueException;
final class UnsupportedFormat extends UnexpectedValueException
{
    public static function forFormat($format)
    {
        return new self(sprintf('The format \'%s\' is not supported.', $format));
    }
}
}

namespace DDTrace\Exceptions {
use InvalidArgumentException;
final class InvalidSpanArgument extends InvalidArgumentException
{
    public static function forTagKey($key)
    {
        return new self(sprintf('Invalid key type in given span tags. Expected string, got %s.', gettype($key)));
    }
    public static function forError($error)
    {
        return new self(sprintf('Error should be either Exception or Throwable, got %s.', gettype($error)));
    }
}
}

namespace DDTrace\Exceptions {
use DomainException;
final class InvalidReferencesSet extends DomainException
{
    public static function create($message)
    {
        return new self($message);
    }
    public static function forMoreThanOneParent()
    {
        return new self('Span can not have more than one parent, either one as child_of or either one as follows_from');
    }
}
}

namespace DDTrace\Exceptions {
use InvalidArgumentException;
final class InvalidSpanOption extends InvalidArgumentException
{
    public static function forIncludingBothChildOfAndReferences()
    {
        return new self('Either "childOf" or "references" options are accepted but not both.');
    }
    public static function forInvalidReference($reference)
    {
        return new self(sprintf('Invalid reference. Expected \\DDTrace\\Reference, got %s.', is_object($reference) ? get_class($reference) : gettype($reference)));
    }
    public static function forInvalidStartTime()
    {
        return new self(sprintf('Invalid start_time option. Expected int or float got string.'));
    }
    public static function forInvalidChildOf($childOfOption)
    {
        return new self(sprintf('Invalid child_of option. Expected Span or SpanContext, got %s', is_object($childOfOption) ? get_class($childOfOption) : gettype($childOfOption)));
    }
    public static function forUnknownOption($key)
    {
        return new self(sprintf('Invalid option %s.', $key));
    }
    public static function forInvalidTag($tag)
    {
        return new self(sprintf('Invalid tag. Expected string, got %s', gettype($tag)));
    }
    public static function forInvalidTagValue($tagValue)
    {
        return new self(sprintf('Invalid tag value. Expected scalar or object with __toString method, got %s', is_object($tagValue) ? get_class($tagValue) : gettype($tagValue)));
    }
    public static function forInvalidTags($value)
    {
        return new self(sprintf('Invalid tags value. Expected a associative array of tags, got %s', is_object($value) ? get_class($value) : gettype($value)));
    }
    public static function forInvalidReferenceSet($value)
    {
        return new self(sprintf('Invalid references set. Expected Reference or Reference[], got %s', is_object($value) ? get_class($value) : gettype($value)));
    }
    public static function forFinishSpanOnClose($value)
    {
        return new self(sprintf('Invalid type for finish_span_on_close. Expected bool, got %s', is_object($value) ? get_class($value) : gettype($value)));
    }
    public static function forIgnoreActiveSpan($value)
    {
        return new self(sprintf('Invalid type for ignore_active_span. Expected bool, got %s', is_object($value) ? get_class($value) : gettype($value)));
    }
}
}

namespace DDTrace {
use DDTrace\Contracts\Tracer as TracerInterface;
final class GlobalTracer
{
    private static $instance;
    public static function set(TracerInterface $tracer)
    {
        self::$instance = $tracer;
    }
    public static function get()
    {
        if (null !== self::$instance) {
            return self::$instance;
        }
        return self::$instance = NoopTracer::create();
    }
}
}

namespace DDTrace\Propagators {
use DDTrace\Log\LoggingTrait;
use DDTrace\Propagator;
use DDTrace\Sampling\PrioritySampling;
use DDTrace\Contracts\SpanContext as SpanContextInterface;
use DDTrace\Contracts\Tracer;
use DDTrace\SpanContext;
final class TextMap implements Propagator
{
    use LoggingTrait;
    private $tracer;
    public function __construct(Tracer $tracer)
    {
        $this->tracer = $tracer;
    }
    public function inject(SpanContextInterface $spanContext, &$carrier)
    {
        $carrier[Propagator::DEFAULT_TRACE_ID_HEADER] = $spanContext->getTraceId();
        $carrier[Propagator::DEFAULT_PARENT_ID_HEADER] = $spanContext->getSpanId();
        foreach ($spanContext as $key => $value) {
            $carrier[Propagator::DEFAULT_BAGGAGE_HEADER_PREFIX . $key] = $value;
        }
        $prioritySampling = $this->tracer->getPrioritySampling();
        if (PrioritySampling::UNKNOWN !== $prioritySampling) {
            $carrier[Propagator::DEFAULT_SAMPLING_PRIORITY_HEADER] = $prioritySampling;
        }
        if (!empty($spanContext->origin)) {
            $carrier[Propagator::DEFAULT_ORIGIN_HEADER] = $spanContext->origin;
        }
    }
    public function extract($carrier)
    {
        $traceId = '';
        $spanId = '';
        $prioritySampling = null;
        $baggageItems = array();
        foreach ($carrier as $key => $value) {
            if ($key === Propagator::DEFAULT_TRACE_ID_HEADER) {
                $traceId = $this->extractStringOrFirstArrayElement($value);
            } elseif ($key === Propagator::DEFAULT_PARENT_ID_HEADER) {
                $spanId = $this->extractStringOrFirstArrayElement($value);
            } elseif (strpos($key, Propagator::DEFAULT_BAGGAGE_HEADER_PREFIX) === 0) {
                $baggageItems[substr($key, strlen(Propagator::DEFAULT_BAGGAGE_HEADER_PREFIX))] = $value;
            }
        }
        if (preg_match('/^\\d+$/', $traceId) !== 1 || preg_match('/^\\d+$/', $spanId) !== 1) {
            return null;
        }
        if (!$this->setDistributedTraceTraceId($traceId)) {
            return null;
        }
        $spanId = $this->setDistributedTraceParentId($spanId);
        $spanContext = new SpanContext($traceId, $spanId, null, $baggageItems, true);
        $this->extractPrioritySampling($spanContext, $carrier);
        $this->extractOrigin($spanContext, $carrier);
        return $spanContext;
    }
    private function setDistributedTraceTraceId($traceId)
    {
        if (!$traceId) {
            return false;
        }
        if (dd_trace_set_trace_id($traceId)) {
            return true;
        }
        if (\ddtrace_config_debug_enabled()) {
            self::logDebug('Error parsing distributed trace trace ID: {id}; ignoring.', array('id' => $traceId));
        }
        return false;
    }
    private function setDistributedTraceParentId($spanId)
    {
        if (!$spanId) {
            return '';
        }
        $pushedSpanId = dd_trace_push_span_id($spanId);
        if ($pushedSpanId === $spanId) {
            return $spanId;
        }
        if (\ddtrace_config_debug_enabled()) {
            self::logDebug('Error parsing distributed trace parent ID: {expected}; using {actual} instead.', array('expected' => $spanId, 'actual' => $pushedSpanId));
        }
        return $pushedSpanId;
    }
    private function extractStringOrFirstArrayElement($value)
    {
        if (is_array($value) && count($value) > 0) {
            return $value[0];
        } elseif (is_string($value)) {
            return $value;
        }
        return null;
    }
    private function extractPrioritySampling(SpanContextInterface $spanContext, $carrier)
    {
        if (isset($carrier[Propagator::DEFAULT_SAMPLING_PRIORITY_HEADER])) {
            $rawValue = $this->extractStringOrFirstArrayElement($carrier[Propagator::DEFAULT_SAMPLING_PRIORITY_HEADER]);
            $spanContext->setPropagatedPrioritySampling(PrioritySampling::parse($rawValue));
        }
    }
    private function extractOrigin(SpanContextInterface $spanContext, $carrier)
    {
        if (property_exists($spanContext, 'origin') && isset($carrier[Propagator::DEFAULT_ORIGIN_HEADER])) {
            $spanContext->origin = $this->extractStringOrFirstArrayElement($carrier[Propagator::DEFAULT_ORIGIN_HEADER]);
        }
    }
}
}

namespace DDTrace\Propagators {
use DDTrace\NoopSpanContext;
use DDTrace\Propagator;
use DDTrace\Sampling\PrioritySampling;
use DDTrace\Contracts\SpanContext;
use DDTrace\Contracts\Tracer;
final class CurlHeadersMap implements Propagator
{
    private $tracer;
    public function __construct(Tracer $tracer)
    {
        $this->tracer = $tracer;
    }
    public function inject(SpanContext $spanContext, &$carrier)
    {
        foreach ($carrier as $index => $value) {
            if (strpos($value, Propagator::DEFAULT_TRACE_ID_HEADER) === 0 || strpos($value, Propagator::DEFAULT_PARENT_ID_HEADER) === 0 || strpos($value, Propagator::DEFAULT_BAGGAGE_HEADER_PREFIX) === 0 || strpos($value, Propagator::DEFAULT_SAMPLING_PRIORITY_HEADER) === 0 || strpos($value, Propagator::DEFAULT_ORIGIN_HEADER) === 0) {
                unset($carrier[$index]);
            }
        }
        $carrier[] = Propagator::DEFAULT_TRACE_ID_HEADER . ': ' . $spanContext->getTraceId();
        $carrier[] = Propagator::DEFAULT_PARENT_ID_HEADER . ': ' . $spanContext->getSpanId();
        foreach ($spanContext as $key => $value) {
            $carrier[] = Propagator::DEFAULT_BAGGAGE_HEADER_PREFIX . $key . ': ' . $value;
        }
        $prioritySampling = $this->tracer->getPrioritySampling();
        if (PrioritySampling::UNKNOWN !== $prioritySampling) {
            $carrier[] = Propagator::DEFAULT_SAMPLING_PRIORITY_HEADER . ': ' . $prioritySampling;
        }
        if (!empty($spanContext->origin)) {
            $carrier[] = Propagator::DEFAULT_ORIGIN_HEADER . ': ' . $spanContext->origin;
        }
    }
    public function extract($carrier)
    {
        return NoopSpanContext::create();
    }
}
}

namespace DDTrace\Http {
use DDTrace\Obfuscation\WildcardToRegex;
class Urls
{
    private static $defaultPatterns = array('<(/)([0-9a-f]{8}-?[0-9a-f]{4}-?[1-5][0-9a-f]{3}-?[89ab][0-9a-f]{3}-?[0-9a-f]{12})(/|$)>i', '<(/)([0-9a-f]{8,128})(/|$)>i', '<(/)([0-9]+)(/|$)>');
    private $replacementPatterns = array();
    public function __construct(array $patternsWithWildcards = array())
    {
        foreach ($patternsWithWildcards as $pattern) {
            $this->replacementPatterns[] = WildcardToRegex::convert($pattern);
        }
    }
    public static function sanitize($url)
    {
        return strstr($url, '?', true) ?: $url;
    }
    public static function hostname($url)
    {
        return (string) parse_url($url, PHP_URL_HOST);
    }
    public static function hostnameForTag($url)
    {
        return 'host-' . self::hostname($url);
    }
    public function normalize($url)
    {
        $url = self::sanitize($url);
        foreach ($this->replacementPatterns as $regexReplacement) {
            list($regex, $replacement) = $regexReplacement;
            $replacedCount = 0;
            $url = preg_replace($regex, $replacement, $url, -1, $replacedCount);
            if ($replacedCount > 0) {
                return $url;
            }
        }
        return preg_replace(self::$defaultPatterns, '$1?$3', $url);
    }
}
}

namespace DDTrace\Http {
class Request
{
    public static function getHeaders(array $server = array())
    {
        $headers = array();
        $server = $server ?: $_SERVER;
        foreach ($server as $key => $value) {
            if (strpos($key, 'HTTP_') !== 0) {
                continue;
            }
            $key = substr($key, 5);
            $key = str_replace(' ', '-', strtolower(str_replace('_', ' ', $key)));
            $headers[$key] = $value;
        }
        return $headers;
    }
}
}

namespace DDTrace {
use DDTrace\Contracts\Scope as ScopeInterface;
use DDTrace\Contracts\ScopeManager as ScopeManagerInterface;
use DDTrace\Contracts\Span as SpanInterface;
final class ScopeManager implements ScopeManagerInterface
{
    private $scopes = array();
    private $hostRootScopes = array();
    public function activate(SpanInterface $span, $finishSpanOnClose = self::DEFAULT_FINISH_SPAN_ON_CLOSE)
    {
        $scope = new Scope($this, $span, $finishSpanOnClose);
        $this->scopes[] = $scope;
        if ($span->getContext()->isHostRoot()) {
            $this->hostRootScopes[] = $scope;
        }
        return $scope;
    }
    public function getActive()
    {
        if (empty($this->scopes)) {
            return null;
        }
        return $this->scopes[count($this->scopes) - 1];
    }
    public function deactivate(Scope $scope)
    {
        $i = array_search($scope, $this->scopes, true);
        if (false === $i) {
            return;
        }
        array_splice($this->scopes, $i, 1);
    }
    public function close()
    {
        foreach ($this->hostRootScopes as $scope) {
            $scope->close();
        }
    }
}
}

namespace DDTrace\Integrations {
abstract class AbstractIntegrationConfiguration
{
    protected $integrationName;
    private $requiresExplicitTraceAnalyticsEnabling = true;
    public function __construct($integrationName, $requiresExplicitTraceAnalyticsEnabling = true)
    {
        $this->integrationName = $integrationName;
        $this->requiresExplicitTraceAnalyticsEnabling = $requiresExplicitTraceAnalyticsEnabling;
    }
    public function requiresExplicitTraceAnalyticsEnabling()
    {
        return $this->requiresExplicitTraceAnalyticsEnabling;
    }
}
}

namespace DDTrace\Integrations {
class DefaultIntegrationConfiguration extends AbstractIntegrationConfiguration
{
    public function isTraceAnalyticsEnabled()
    {
        if (\DDTrace\Config\integration_analytics_enabled($this->integrationName)) {
            return true;
        }
        return \ddtrace_config_analytics_enabled() && !$this->requiresExplicitTraceAnalyticsEnabling();
    }
    public function getTraceAnalyticsSampleRate()
    {
        return \DDTrace\Config\integration_analytics_sample_rate($this->integrationName);
    }
}
}

namespace DDTrace\Integrations {
use DDTrace\Contracts\Span;
use DDTrace\SpanData;
use DDTrace\Tag;
abstract class Integration
{
    const NOT_LOADED = 0;
    const LOADED = 1;
    const NOT_AVAILABLE = 2;
    protected $configuration;
    public abstract function init();
    public abstract function getName();
    public final function __construct()
    {
        $this->configuration = new DefaultIntegrationConfiguration($this->getName(), $this->requiresExplicitTraceAnalyticsEnabling());
    }
    public function addTraceAnalyticsIfEnabled(SpanData $span)
    {
        if (!$this->configuration->isTraceAnalyticsEnabled()) {
            return;
        }
        $span->metrics[Tag::ANALYTICS_KEY] = $this->configuration->getTraceAnalyticsSampleRate();
    }
    public function addTraceAnalyticsIfEnabledLegacy(Span $span)
    {
        if (!$this->configuration->isTraceAnalyticsEnabled()) {
            return;
        }
        $span->setMetric(Tag::ANALYTICS_KEY, $this->configuration->getTraceAnalyticsSampleRate());
    }
    public function setError(SpanData $span, \Exception $exception)
    {
        $span->meta[Tag::ERROR_MSG] = $exception->getMessage();
        $span->meta[Tag::ERROR_TYPE] = get_class($exception);
        $span->meta[Tag::ERROR_STACK] = $exception->getTraceAsString();
    }
    public function mergeMeta(SpanData $span, $meta)
    {
        foreach ($meta as $tagName => $value) {
            $span->meta[$tagName] = $value;
        }
    }
    protected function getConfiguration()
    {
        return $this->configuration;
    }
    public function requiresExplicitTraceAnalyticsEnabling()
    {
        return true;
    }
    public static function shouldLoad($name)
    {
        if (!\extension_loaded('ddtrace')) {
            \trigger_error('ddtrace extension required to load integration.', \E_USER_WARNING);
            return false;
        }
        return \ddtrace_config_integration_enabled($name);
    }
}
function load_deferred_integration($integrationName)
{
    if (\class_exists($integrationName, $autoload = false) && \is_subclass_of($integrationName, 'DDTrace\\Integrations\\Integration')) {
        $integration = new $integrationName();
        $integration->init();
    }
}
}

namespace DDTrace\Integrations\CakePHP {
use CakeRequest;
use DDTrace\GlobalTracer;
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
use Router;
class CakePHPIntegration extends Integration
{
    const NAME = 'cakephp';
    public $appName;
    public $rootSpan;
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        if (!self::shouldLoad(self::NAME)) {
            return self::NOT_AVAILABLE;
        }
        $integration = $this;
        $initCakeV2 = function () use($integration) {
            if (!defined('CAKE_CORE_INCLUDE_PATH')) {
                return false;
            }
            $scope = GlobalTracer::get()->getRootScope();
            if (!$scope) {
                return false;
            }
            $integration->appName = \ddtrace_config_app_name(CakePHPIntegration::NAME);
            $integration->rootSpan = $scope->getSpan();
            $integration->addTraceAnalyticsIfEnabledLegacy($integration->rootSpan);
            $integration->rootSpan->setTag(Tag::SERVICE_NAME, $integration->appName);
            if ('cli' === PHP_SAPI) {
                $integration->rootSpan->overwriteOperationName('cakephp.console');
                $integration->rootSpan->setTag(Tag::RESOURCE_NAME, !empty($_SERVER['argv'][1]) ? 'cake_console ' . $_SERVER['argv'][1] : 'cake_console');
            } else {
                $integration->rootSpan->overwriteOperationName('cakephp.request');
            }
            \DDTrace\trace_method('Controller', 'invokeAction', function (SpanData $span, array $args) use($integration) {
                $span->name = $span->resource = 'Controller.invokeAction';
                $span->type = Type::WEB_SERVLET;
                $span->service = $integration->appName;
                $request = $args[0];
                if (!$request instanceof CakeRequest) {
                    return;
                }
                $integration->rootSpan->setTag(Tag::RESOURCE_NAME, $_SERVER['REQUEST_METHOD'] . ' ' . $this->name . 'Controller@' . $request->params['action']);
                $integration->rootSpan->setTag(Tag::HTTP_URL, Router::url($request->here, true));
                $integration->rootSpan->setTag('cakephp.route.controller', $request->params['controller']);
                $integration->rootSpan->setTag('cakephp.route.action', $request->params['action']);
                if (isset($request->params['plugin'])) {
                    $integration->rootSpan->setTag('cakephp.plugin', $request->params['plugin']);
                }
            });
            \DDTrace\trace_method('ExceptionRenderer', '__construct', array('instrument_when_limited' => 1, 'posthook' => function (SpanData $span, array $args) use($integration) {
                $integration->rootSpan->setError($args[0]);
                return false;
            }));
            \DDTrace\trace_method('CakeResponse', 'statusCode', array('instrument_when_limited' => 1, 'posthook' => function (SpanData $span, $args, $return) use($integration) {
                $integration->rootSpan->setTag(Tag::HTTP_STATUS_CODE, $return);
                return false;
            }));
            \DDTrace\trace_method('View', 'render', function (SpanData $span) use($integration) {
                $span->name = 'cakephp.view';
                $span->type = Type::WEB_SERVLET;
                $file = $this->viewPath . '/' . $this->view . $this->ext;
                $span->resource = $file;
                $span->meta = array('cakephp.view' => $file);
                $span->service = $integration->appName;
            });
            return false;
        };
        if ('cli' === PHP_SAPI) {
            \DDTrace\trace_method('App', 'init', $initCakeV2);
        } else {
            \DDTrace\trace_method('Dispatcher', '__construct', $initCakeV2);
        }
        return Integration::LOADED;
    }
}
}

namespace DDTrace\Integrations\CodeIgniter\V2 {
use DDTrace\Contracts\Span;
use DDTrace\GlobalTracer;
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
class CodeIgniterIntegration extends Integration
{
    const NAME = 'codeigniter';
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        $tracer = GlobalTracer::get();
        $integration = $this;
        $rootScope = $tracer->getRootScope();
        if (!$rootScope) {
            return Integration::NOT_LOADED;
        }
        $service = \ddtrace_config_app_name(self::NAME);
        \DDTrace\hook_method('CI_Router', '_set_routing', null, function ($router) use($integration, $rootScope, $service) {
            if (!\defined('CI_VERSION') || !isset($router)) {
                return;
            }
            $majorVersion = \substr(\CI_VERSION, 0, 2);
            if ('2.' === $majorVersion) {
                $integration->registerIntegration($router, $rootScope->getSpan(), $service);
            }
        });
        return parent::LOADED;
    }
    public function registerIntegration(\CI_Router $router, Span $root, $service)
    {
        $this->addTraceAnalyticsIfEnabledLegacy($root);
        $root->overwriteOperationName('codeigniter.request');
        $root->setTag(Tag::SERVICE_NAME, $service);
        $root->setTag(Tag::SPAN_TYPE, Type::WEB_SERVLET);
        if ('cli' !== PHP_SAPI) {
            $normalizedPath = \DDtrace\Private_\util_uri_normalize_incoming_path($_SERVER['REQUEST_URI']);
            $root->setTag(Tag::RESOURCE_NAME, "{$_SERVER['REQUEST_METHOD']} {$normalizedPath}", true);
        }
        $controller = $router->fetch_class();
        $method = $router->fetch_method();
        \DDTrace\trace_method($controller, $method, function (SpanData $span) use($root, $method, $service) {
            $class = \get_class($this);
            $span->name = $span->resource = "{$class}.{$method}";
            $span->service = $service;
            $span->type = Type::WEB_SERVLET;
            $this->load->helper('url');
            $root->setTag(Tag::HTTP_URL, base_url(uri_string()));
            $root->setTag('app.endpoint', "{$class}::{$method}");
        });
        \DDTrace\trace_method($controller, '_remap', function (SpanData $span, $args, $retval, $ex) use($root, $service) {
            $class = \get_class($this);
            $span->name = "{$class}._remap";
            $span->resource = !$ex && isset($args[0]) ? $args[0] : $span->name;
            $span->service = $service;
            $span->type = Type::WEB_SERVLET;
            $this->load->helper('url');
            $root->setTag(Tag::HTTP_URL, base_url(uri_string()));
            $root->setTag('app.endpoint', "{$class}::_remap");
        });
        \DDTrace\trace_method('CI_Loader', 'view', function (SpanData $span, $args, $retval, $ex) use($service) {
            $span->name = 'CI_Loader.view';
            $span->service = $service;
            $span->resource = !$ex && isset($args[0]) ? $args[0] : $span->name;
            $span->type = Type::WEB_SERVLET;
        });
        \DDTrace\trace_method('CI_DB_driver', 'query', function (SpanData $span, $args, $retval, $ex) use($service) {
            if (\dd_trace_tracer_is_limited()) {
                return false;
            }
            $class = \get_class($this);
            $span->name = "{$class}.query";
            $span->service = $service;
            $span->type = Type::SQL;
            $span->resource = !$ex && isset($args[0]) ? $args[0] : $span->name;
        });
        $registered_cache_adapters = array();
        \DDTrace\trace_method('CI_Cache', '__get', function (SpanData $span, $args, $retval, $ex) use($service, &$registered_cache_adapters) {
            if (!$ex && \is_object($retval)) {
                $class = \get_class($retval);
                if (!isset($registered_cache_adapters[$class])) {
                    CodeIgniterIntegration::registerCacheAdapter($class, $service);
                    $registered_cache_adapters[$class] = true;
                }
            }
            return false;
        });
    }
    public static function registerCacheAdapter($adapter, $service)
    {
        \DDTrace\trace_method($adapter, 'get', function (SpanData $span, $args, $retval, $ex) use($adapter, $service) {
            $class = \get_class($this);
            $span->name = "{$class}.get";
            $span->service = $service;
            $span->type = Type::CACHE;
            $span->resource = !$ex && isset($args[0]) ? $args[0] : $span->name;
        });
        \DDTrace\trace_method($adapter, 'save', function (SpanData $span, $args, $retval, $ex) use($adapter, $service) {
            $class = \get_class($this);
            $span->name = "{$class}.save";
            $span->service = $service;
            $span->type = Type::CACHE;
            $span->resource = !$ex && isset($args[0]) ? $args[0] : $span->name;
        });
        \DDTrace\trace_method($adapter, 'delete', function (SpanData $span, $args, $retval, $ex) use($adapter, $service) {
            $class = \get_class($this);
            $span->name = "{$class}.delete";
            $span->service = $service;
            $span->type = Type::CACHE;
            $span->resource = !$ex && isset($args[0]) ? $args[0] : $span->name;
        });
        \DDTrace\trace_method($adapter, 'clean', function (SpanData $span, $args, $retval, $ex) use($adapter, $service) {
            $class = \get_class($this);
            $span->name = "{$class}.clean";
            $span->service = $service;
            $span->type = Type::CACHE;
            $span->resource = $span->name;
        });
    }
}
}

namespace DDTrace\Integrations\Web {
use DDTrace\Integrations\Integration;
class WebIntegration extends Integration
{
    const NAME = 'web';
    private static $instance;
    public static function getInstance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        return Integration::LOADED;
    }
    public function requiresExplicitTraceAnalyticsEnabling()
    {
        return false;
    }
}
}

namespace DDTrace\Integrations {
use DDTrace\Integrations\CakePHP\CakePHPIntegration;
use DDTrace\Integrations\CodeIgniter\V2\CodeIgniterIntegration;
use DDTrace\Integrations\Curl\CurlIntegration;
use DDTrace\Integrations\ElasticSearch\V1\ElasticSearchIntegration;
use DDTrace\Integrations\Eloquent\EloquentIntegration;
use DDTrace\Integrations\Guzzle\GuzzleIntegration;
use DDTrace\Integrations\Laravel\LaravelIntegration;
use DDTrace\Integrations\Lumen\LumenIntegration;
use DDTrace\Integrations\Memcached\MemcachedIntegration;
use DDTrace\Integrations\Mongo\MongoIntegration;
use DDTrace\Integrations\Mysqli\MysqliIntegration;
use DDTrace\Integrations\PDO\PDOIntegration;
use DDTrace\Integrations\Predis\PredisIntegration;
use DDTrace\Integrations\Slim\SlimIntegration;
use DDTrace\Integrations\Symfony\SymfonyIntegration;
use DDTrace\Integrations\Web\WebIntegration;
use DDTrace\Integrations\WordPress\WordPressIntegration;
use DDTrace\Integrations\Yii\YiiIntegration;
use DDTrace\Integrations\ZendFramework\ZendFrameworkIntegration;
use DDTrace\Log\LoggingTrait;
class IntegrationsLoader
{
    use LoggingTrait;
    private static $instance;
    private $integrations = array();
    public static $officiallySupportedIntegrations = array(WebIntegration::NAME => '\\DDTrace\\Integrations\\Web\\WebIntegration');
    private $loadings = array();
    public function __construct(array $integrations)
    {
        $this->integrations = $integrations;
        $this->integrations[CakePHPIntegration::NAME] = '\\DDTrace\\Integrations\\CakePHP\\CakePHPIntegration';
        $this->integrations[CodeIgniterIntegration::NAME] = '\\DDTrace\\Integrations\\CodeIgniter\\V2\\CodeIgniterIntegration';
        $this->integrations[CurlIntegration::NAME] = '\\DDTrace\\Integrations\\Curl\\CurlIntegration';
        $this->integrations[EloquentIntegration::NAME] = '\\DDTrace\\Integrations\\Eloquent\\EloquentIntegration';
        $this->integrations[GuzzleIntegration::NAME] = '\\DDTrace\\Integrations\\Guzzle\\GuzzleIntegration';
        $this->integrations[LaravelIntegration::NAME] = '\\DDTrace\\Integrations\\Laravel\\LaravelIntegration';
        $this->integrations[LumenIntegration::NAME] = '\\DDTrace\\Integrations\\Lumen\\LumenIntegration';
        $this->integrations[MongoIntegration::NAME] = '\\DDTrace\\Integrations\\Mongo\\MongoIntegration';
        $this->integrations[MysqliIntegration::NAME] = '\\DDTrace\\Integrations\\Mysqli\\MysqliIntegration';
        $this->integrations[SymfonyIntegration::NAME] = '\\DDTrace\\Integrations\\Symfony\\SymfonyIntegration';
        $this->integrations[ZendFrameworkIntegration::NAME] = '\\DDTrace\\Integrations\\ZendFramework\\ZendFrameworkIntegration';
        if (\PHP_MAJOR_VERSION < 7) {
            $this->integrations[ElasticSearchIntegration::NAME] = '\\DDTrace\\Integrations\\ElasticSearch\\V1\\ElasticSearchIntegration';
            $this->integrations[MemcachedIntegration::NAME] = '\\DDTrace\\Integrations\\Memcached\\MemcachedIntegration';
            $this->integrations[PDOIntegration::NAME] = '\\DDTrace\\Integrations\\PDO\\PDOIntegration';
            $this->integrations[PredisIntegration::NAME] = '\\DDTrace\\Integrations\\Predis\\PredisIntegration';
            $this->integrations[SlimIntegration::NAME] = '\\DDTrace\\Integrations\\Slim\\SlimIntegration';
            $this->integrations[YiiIntegration::NAME] = '\\DDTrace\\Integrations\\Yii\\YiiIntegration';
            $this->integrations[WordPressIntegration::NAME] = '\\DDTrace\\Integrations\\WordPress\\WordPressIntegration';
        }
    }
    public static function get()
    {
        if (null === self::$instance) {
            self::$instance = new IntegrationsLoader(self::$officiallySupportedIntegrations);
        }
        return self::$instance;
    }
    public function loadAll()
    {
        if (!extension_loaded('ddtrace')) {
            trigger_error('Missing ddtrace extension. To disable tracing set env variable DD_TRACE_ENABLED=false', E_USER_WARNING);
            return;
        }
        if (!\ddtrace_config_trace_enabled()) {
            return;
        }
        self::logDebug('Attempting integrations load');
        foreach ($this->integrations as $name => $class) {
            if (!\ddtrace_config_integration_enabled($name)) {
                self::logDebug('Integration {name} is disabled', array('name' => $name));
                continue;
            }
            $integrationLoadingStatus = $this->getLoadingStatus($name);
            if (in_array($integrationLoadingStatus, array(Integration::LOADED, Integration::NOT_AVAILABLE))) {
                continue;
            }
            $integration = new $class();
            $this->loadings[$name] = $integration->init();
            $this->logResult($name, $this->loadings[$name]);
        }
    }
    private function logResult($name, $result)
    {
        if ($result === Integration::LOADED) {
            self::logDebug('Loaded integration {name}', array('name' => $name));
        } elseif ($result === Integration::NOT_AVAILABLE) {
            self::logDebug('Integration {name} not available. New attempts WILL NOT be performed.', array('name' => $name));
        } elseif ($result === Integration::NOT_LOADED) {
            self::logDebug('Integration {name} not loaded. New attempts might be performed.', array('name' => $name));
        } else {
            self::logError('Invalid value returning by integration loader for {name}: {value}', array('name' => $name, 'value' => $result));
        }
    }
    public function getIntegrations()
    {
        return $this->integrations;
    }
    public function getLoadingStatus($integrationName)
    {
        return isset($this->loadings[$integrationName]) ? $this->loadings[$integrationName] : Integration::NOT_LOADED;
    }
    public static function load()
    {
        self::get()->loadAll();
    }
    public static function reload()
    {
        self::$instance = null;
        self::load();
    }
    public function reset()
    {
        $this->integrations = array();
    }
}
}

namespace DDTrace\Integrations\PDO {
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
class PDOIntegration extends Integration
{
    const NAME = 'pdo';
    private static $connections = array();
    private static $statements = array();
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        if (!extension_loaded('PDO')) {
            return Integration::NOT_AVAILABLE;
        }
        $integration = $this;
        \DDTrace\trace_method('PDO', '__construct', function (SpanData $span, array $args) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $span->name = $span->resource = 'PDO.__construct';
            $span->service = 'pdo';
            $span->type = Type::SQL;
            $span->meta = PDOIntegration::storeConnectionParams($this, $args);
        });
        \DDTrace\trace_method('PDO', 'exec', function (SpanData $span, array $args, $retval) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $span->name = 'PDO.exec';
            $span->service = 'pdo';
            $span->type = Type::SQL;
            $span->resource = $args[0];
            if (is_numeric($retval)) {
                $span->meta = array('db.rowcount' => $retval);
            }
            PDOIntegration::setConnectionTags($this, $span);
            $integration->addTraceAnalyticsIfEnabled($span);
            PDOIntegration::detectError($this, $span);
        });
        \DDTrace\trace_method('PDO', 'query', function (SpanData $span, array $args, $retval) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $span->name = 'PDO.query';
            $span->service = 'pdo';
            $span->type = Type::SQL;
            $span->resource = $args[0];
            if ($retval instanceof \PDOStatement) {
                $span->meta = array('db.rowcount' => $retval->rowCount());
                PDOIntegration::storeStatementFromConnection($this, $retval);
            }
            PDOIntegration::setConnectionTags($this, $span);
            $integration->addTraceAnalyticsIfEnabled($span);
            PDOIntegration::detectError($this, $span);
        });
        \DDTrace\trace_method('PDO', 'commit', function (SpanData $span) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $span->name = $span->resource = 'PDO.commit';
            $span->service = 'pdo';
            $span->type = Type::SQL;
            PDOIntegration::setConnectionTags($this, $span);
        });
        \DDTrace\trace_method('PDO', 'prepare', function (SpanData $span, array $args, $retval) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $span->name = 'PDO.prepare';
            $span->service = 'pdo';
            $span->type = Type::SQL;
            $span->resource = $args[0];
            PDOIntegration::setConnectionTags($this, $span);
            PDOIntegration::storeStatementFromConnection($this, $retval);
        });
        \DDTrace\trace_method('PDOStatement', 'execute', function (SpanData $span, array $args, $retval) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $span->name = 'PDOStatement.execute';
            $span->service = 'pdo';
            $span->type = Type::SQL;
            $span->resource = $this->queryString;
            if ($retval === true) {
                $span->meta = array('db.rowcount' => $this->rowCount());
            }
            PDOIntegration::setStatementTags($this, $span);
            $integration->addTraceAnalyticsIfEnabled($span);
            PDOIntegration::detectError($this, $span);
        });
        return Integration::LOADED;
    }
    public static function detectError($pdoOrStatement, SpanData $span)
    {
        $errorCode = $pdoOrStatement->errorCode();
        if (strlen($errorCode) !== 5) {
            return;
        }
        $class = strtoupper(substr($errorCode, 0, 2));
        if (in_array($class, array('00', '01', 'IM'), true)) {
            return;
        }
        $errorInfo = $pdoOrStatement->errorInfo();
        $span->meta[Tag::ERROR_MSG] = 'SQL error: ' . $errorCode . '. Driver error: ' . $errorInfo[1];
        $span->meta[Tag::ERROR_TYPE] = get_class($pdoOrStatement) . ' error';
    }
    private static function parseDsn($dsn)
    {
        $engine = substr($dsn, 0, strpos($dsn, ':'));
        $tags = array('db.engine' => $engine);
        $valStrings = explode(';', substr($dsn, strlen($engine) + 1));
        foreach ($valStrings as $valString) {
            if (!strpos($valString, '=')) {
                continue;
            }
            list($key, $value) = explode('=', $valString);
            switch ($key) {
                case 'charset':
                    $tags['db.charset'] = $value;
                    break;
                case 'dbname':
                    $tags['db.name'] = $value;
                    break;
                case 'host':
                    $tags[Tag::TARGET_HOST] = $value;
                    break;
                case 'port':
                    $tags[Tag::TARGET_PORT] = $value;
                    break;
            }
        }
        return $tags;
    }
    public static function storeConnectionParams($pdo, array $constructorArgs)
    {
        $tags = self::parseDsn($constructorArgs[0]);
        if (isset($constructorArgs[1])) {
            $tags['db.user'] = $constructorArgs[1];
        }
        self::$connections[spl_object_hash($pdo)] = $tags;
        return $tags;
    }
    public static function storeStatementFromConnection($pdo, $stmt)
    {
        if (!$stmt instanceof \PDOStatement) {
            return;
        }
        $pdoHash = spl_object_hash($pdo);
        if (isset(self::$connections[$pdoHash])) {
            self::$statements[spl_object_hash($stmt)] = $pdoHash;
        }
    }
    public static function setConnectionTags($pdo, SpanData $span)
    {
        $hash = spl_object_hash($pdo);
        if (!isset(self::$connections[$hash])) {
            return;
        }
        foreach (self::$connections[$hash] as $tag => $value) {
            $span->meta[$tag] = $value;
        }
    }
    public static function setStatementTags($stmt, SpanData $span)
    {
        $stmtHash = spl_object_hash($stmt);
        if (!isset(self::$statements[$stmtHash])) {
            return;
        }
        if (!isset(self::$connections[self::$statements[$stmtHash]])) {
            return;
        }
        foreach (self::$connections[self::$statements[$stmtHash]] as $tag => $value) {
            $span->meta[$tag] = $value;
        }
    }
}
}

namespace DDTrace\Integrations\PHPRedis {
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
class PHPRedisIntegration extends Integration
{
    const NAME = 'phpredis';
    const NOT_SET = '__DD_NOT_SET__';
    const CMD_MAX_LEN = 1000;
    const VALUE_TOO_LONG_MARK = '...';
    const VALUE_MAX_LEN = 100;
    const VALUE_PLACEHOLDER = '?';
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        $traceConnectOpen = function (SpanData $span, $args) {
            PHPRedisIntegration::enrichSpan($span);
            $span->meta[Tag::TARGET_HOST] = isset($args[0]) && \is_string($args[0]) ? $args[0] : '127.0.0.1';
            $span->meta[Tag::TARGET_PORT] = isset($args[1]) && \is_numeric($args[1]) ? $args[1] : 6379;
        };
        \DDTrace\trace_method('Redis', 'connect', $traceConnectOpen);
        \DDTrace\trace_method('Redis', 'pconnect', $traceConnectOpen);
        \DDTrace\trace_method('Redis', 'open', $traceConnectOpen);
        \DDTrace\trace_method('Redis', 'popen', $traceConnectOpen);
        self::traceMethodNoArgs('close');
        self::traceMethodNoArgs('auth');
        self::traceMethodNoArgs('ping');
        self::traceMethodNoArgs('echo');
        self::traceMethodNoArgs('bgRewriteAOF');
        self::traceMethodNoArgs('bgSave');
        self::traceMethodNoArgs('flushAll');
        self::traceMethodNoArgs('flushDb');
        self::traceMethodNoArgs('save');
        self::traceMethodNoArgs('restore');
        \DDTrace\trace_method('Redis', 'select', function (SpanData $span, $args) {
            PHPRedisIntegration::enrichSpan($span);
            if (isset($args[0]) && \is_numeric($args[0])) {
                $span->meta['db.index'] = $args[0];
            }
        });
        self::traceMethodAsCommand('swapdb');
        self::traceMethodAsCommand('append');
        self::traceMethodAsCommand('decr');
        self::traceMethodAsCommand('decrBy');
        self::traceMethodAsCommand('get');
        self::traceMethodAsCommand('getBit');
        self::traceMethodAsCommand('getRange');
        self::traceMethodAsCommand('getSet');
        self::traceMethodAsCommand('incr');
        self::traceMethodAsCommand('incrBy');
        self::traceMethodAsCommand('incrByFloat');
        self::traceMethodAsCommand('mGet');
        self::traceMethodAsCommand('getMultiple');
        self::traceMethodAsCommand('mSet');
        self::traceMethodAsCommand('mSetNx');
        self::traceMethodAsCommand('set');
        self::traceMethodAsCommand('setBit');
        self::traceMethodAsCommand('setEx');
        self::traceMethodAsCommand('pSetEx');
        self::traceMethodAsCommand('setNx');
        self::traceMethodAsCommand('setRange');
        self::traceMethodAsCommand('strLen');
        self::traceMethodAsCommand('del');
        self::traceMethodAsCommand('delete');
        self::traceMethodAsCommand('dump');
        self::traceMethodAsCommand('exists');
        self::traceMethodAsCommand('keys');
        self::traceMethodAsCommand('getKeys');
        self::traceMethodAsCommand('scan');
        self::traceMethodAsCommand('migrate');
        self::traceMethodAsCommand('move');
        self::traceMethodAsCommand('persist');
        self::traceMethodAsCommand('rename');
        self::traceMethodAsCommand('object');
        self::traceMethodAsCommand('randomKey');
        self::traceMethodAsCommand('renameKey');
        self::traceMethodAsCommand('renameNx');
        self::traceMethodAsCommand('type');
        self::traceMethodAsCommand('sort');
        self::traceMethodAsCommand('expire');
        self::traceMethodAsCommand('expireAt');
        self::traceMethodAsCommand('setTimeout');
        self::traceMethodAsCommand('pexpire');
        self::traceMethodAsCommand('pexpireAt');
        self::traceMethodAsCommand('ttl');
        self::traceMethodAsCommand('pttl');
        self::traceMethodAsCommand('hDel');
        self::traceMethodAsCommand('hExists');
        self::traceMethodAsCommand('hGet');
        self::traceMethodAsCommand('hGetAll');
        self::traceMethodAsCommand('hIncrBy');
        self::traceMethodAsCommand('hIncrByFloat');
        self::traceMethodAsCommand('hKeys');
        self::traceMethodAsCommand('hLen');
        self::traceMethodAsCommand('hMGet');
        self::traceMethodAsCommand('hMSet');
        self::traceMethodAsCommand('hSet');
        self::traceMethodAsCommand('hSetNx');
        self::traceMethodAsCommand('hVals');
        self::traceMethodAsCommand('hScan');
        self::traceMethodAsCommand('hStrLen');
        self::traceMethodAsCommand('blPop');
        self::traceMethodAsCommand('brPop');
        self::traceMethodAsCommand('bRPopLPush');
        self::traceMethodAsCommand('lGet');
        self::traceMethodAsCommand('lGetRange');
        self::traceMethodAsCommand('lIndex');
        self::traceMethodAsCommand('lInsert');
        self::traceMethodAsCommand('listTrim');
        self::traceMethodAsCommand('lLen');
        self::traceMethodAsCommand('lPop');
        self::traceMethodAsCommand('lPush');
        self::traceMethodAsCommand('lPushx');
        self::traceMethodAsCommand('lRange');
        self::traceMethodAsCommand('lRem');
        self::traceMethodAsCommand('lRemove');
        self::traceMethodAsCommand('lSet');
        self::traceMethodAsCommand('lSize');
        self::traceMethodAsCommand('lTrim');
        self::traceMethodAsCommand('rPop');
        self::traceMethodAsCommand('rPopLPush');
        self::traceMethodAsCommand('rPush');
        self::traceMethodAsCommand('rPushX');
        self::traceMethodAsCommand('sAdd');
        self::traceMethodAsCommand('sCard');
        self::traceMethodAsCommand('sContains');
        self::traceMethodAsCommand('sDiff');
        self::traceMethodAsCommand('sDiffStore');
        self::traceMethodAsCommand('sGetMembers');
        self::traceMethodAsCommand('sInter');
        self::traceMethodAsCommand('sInterStore');
        self::traceMethodAsCommand('sIsMember');
        self::traceMethodAsCommand('sMembers');
        self::traceMethodAsCommand('sMove');
        self::traceMethodAsCommand('sPop');
        self::traceMethodAsCommand('sRandMember');
        self::traceMethodAsCommand('sRem');
        self::traceMethodAsCommand('sRemove');
        self::traceMethodAsCommand('sScan');
        self::traceMethodAsCommand('sSize');
        self::traceMethodAsCommand('sUnion');
        self::traceMethodAsCommand('sUnionStore');
        self::traceMethodAsCommand('zAdd');
        self::traceMethodAsCommand('zCard');
        self::traceMethodAsCommand('zSize');
        self::traceMethodAsCommand('zCount');
        self::traceMethodAsCommand('zIncrBy');
        self::traceMethodAsCommand('zInter');
        self::traceMethodAsCommand('zPopMax');
        self::traceMethodAsCommand('zPopMin');
        self::traceMethodAsCommand('zRange');
        self::traceMethodAsCommand('zRangeByScore');
        self::traceMethodAsCommand('zRevRangeByScore');
        self::traceMethodAsCommand('zRangeByLex');
        self::traceMethodAsCommand('zRank');
        self::traceMethodAsCommand('zRevRank');
        self::traceMethodAsCommand('zRem');
        self::traceMethodAsCommand('zRemove');
        self::traceMethodAsCommand('zDelete');
        self::traceMethodAsCommand('zRemRangeByRank');
        self::traceMethodAsCommand('zDeleteRangeByRank');
        self::traceMethodAsCommand('zRemRangeByScore');
        self::traceMethodAsCommand('zDeleteRangeByScore');
        self::traceMethodAsCommand('zRemoveRangeByScore');
        self::traceMethodAsCommand('zRevRange');
        self::traceMethodAsCommand('zScore');
        self::traceMethodAsCommand('zUnion');
        self::traceMethodAsCommand('zunionstore');
        self::traceMethodAsCommand('zScan');
        self::traceMethodAsCommand('publish');
        self::traceMethodAsCommand('multi');
        self::traceMethodAsCommand('exec');
        self::traceMethodAsCommand('rawCommand');
        self::traceMethodAsCommand('eval');
        self::traceMethodAsCommand('evalSha');
        self::traceMethodAsCommand('script');
        self::traceMethodAsCommand('getLastError');
        self::traceMethodAsCommand('clearLastError');
        self::traceMethodAsCommand('_unserialize');
        self::traceMethodAsCommand('_serialize');
        self::traceMethodAsCommand('isConnected');
        self::traceMethodAsCommand('getHost');
        self::traceMethodAsCommand('getPort');
        self::traceMethodAsCommand('getDbNum');
        self::traceMethodAsCommand('getTimeout');
        self::traceMethodAsCommand('getReadTimeout');
        self::traceMethodAsCommand('geoAdd');
        self::traceMethodAsCommand('geoHash');
        self::traceMethodAsCommand('geoPos');
        self::traceMethodAsCommand('geoDist');
        self::traceMethodAsCommand('geoRadius');
        self::traceMethodAsCommand('geoRadiusByMember');
        self::traceMethodAsCommand('xAck');
        self::traceMethodAsCommand('xAdd');
        self::traceMethodAsCommand('xClaim');
        self::traceMethodAsCommand('xDel');
        self::traceMethodAsCommand('xGroup');
        self::traceMethodAsCommand('xInfo');
        self::traceMethodAsCommand('xLen');
        self::traceMethodAsCommand('xPending');
        self::traceMethodAsCommand('xRange');
        self::traceMethodAsCommand('xRead');
        self::traceMethodAsCommand('xReadGroup');
        self::traceMethodAsCommand('xRevRange');
        self::traceMethodAsCommand('xTrim');
        return Integration::LOADED;
    }
    public static function enrichSpan(SpanData $span, $method = null)
    {
        $span->service = 'phpredis';
        $span->type = Type::REDIS;
        if (null !== $method) {
            $span->name = $span->resource = "Redis.{$method}";
        }
    }
    public static function traceMethodNoArgs($method)
    {
        \DDTrace\trace_method('Redis', $method, function (SpanData $span, $args) use($method) {
            PHPRedisIntegration::enrichSpan($span, $method);
        });
    }
    public static function traceMethodAsCommand($method)
    {
        \DDTrace\trace_method('Redis', $method, function (SpanData $span, $args) use($method) {
            PHPRedisIntegration::enrichSpan($span, $method);
            $normalizedArgs = PHPRedisIntegration::normalizeArgs($args);
            $span->meta[Tag::REDIS_RAW_COMMAND] = empty($normalizedArgs) ? $method : $method . ' ' . $normalizedArgs;
        });
    }
    public static function normalizeArgs($args)
    {
        $rawCommandParts = array();
        $totalArgsLength = 0;
        foreach ($args as $arg) {
            if ($totalArgsLength > self::CMD_MAX_LEN) {
                break;
            }
            $partValue = null;
            if (\is_string($arg)) {
                $partValue = $arg;
            } elseif (\is_numeric($arg)) {
                $partValue = (string) $arg;
            } elseif (\is_null($arg)) {
                $partValue = 'null';
            } elseif (\is_bool($arg)) {
                $partValue = $args ? 'true' : false;
            } elseif (\is_array($arg)) {
                if (empty($arg)) {
                    continue;
                }
                $expectedNextIndex = 0;
                foreach ($arg as $key => $val) {
                    if ($key !== $expectedNextIndex++) {
                        $rawCommandParts[] = $key;
                    }
                    $rawCommandParts[] = self::normalizeArgs(array($val));
                }
                continue;
            } else {
                $rawCommandParts[] = self::VALUE_PLACEHOLDER;
                continue;
            }
            $len = strlen($partValue);
            if ($len > self::VALUE_MAX_LEN) {
                $partValue = substr($partValue, 0, self::VALUE_MAX_LEN) . self::VALUE_TOO_LONG_MARK;
            }
            if ($totalArgsLength + $len > self::CMD_MAX_LEN) {
                $partValue = substr($partValue, 0, self::CMD_MAX_LEN) . self::VALUE_TOO_LONG_MARK;
            }
            $rawCommandParts[] = $partValue;
            $totalArgsLength += strlen($partValue);
        }
        return \implode(' ', $rawCommandParts);
    }
}
}

namespace DDTrace\Integrations\Predis {
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
use DDTrace\Util\Versions;
use Predis\Configuration\OptionsInterface;
use Predis\Connection\AbstractConnection;
const VALUE_PLACEHOLDER = '?';
const VALUE_MAX_LEN = 100;
const VALUE_TOO_LONG_MARK = '...';
const CMD_MAX_LEN = 1000;
class PredisIntegration extends Integration
{
    const NAME = 'predis';
    private static $connections = array();
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        $integration = $this;
        \DDTrace\trace_method('Predis\\Client', '__construct', function (SpanData $span, $args) {
            $span->name = 'Predis.Client.__construct';
            $span->type = Type::CACHE;
            $span->service = 'redis';
            $span->resource = 'Predis.Client.__construct';
            PredisIntegration::storeConnectionParams($this, $args);
            PredisIntegration::setConnectionTags($this, $span);
        });
        \DDTrace\trace_method('Predis\\Client', 'connect', function (SpanData $span, $args) {
            $span->name = 'Predis.Client.connect';
            $span->type = Type::CACHE;
            $span->service = 'redis';
            $span->resource = 'Predis.Client.connect';
            PredisIntegration::setConnectionTags($this, $span);
        });
        \DDTrace\trace_method('Predis\\Client', 'executeCommand', function (SpanData $span, $args) use($integration) {
            $span->name = 'Predis.Client.executeCommand';
            $span->type = Type::CACHE;
            $span->service = 'redis';
            PredisIntegration::setConnectionTags($this, $span);
            $integration->addTraceAnalyticsIfEnabled($span);
            $span->resource = 'Predis.Client.executeCommand';
            if (\count($args) == 0) {
                return;
            }
            $command = $args[0];
            $arguments = $command->getArguments();
            array_unshift($arguments, $command->getId());
            $span->meta['redis.args_length'] = count($arguments);
            $query = PredisIntegration::formatArguments($arguments);
            $span->resource = $query;
            $span->meta['redis.raw_command'] = $query;
        });
        \DDTrace\trace_method('Predis\\Client', 'executeRaw', function (SpanData $span, $args) use($integration) {
            $span->name = 'Predis.Client.executeRaw';
            $span->type = Type::CACHE;
            $span->service = 'redis';
            PredisIntegration::setConnectionTags($this, $span);
            $integration->addTraceAnalyticsIfEnabled($span);
            $span->resource = 'Predis.Client.executeRaw';
            if (\count($args) == 0) {
                return;
            }
            $arguments = $args[0];
            $query = PredisIntegration::formatArguments($arguments);
            $span->resource = $query;
            $span->meta['redis.args_length'] = count($arguments);
            $span->meta['redis.raw_command'] = $query;
        });
        if (Versions::phpVersionMatches('5')) {
            \DDTrace\trace_method('Predis\\Pipeline\\Pipeline', 'executePipeline', function (SpanData $span, $args) {
                $span->name = 'Predis.Pipeline.executePipeline';
                $span->resource = $span->name;
                $span->type = Type::CACHE;
                $span->service = 'redis';
                PredisIntegration::setConnectionTags($this, $span);
            });
        } else {
            \DDTrace\trace_method('Predis\\Pipeline\\Pipeline', 'executePipeline', array('prehook' => function (SpanData $span, $args) {
                $span->name = 'Predis.Pipeline.executePipeline';
                $span->resource = $span->name;
                $span->type = Type::CACHE;
                $span->service = 'redis';
                PredisIntegration::setConnectionTags($this, $span);
                if (\count($args) < 2) {
                    return;
                }
                $commands = $args[1];
                $span->meta['redis.pipeline_length'] = count($commands);
            }));
        }
        return Integration::LOADED;
    }
    public static function storeConnectionParams($predis, $args)
    {
        $tags = array();
        $connection = $predis->getConnection();
        if ($connection instanceof AbstractConnection) {
            $connectionParameters = $connection->getParameters();
            $tags[Tag::TARGET_HOST] = $connectionParameters->host;
            $tags[Tag::TARGET_PORT] = $connectionParameters->port;
        }
        if (isset($args[1])) {
            $options = $args[1];
            if (is_array($options)) {
                $parameters = isset($options['parameters']) ? $options['parameters'] : array();
            } elseif ($options instanceof OptionsInterface) {
                $parameters = $options->__get('parameters') ?: array();
            }
            if (is_array($parameters) && isset($parameters['database'])) {
                $tags['out.redis_db'] = $parameters['database'];
            }
        }
        self::$connections[spl_object_hash($predis)] = $tags;
    }
    public static function setConnectionTags($predis, SpanData $span)
    {
        $hash = spl_object_hash($predis);
        if (!isset(self::$connections[$hash])) {
            return;
        }
        foreach (self::$connections[$hash] as $tag => $value) {
            $span->meta[$tag] = $value;
        }
    }
    public static function formatArguments($arguments)
    {
        $len = 0;
        $out = array();
        foreach ($arguments as $argument) {
            if (strpos($argument, ' ') !== false) {
                continue;
            }
            $cmd = (string) $argument;
            if (strlen($cmd) > VALUE_MAX_LEN) {
                $cmd = substr($cmd, 0, VALUE_MAX_LEN) . VALUE_TOO_LONG_MARK;
            }
            if ($len + strlen($cmd) > CMD_MAX_LEN) {
                $prefix = substr($cmd, 0, CMD_MAX_LEN - $len);
                $out[] = $prefix . VALUE_TOO_LONG_MARK;
                break;
            }
            $out[] = $cmd;
            $len += strlen($cmd);
        }
        return implode(' ', $out);
    }
}
}

namespace DDTrace\Integrations\Eloquent {
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
class EloquentIntegration extends Integration
{
    const NAME = 'eloquent';
    private $appName;
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        $integration = $this;
        \DDTrace\trace_method('Illuminate\\Database\\Eloquent\\Builder', 'getModels', function (SpanData $span) use($integration) {
            $span->name = 'eloquent.get';
            $sql = $this->getQuery()->toSql();
            $span->resource = $sql;
            $span->meta[Tag::DB_STATEMENT] = $sql;
            $integration->setCommonValues($span);
        });
        \DDTrace\trace_method('Illuminate\\Database\\Eloquent\\Model', 'performInsert', function (SpanData $span) use($integration) {
            $span->name = 'eloquent.insert';
            $span->resource = get_class($this);
            $integration->setCommonValues($span);
        });
        \DDTrace\trace_method('Illuminate\\Database\\Eloquent\\Model', 'performUpdate', function (SpanData $span) use($integration) {
            $span->name = 'eloquent.update';
            $span->resource = get_class($this);
            $integration->setCommonValues($span);
        });
        \DDTrace\trace_method('Illuminate\\Database\\Eloquent\\Model', 'delete', function (SpanData $span) use($integration) {
            $span->name = 'eloquent.delete';
            $span->resource = get_class($this);
            $integration->setCommonValues($span);
        });
        \DDTrace\trace_method('Illuminate\\Database\\Eloquent\\Model', 'destroy', function (SpanData $span) use($integration) {
            $span->name = 'eloquent.destroy';
            $span->resource = get_called_class();
            $integration->setCommonValues($span);
        });
        \DDTrace\trace_method('Illuminate\\Database\\Eloquent\\Model', 'refresh', function (SpanData $span) use($integration) {
            $span->name = 'eloquent.refresh';
            $span->resource = get_class($this);
            $integration->setCommonValues($span);
        });
        return Integration::LOADED;
    }
    public function setCommonValues(SpanData $span)
    {
        $span->type = Type::SQL;
        $span->service = $this->getAppName();
    }
    public function getAppName()
    {
        if (null !== $this->appName) {
            return $this->appName;
        }
        $name = \ddtrace_config_app_name();
        if (empty($name) && is_callable('config')) {
            $name = config('app.name');
        }
        $this->appName = $name ?: 'laravel';
        return $this->appName;
    }
}
}

namespace DDTrace\Integrations\Memcached {
use DDTrace\Integrations\Integration;
use DDTrace\Obfuscation;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
class MemcachedIntegration extends Integration
{
    const NAME = 'memcached';
    private static $instance;
    public static function getInstance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        if (!extension_loaded('memcached')) {
            return Integration::NOT_AVAILABLE;
        }
        $integration = $this;
        $this->traceCommand('add');
        $this->traceCommandByKey('addByKey');
        $this->traceCommand('append');
        $this->traceCommandByKey('appendByKey');
        $this->traceCommand('decrement');
        $this->traceCommandByKey('decrementByKey');
        $this->traceCommand('delete');
        $this->traceMulti('deleteMulti');
        $this->traceCommandByKey('deleteByKey');
        $this->traceMultiByKey('deleteMultiByKey');
        $this->traceCommand('get');
        $this->traceMulti('getMulti');
        $this->traceCommandByKey('getByKey');
        $this->traceMultiByKey('getMultiByKey');
        $this->traceCommand('set');
        $this->traceMulti('setMulti');
        $this->traceCommandByKey('setByKey');
        $this->traceMultiByKey('setMultiByKey');
        $this->traceCommand('increment');
        $this->traceCommandByKey('incrementByKey');
        $this->traceCommand('prepend');
        $this->traceCommandByKey('prependByKey');
        $this->traceCommand('replace');
        $this->traceCommandByKey('replaceByKey');
        $this->traceCommand('touch');
        $this->traceCommandByKey('touchByKey');
        \DDTrace\trace_method('Memcached', 'flush', function (SpanData $span) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->setCommonData($span, 'flush');
        });
        \DDTrace\trace_method('Memcached', 'cas', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->setCommonData($span, 'cas');
            $span->meta['memcached.cas_token'] = $args[0];
            $span->meta['memcached.query'] = 'cas ?';
            $integration->setServerTags($span, $this);
        });
        \DDTrace\trace_method('Memcached', 'casByKey', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->setCommonData($span, 'casByKey');
            $span->meta['memcached.cas_token'] = $args[0];
            $span->meta['memcached.query'] = 'casByKey ?';
            $span->meta['memcached.server_key'] = $args[1];
            $integration->setServerTags($span, $this);
        });
        return Integration::LOADED;
    }
    public function traceCommand($command)
    {
        $integration = $this;
        \DDTrace\trace_method('Memcached', $command, function (SpanData $span, $args) use($integration, $command) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->setCommonData($span, $command);
            if (!is_array($args[0])) {
                $integration->setServerTags($span, $this);
                $span->meta['memcached.query'] = $command . ' ' . Obfuscation::toObfuscatedString($args[0]);
            }
            $integration->markForTraceAnalytics($span, $command);
        });
    }
    public function traceCommandByKey($command)
    {
        $integration = $this;
        \DDTrace\trace_method('Memcached', $command, function (SpanData $span, $args) use($integration, $command) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->setCommonData($span, $command);
            if (!is_array($args[0])) {
                $integration->setServerTags($span, $this);
                $span->meta['memcached.query'] = $command . ' ' . Obfuscation::toObfuscatedString($args[0]);
                $span->meta['memcached.server_key'] = $args[0];
            }
            $integration->markForTraceAnalytics($span, $command);
        });
    }
    public function traceMulti($command)
    {
        $integration = $this;
        \DDTrace\trace_method('Memcached', $command, function (SpanData $span, $args) use($integration, $command) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->setCommonData($span, $command);
            if (!is_array($args[0])) {
                $integration->setServerTags($span, $this);
            }
            $span->meta['memcached.query'] = $command . ' ' . Obfuscation::toObfuscatedString($args[0], ',');
            $integration->markForTraceAnalytics($span, $command);
        });
    }
    public function traceMultiByKey($command)
    {
        $integration = $this;
        \DDTrace\trace_method('Memcached', $command, function (SpanData $span, $args) use($integration, $command) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->setCommonData($span, $command);
            $span->meta['memcached.server_key'] = $args[0];
            $integration->setServerTags($span, $this);
            $query = "{$command} " . Obfuscation::toObfuscatedString($args[1], ',');
            $span->meta['memcached.query'] = $query;
            $integration->markForTraceAnalytics($span, $command);
        });
    }
    public function setCommonData(SpanData $span, $command)
    {
        $span->name = "Memcached.{$command}";
        $span->type = Type::MEMCACHED;
        $span->service = 'memcached';
        $span->resource = $command;
        $span->meta['memcached.command'] = $command;
    }
    public function setServerTags(SpanData $span, \Memcached $memcached)
    {
        $servers = $memcached->getServerList();
        if (isset($servers[0]['host'], $servers[0]['port'])) {
            $span->meta[Tag::TARGET_HOST] = $servers[0]['host'];
            $span->meta[Tag::TARGET_PORT] = $servers[0]['port'];
        }
    }
    public function markForTraceAnalytics(SpanData $span, $command)
    {
        $commandsForAnalytics = array('add', 'addByKey', 'delete', 'deleteByKey', 'get', 'getByKey', 'set', 'setByKey');
        if (in_array($command, $commandsForAnalytics)) {
            $this->addTraceAnalyticsIfEnabled($span);
        }
    }
}
}

namespace DDTrace\Integrations\Curl {
use DDTrace\Http\Urls;
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
function addSpanDataTagFromCurlInfo($span, &$info, $tagName, $curlInfoOpt)
{
    if (isset($info[$curlInfoOpt]) && !\trim($info[$curlInfoOpt]) !== '') {
        $span->meta[$tagName] = $info[$curlInfoOpt];
        unset($info[$curlInfoOpt]);
    }
}
final class CurlIntegration extends Integration
{
    const NAME = 'curl';
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        if (!extension_loaded('curl')) {
            return Integration::NOT_AVAILABLE;
        }
        if (!Integration::shouldLoad(self::NAME)) {
            return Integration::NOT_LOADED;
        }
        $integration = $this;
        \DDTrace\trace_function('curl_exec', array('instrument_when_limited' => 0, 'posthook' => function (SpanData $span, $args, $retval) use($integration) {
            $span->name = $span->resource = 'curl_exec';
            $span->type = Type::HTTP_CLIENT;
            $span->service = 'curl';
            $integration->addTraceAnalyticsIfEnabled($span);
            if (!isset($args[0])) {
                return;
            }
            $ch = $args[0];
            if (isset($retval) && $retval === false) {
                $span->meta[Tag::ERROR_MSG] = \curl_error($ch);
                $span->meta[Tag::ERROR_TYPE] = 'curl error';
            }
            $info = \curl_getinfo($ch);
            $sanitizedUrl = Urls::sanitize($info['url']);
            $normalizedPath = \DDtrace\Private_\util_uri_normalize_outgoing_path($info['url']);
            unset($info['url']);
            if (\ddtrace_config_http_client_split_by_domain_enabled()) {
                $span->service = Urls::hostnameForTag($sanitizedUrl);
            }
            $span->resource = $normalizedPath;
            $span->meta[Tag::HTTP_URL] = $sanitizedUrl;
            addSpanDataTagFromCurlInfo($span, $info, Tag::HTTP_STATUS_CODE, 'http_code');
            $span->meta['duration'] = $info['total_time'] * 1000000000;
            unset($info['duration']);
            addSpanDataTagFromCurlInfo($span, $info, 'network.client.ip', 'local_ip');
            addSpanDataTagFromCurlInfo($span, $info, 'network.client.port', 'local_port');
            addSpanDataTagFromCurlInfo($span, $info, 'network.destination.ip', 'primary_ip');
            addSpanDataTagFromCurlInfo($span, $info, 'network.destination.port', 'primary_port');
            addSpanDataTagFromCurlInfo($span, $info, 'network.bytes_read', 'size_download');
            addSpanDataTagFromCurlInfo($span, $info, 'network.bytes_written', 'size_upload');
            foreach ($info as $key => $val) {
                if (\is_scalar($val) && $val !== '') {
                    if (\substr_compare($key, '_time', -5) === 0) {
                        $val *= 1000000000;
                    }
                    $span->meta["curl.{$key}"] = $val;
                }
            }
        }));
        return Integration::LOADED;
    }
}
}

namespace DDTrace\Integrations\Mysqli {
use DDTrace\Util\ObjectKVStore;
class MysqliCommon
{
    public static function extractHostInfo($mysqli)
    {
        if (!isset($mysqli->host_info) || !is_string($mysqli->host_info)) {
            return array();
        }
        $hostInfo = $mysqli->host_info;
        return self::parseHostInfo(substr($hostInfo, 0, strpos($hostInfo, ' ')));
    }
    public static function parseHostInfo($hostString)
    {
        if (empty($hostString) || !is_string($hostString)) {
            return array();
        }
        $parts = explode(':', $hostString);
        $host = $parts[0];
        $port = isset($parts[1]) ? $parts[1] : '3306';
        return array('db.type' => 'mysql', 'out.host' => $host, 'out.port' => $port);
    }
    public static function storeQuery($instance, $query)
    {
        ObjectKVStore::put($instance, 'query', $query);
    }
    public static function retrieveQuery($instance, $fallbackValue)
    {
        return ObjectKVStore::get($instance, 'query', $fallbackValue);
    }
}
}

namespace DDTrace\Integrations\Mysqli {
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Type;
use DDTrace\Util\ObjectKVStore;
class MysqliIntegration extends Integration
{
    const NAME = 'mysqli';
    const DEFAULT_MYSQLI_HOST = 'localhost';
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        if (!extension_loaded('mysqli')) {
            return Integration::NOT_AVAILABLE;
        }
        $integration = $this;
        \DDTrace\trace_function('mysqli_connect', function (SpanData $span, $args, $result) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            list($host) = $args;
            $integration->setDefaultAttributes($span, 'mysqli_connect', 'mysqli_connect');
            $integration->mergeMeta($span, MysqliCommon::parseHostInfo($host ?: self::DEFAULT_MYSQLI_HOST));
            if ($result === false) {
                $integration->trackPotentialError($span);
            }
        });
        $mysqli_constructor = PHP_MAJOR_VERSION > 5 ? '__construct' : 'mysqli';
        \DDTrace\trace_method('mysqli', $mysqli_constructor, function (SpanData $span) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->setDefaultAttributes($span, 'mysqli.__construct', 'mysqli.__construct');
            $integration->trackPotentialError($span);
            try {
                $integration->setConnectionInfo($span, $this);
            } catch (\Exception $ex) {
            }
        });
        \DDTrace\trace_function('mysqli_real_connect', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->setDefaultAttributes($span, 'mysqli_real_connect', 'mysqli_real_connect');
            $integration->trackPotentialError($span);
            if (count($args) > 0) {
                $integration->setConnectionInfo($span, $args[0]);
            }
        });
        \DDTrace\trace_method('mysqli', 'real_connect', function (SpanData $span) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->setDefaultAttributes($span, 'mysqli.real_connect', 'mysqli.real_connect');
            $integration->trackPotentialError($span);
            $integration->setConnectionInfo($span, $this);
        });
        \DDTrace\trace_function('mysqli_query', function (SpanData $span, $args, $result) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            list($mysqli, $query) = $args;
            $integration->setDefaultAttributes($span, 'mysqli_query', $query);
            $integration->addTraceAnalyticsIfEnabled($span);
            $integration->setConnectionInfo($span, $mysqli);
            MysqliCommon::storeQuery($mysqli, $query);
            MysqliCommon::storeQuery($result, $query);
            ObjectKVStore::put($result, 'host_info', MysqliCommon::extractHostInfo($mysqli));
        });
        \DDTrace\trace_function('mysqli_prepare', function (SpanData $span, $args, $retval) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            list($mysqli, $query) = $args;
            $integration->setDefaultAttributes($span, 'mysqli_prepare', $query);
            $integration->setConnectionInfo($span, $mysqli);
            $host_info = MysqliCommon::extractHostInfo($mysqli);
            MysqliCommon::storeQuery($retval, $query);
            ObjectKVStore::put($retval, 'host_info', $host_info);
        });
        \DDTrace\trace_function('mysqli_commit', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            list($mysqli) = $args;
            $resource = MysqliCommon::retrieveQuery($mysqli, 'mysqli_commit');
            $integration->setDefaultAttributes($span, 'mysqli_commit', $resource);
            $integration->setConnectionInfo($span, $mysqli);
            if (isset($args[2])) {
                $span->meta['db.transaction_name'] = $args[2];
            }
        });
        \DDTrace\trace_function('mysqli_stmt_execute', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            list($statement) = $args;
            $resource = MysqliCommon::retrieveQuery($statement, 'mysqli_stmt_execute');
            $integration->setDefaultAttributes($span, 'mysqli_stmt_execute', $resource);
        });
        \DDTrace\trace_function('mysqli_stmt_get_result', function (SpanData $span, $args, $result) {
            list($statement) = $args;
            $resource = MysqliCommon::retrieveQuery($statement, 'mysqli_stmt_get_result');
            MysqliCommon::storeQuery($result, $resource);
            ObjectKVStore::propagate($statement, $result, 'host_info');
            return false;
        });
        \DDTrace\trace_method('mysqli', 'query', function (SpanData $span, $args, $result) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            list($query) = $args;
            $integration->setDefaultAttributes($span, 'mysqli.query', $query);
            $integration->addTraceAnalyticsIfEnabled($span);
            $integration->setConnectionInfo($span, $this);
            MysqliCommon::storeQuery($this, $query);
            ObjectKVStore::put($result, 'query', $query);
            $host_info = MysqliCommon::extractHostInfo($this);
            ObjectKVStore::put($result, 'host_info', $host_info);
            ObjectKVStore::put($result, 'query', $query);
        });
        \DDTrace\trace_method('mysqli', 'prepare', function (SpanData $span, $args, $retval) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            list($query) = $args;
            $integration->setDefaultAttributes($span, 'mysqli.prepare', $query);
            $integration->setConnectionInfo($span, $this);
            $host_info = MysqliCommon::extractHostInfo($this);
            ObjectKVStore::put($retval, 'host_info', $host_info);
            MysqliCommon::storeQuery($retval, $query);
        });
        \DDTrace\trace_method('mysqli', 'commit', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $resource = MysqliCommon::retrieveQuery($this, 'mysqli.commit');
            $integration->setDefaultAttributes($span, 'mysqli.commit', $resource);
            $integration->setConnectionInfo($span, $this);
            if (isset($args[1])) {
                $span->meta['db.transaction_name'] = $args[1];
            }
        });
        \DDTrace\trace_method('mysqli_stmt', 'execute', function (SpanData $span) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $resource = MysqliCommon::retrieveQuery($this, 'mysqli_stmt.execute');
            $integration->setDefaultAttributes($span, 'mysqli_stmt.execute', $resource);
            $integration->addTraceAnalyticsIfEnabled($span);
        });
        \DDTrace\trace_method('mysqli_stmt', 'get_result', function (SpanData $span, $a, $result) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $resource = MysqliCommon::retrieveQuery($this, 'mysqli_stmt.get_result');
            $integration->setDefaultAttributes($span, 'mysqli_stmt.get_result', $resource);
            $integration->setConnectionInfo($span, $this);
            ObjectKVStore::propagate($this, $result, 'host_info');
            ObjectKVStore::put($result, 'query', $resource);
        });
        return Integration::LOADED;
    }
    public function setDefaultAttributes(SpanData $span, $name, $resource)
    {
        $span->name = $name;
        $span->resource = $resource;
        $span->type = Type::SQL;
        $span->service = 'mysqli';
    }
    public function setConnectionInfo(SpanData $span, $mysqli)
    {
        $hostInfo = MysqliCommon::extractHostInfo($mysqli);
        foreach ($hostInfo as $tagName => $value) {
            $span->meta[$tagName] = $value;
        }
    }
    public function trackPotentialError(SpanData $span)
    {
        $errorCode = mysqli_connect_errno();
        if ($errorCode > 0) {
            $this->setError($span, new \Exception(mysqli_connect_error()));
        }
    }
}
}

namespace DDTrace\Integrations\Mongo {
use DDTrace\Integrations\Integration;
use DDTrace\Obfuscation;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
use DDTrace\Util\Versions;
class MongoIntegration extends Integration
{
    const NAME = 'mongo';
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        if (!extension_loaded('mongo') || Versions::phpVersionMatches('5.4')) {
            return Integration::NOT_AVAILABLE;
        }
        $integration = $this;
        \DDTrace\trace_method('MongoClient', '__construct', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoClient', '__construct');
            if (isset($args[0])) {
                $span->meta[Tag::MONGODB_SERVER] = Obfuscation::dsn($args[0]);
                $dbName = MongoIntegration::extractDatabaseNameFromDsn($args[0]);
                if (null !== $dbName) {
                    $span->meta[Tag::MONGODB_DATABASE] = $dbName;
                }
            }
            if (isset($args[1]['db'])) {
                $span->meta[Tag::MONGODB_DATABASE] = $args[1]['db'];
            }
        });
        \DDTrace\trace_method('MongoClient', 'selectCollection', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoClient', 'selectCollection');
            if (isset($args[0])) {
                $span->meta[Tag::MONGODB_DATABASE] = $args[0];
            }
            if (isset($args[1])) {
                $span->meta[Tag::MONGODB_COLLECTION] = $args[1];
            }
        });
        \DDTrace\trace_method('MongoClient', 'selectDB', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoClient', 'selectDB');
            if (isset($args[0])) {
                $span->meta[Tag::MONGODB_DATABASE] = $args[0];
            }
        });
        \DDTrace\trace_method('MongoClient', 'setReadPreference', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoClient', 'setReadPreference');
            if (isset($args[0])) {
                $span->meta[Tag::MONGODB_READ_PREFERENCE] = $args[0];
            }
        });
        $this->traceMongoMethod('MongoClient', 'getHosts');
        $this->traceMongoMethod('MongoClient', 'getReadPreference');
        $this->traceMongoMethod('MongoClient', 'getWriteConcern');
        $this->traceMongoMethod('MongoClient', 'listDBs');
        $this->traceMongoMethod('MongoClient', 'setWriteConcern');
        \DDTrace\trace_method('MongoCollection', '__construct', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoCollection', '__construct');
            if (isset($args[0])) {
                $span->meta[Tag::MONGODB_DATABASE] = $args[0];
            }
            if (isset($args[1])) {
                $span->meta[Tag::MONGODB_COLLECTION] = $args[1];
            }
        });
        \DDTrace\trace_method('MongoCollection', 'createDBRef', function (SpanData $span, $args, $return) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoCollection', 'createDBRef');
            if (!is_array($return)) {
                return;
            }
            if (isset($return['$id'])) {
                $span->meta[Tag::MONGODB_BSON_ID] = $return['$id'];
            }
            if (isset($return['$ref'])) {
                $span->meta[Tag::MONGODB_COLLECTION] = $return['$ref'];
            }
        });
        \DDTrace\trace_method('MongoCollection', 'getDBRef', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoCollection', 'getDBRef');
            if (isset($args[0]['$id'])) {
                $span->meta[Tag::MONGODB_BSON_ID] = $args[0]['$id'];
            }
            if (isset($args[0]['$ref'])) {
                $span->meta[Tag::MONGODB_COLLECTION] = $args[0]['$ref'];
            }
        });
        \DDTrace\trace_method('MongoCollection', 'distinct', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoCollection', 'distinct');
            $integration->addTraceAnalyticsIfEnabled($span);
            if (isset($args[1])) {
                $span->meta[Tag::MONGODB_QUERY] = json_encode($args[1]);
            }
        });
        \DDTrace\trace_method('MongoCollection', 'setReadPreference', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoCollection', 'setReadPreference');
            if (isset($args[0])) {
                $span->meta[Tag::MONGODB_READ_PREFERENCE] = $args[0];
            }
        });
        $this->traceMongoQuery('MongoCollection', 'count', false);
        $this->traceMongoQuery('MongoCollection', 'find');
        $this->traceMongoQuery('MongoCollection', 'findAndModify');
        $this->traceMongoQuery('MongoCollection', 'findOne');
        $this->traceMongoQuery('MongoCollection', 'remove', false);
        $this->traceMongoQuery('MongoCollection', 'update');
        $this->traceMongoMethod('MongoCollection', 'aggregate');
        $this->traceMongoMethod('MongoCollection', 'aggregateCursor');
        $this->traceMongoMethod('MongoCollection', 'batchInsert');
        $this->traceMongoMethod('MongoCollection', 'createIndex');
        $this->traceMongoMethod('MongoCollection', 'deleteIndex');
        $this->traceMongoMethod('MongoCollection', 'deleteIndexes');
        $this->traceMongoMethod('MongoCollection', 'drop');
        $this->traceMongoMethod('MongoCollection', 'getIndexInfo');
        $this->traceMongoMethod('MongoCollection', 'getName');
        $this->traceMongoMethod('MongoCollection', 'getReadPreference');
        $this->traceMongoMethod('MongoCollection', 'getWriteConcern');
        $this->traceMongoMethod('MongoCollection', 'group');
        $this->traceMongoMethod('MongoCollection', 'insert');
        $this->traceMongoMethod('MongoCollection', 'parallelCollectionScan');
        $this->traceMongoMethod('MongoCollection', 'save');
        $this->traceMongoMethod('MongoCollection', 'setWriteConcern');
        $this->traceMongoMethod('MongoCollection', 'validate');
        \DDTrace\trace_method('MongoDB', 'setReadPreference', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoDB', 'setReadPreference');
            if (isset($args[0])) {
                $span->meta[Tag::MONGODB_READ_PREFERENCE] = $args[0];
            }
        });
        \DDTrace\trace_method('MongoDB', 'setProfilingLevel', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoDB', 'setProfilingLevel');
            if (isset($args[0])) {
                $span->meta[Tag::MONGODB_PROFILING_LEVEL] = json_encode($args[0]);
            }
        });
        \DDTrace\trace_method('MongoDB', 'command', function (SpanData $span, $args, $return) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoDB', 'command');
            if (isset($args[0]['query'])) {
                $span->meta[Tag::MONGODB_QUERY] = json_encode($args[0]['query']);
            }
            if (isset($args[1]['socketTimeoutMS'])) {
                $span->meta[Tag::MONGODB_TIMEOUT] = $args[1]['socketTimeoutMS'];
            } elseif (isset($args[1]['timeout'])) {
                $span->meta[Tag::MONGODB_TIMEOUT] = $args[1]['timeout'];
            }
        });
        \DDTrace\trace_method('MongoDB', 'createDBRef', function (SpanData $span, $args, $return) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoDB', 'createDBRef');
            if (isset($args[0])) {
                $span->meta[Tag::MONGODB_COLLECTION] = $args[0];
            }
            if (isset($return['$id'])) {
                $span->meta[Tag::MONGODB_BSON_ID] = $return['$id'];
            }
        });
        \DDTrace\trace_method('MongoDB', 'getDBRef', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoDB', 'getDBRef');
            if (isset($args[0]['$ref'])) {
                $span->meta[Tag::MONGODB_COLLECTION] = $args[0]['$ref'];
            }
        });
        \DDTrace\trace_method('MongoDB', 'createCollection', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoDB', 'createCollection');
            if (isset($args[0])) {
                $span->meta[Tag::MONGODB_COLLECTION] = $args[0];
            }
        });
        \DDTrace\trace_method('MongoDB', 'selectCollection', function (SpanData $span, $args) use($integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, 'MongoDB', 'selectCollection');
            if (isset($args[0])) {
                $span->meta[Tag::MONGODB_COLLECTION] = $args[0];
            }
        });
        $this->traceMongoMethod('MongoDB', 'drop');
        $this->traceMongoMethod('MongoDB', 'execute');
        $this->traceMongoMethod('MongoDB', 'getCollectionInfo');
        $this->traceMongoMethod('MongoDB', 'getCollectionNames');
        $this->traceMongoMethod('MongoDB', 'getGridFS');
        $this->traceMongoMethod('MongoDB', 'getProfilingLevel');
        $this->traceMongoMethod('MongoDB', 'getReadPreference');
        $this->traceMongoMethod('MongoDB', 'getWriteConcern');
        $this->traceMongoMethod('MongoDB', 'lastError');
        $this->traceMongoMethod('MongoDB', 'listCollections');
        $this->traceMongoMethod('MongoDB', 'repair');
        $this->traceMongoMethod('MongoDB', 'setWriteConcern');
        return Integration::LOADED;
    }
    public function traceMongoMethod($class, $method)
    {
        $integration = $this;
        \DDTrace\trace_method($class, $method, function (SpanData $span) use($class, $method, $integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, $class, $method);
        });
    }
    public function traceMongoQuery($class, $method, $isTraceAnalithicsCandidate = true)
    {
        $integration = $this;
        \DDTrace\trace_method($class, $method, function (SpanData $span, $args) use($class, $method, $isTraceAnalithicsCandidate, $integration) {
            if (dd_trace_tracer_is_limited()) {
                return false;
            }
            $integration->addSpanDefaultMetadata($span, $class, $method);
            if ($isTraceAnalithicsCandidate) {
                $integration->addTraceAnalyticsIfEnabled($span);
            }
            if (isset($args[0])) {
                $span->meta[Tag::MONGODB_QUERY] = json_encode($args[0]);
            }
        });
    }
    public function addSpanDefaultMetadata(SpanData $span, $class, $method)
    {
        $span->name = $class . '.' . $method;
        $span->resource = $method;
        $span->type = Type::MONGO;
        $span->service = MongoIntegration::NAME;
    }
    public static function extractDatabaseNameFromDsn($dsn)
    {
        $matches = array();
        if (false === preg_match('/^.+\\/\\/.+\\/(.+)$/', $dsn, $matches)) {
            return null;
        }
        return isset($matches[1]) ? $matches[1] : null;
    }
}
}

namespace DDTrace\Integrations\Slim {
use DDTrace\GlobalTracer;
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
use DDTrace\Util\Versions;
use Psr\Http\Message\ServerRequestInterface;
class SlimIntegration extends Integration
{
    const NAME = 'slim';
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        if (\PHP_VERSION_ID < 50500) {
            return Integration::NOT_AVAILABLE;
        }
        $integration = $this;
        $appName = \ddtrace_config_app_name(self::NAME);
        \DDTrace\hook_method('Slim\\App', '__construct', null, function ($app) use($integration, $appName) {
            $majorVersion = substr($app::VERSION, 0, 1);
            if ('3' !== $majorVersion) {
                return;
            }
            $rootSpan = GlobalTracer::get()->getRootScope()->getSpan();
            $integration->addTraceAnalyticsIfEnabledLegacy($rootSpan);
            $rootSpan->overwriteOperationName('slim.request');
            $rootSpan->setTag(Tag::SERVICE_NAME, $appName);
            \DDTrace\hook_method('Slim\\Router', 'lookupRoute', null, function ($router, $scope, $args, $return) use($rootSpan) {
                $route = $return;
                $rootSpan->setTag(Tag::RESOURCE_NAME, $_SERVER['REQUEST_METHOD'] . ' ' . ($route->getName() ?: $route->getPattern()));
            });
            $traceControllers = function (SpanData $span, $args) use($rootSpan, $appName) {
                $callable = $args[0];
                $callableName = '{unknown callable}';
                \is_callable($callable, false, $callableName);
                $rootSpan->setTag('slim.route.controller', $callableName);
                $span->name = 'slim.route.controller';
                $span->resource = $callableName ?: 'controller';
                $span->type = Type::WEB_SERVLET;
                $span->service = $appName;
                $request = $args[1];
                $rootSpan->setTag(Tag::HTTP_URL, (string) $request->getUri());
            };
            \DDTrace\trace_method('Slim\\Handlers\\Strategies\\RequestResponse', '__invoke', array('prehook' => $traceControllers));
            \DDTrace\trace_method('Slim\\Handlers\\Strategies\\RequestResponseArgs', '__invoke', array('prehook' => $traceControllers));
            \DDTrace\trace_method('Slim\\Views\\Twig', 'render', function (SpanData $span, $args) use($appName) {
                $span->name = 'slim.view';
                $span->service = $appName;
                $span->type = Type::WEB_SERVLET;
                $template = $args[1];
                $span->resource = $template;
                $span->meta['slim.view'] = $template;
            });
        });
        return Integration::LOADED;
    }
}
}

namespace DDTrace\Integrations\Symfony {
use DDTrace\Contracts\Span;
use DDTrace\GlobalTracer;
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
use DDTrace\Util\Versions;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\KernelEvents;
class SymfonyIntegration extends Integration
{
    const NAME = 'symfony';
    public $symfonyRequestSpan;
    public $appName;
    public function getName()
    {
        return static::NAME;
    }
    public function requiresExplicitTraceAnalyticsEnabling()
    {
        return false;
    }
    public function init()
    {
        $integration = $this;
        \DDTrace\hook_method('Symfony\\Component\\HttpKernel\\Kernel', '__construct', function () {
            \DDTrace\trace_method('Symfony\\Component\\HttpKernel\\Kernel', 'handle', function (SpanData $span) {
                $span->name = 'symfony.httpkernel.kernel.handle';
                $span->resource = \get_class($this);
                $span->type = Type::WEB_SERVLET;
                $span->service = \ddtrace_config_app_name('symfony');
            });
            \DDTrace\trace_method('Symfony\\Component\\HttpKernel\\Kernel', 'boot', function (SpanData $span) {
                $span->name = 'symfony.httpkernel.kernel.boot';
                $span->resource = \get_class($this);
                $span->type = Type::WEB_SERVLET;
                $span->service = \ddtrace_config_app_name('symfony');
            });
        });
        \DDTrace\hook_method('Symfony\\Component\\HttpKernel\\HttpKernel', '__construct', function () use($integration) {
            $tracer = GlobalTracer::get();
            $scope = $tracer->getRootScope();
            if (!$scope) {
                return;
            }
            $integration->symfonyRequestSpan = $scope->getSpan();
            if (defined('\\Symfony\\Component\\HttpKernel\\Kernel::VERSION') && Versions::versionMatches('2', \Symfony\Component\HttpKernel\Kernel::VERSION)) {
                $integration->loadSymfony2($integration);
                return;
            }
            $integration->loadSymfony($integration);
        });
        return Integration::LOADED;
    }
    public function loadSymfony($integration)
    {
        $integration->appName = \ddtrace_config_app_name('symfony');
        $integration->symfonyRequestSpan->overwriteOperationName('symfony.request');
        $integration->symfonyRequestSpan->setTag(Tag::SERVICE_NAME, $integration->appName);
        $integration->addTraceAnalyticsIfEnabledLegacy($integration->symfonyRequestSpan);
        \DDTrace\trace_method('Symfony\\Component\\HttpKernel\\HttpKernel', 'handle', function (SpanData $span, $args, $response) use($integration) {
            list($request) = $args;
            $span->name = $span->resource = 'symfony.kernel.handle';
            $span->service = $integration->appName;
            $span->type = Type::WEB_SERVLET;
            $integration->symfonyRequestSpan->setTag(Tag::HTTP_METHOD, $request->getMethod());
            $integration->symfonyRequestSpan->setTag(Tag::HTTP_URL, $request->getUriForPath($request->getPathInfo()));
            if (isset($response)) {
                $integration->symfonyRequestSpan->setTag(Tag::HTTP_STATUS_CODE, $response->getStatusCode());
            }
            $route = $request->get('_route');
            if (null !== $route && null !== $request) {
                $integration->symfonyRequestSpan->setTag(Tag::RESOURCE_NAME, $route);
                $integration->symfonyRequestSpan->setTag('symfony.route.name', $route);
            }
        });
        $hookType = PHP_MAJOR_VERSION >= 7 ? 'prehook' : 'posthook';
        \DDTrace\trace_method('Symfony\\Component\\EventDispatcher\\EventDispatcher', 'dispatch', array($hookType => function (SpanData $span, $args) use($integration) {
            if (!isset($args[0])) {
                return false;
            }
            if (\is_object($args[0])) {
                $event = $args[0];
                $eventName = isset($args[1]) && \is_string($args[1]) ? $args[1] : \get_class($event);
            } elseif (\is_string($args[0])) {
                $eventName = $args[0];
                $event = isset($args[1]) && \is_object($args[1]) ? $args[1] : null;
            } else {
                return false;
            }
            if ($eventName === 'kernel.controller' && \method_exists($event, 'getController')) {
                $controller = $event->getController();
                if (!$controller instanceof \Closure) {
                    if (\is_callable($controller, false, $controllerName) && $controllerName !== null) {
                        if (\strpos($controllerName, '::') > 0) {
                            list($class, $method) = \explode('::', $controllerName);
                            if (isset($class, $method)) {
                                \DDTrace\trace_method($class, $method, function (SpanData $span) use($controllerName, $integration) {
                                    $span->name = 'symfony.controller';
                                    $span->resource = $controllerName;
                                    $span->type = Type::WEB_SERVLET;
                                    $span->service = $integration->appName;
                                });
                            }
                        } else {
                            \DDTrace\trace_function($controllerName, function (SpanData $span) use($controllerName, $integration) {
                                $span->name = 'symfony.controller';
                                $span->resource = $controllerName;
                                $span->type = Type::WEB_SERVLET;
                                $span->service = $integration->appName;
                            });
                        }
                    }
                }
            }
            $span->name = $span->resource = 'symfony.' . $eventName;
            $span->service = $integration->appName;
            if ($event === null) {
                return;
            }
            $integration->injectActionInfo($event, $eventName, $integration->symfonyRequestSpan);
        }));
        $exceptionHandlingTracer = function (SpanData $span, $args, $retval) use($integration) {
            $span->name = $span->resource = 'symfony.kernel.handleException';
            $span->service = $integration->appName;
            if (!(isset($retval) && \method_exists($retval, 'getStatusCode') && $retval->getStatusCode() < 500)) {
                $integration->symfonyRequestSpan->setError($args[0]);
            }
        };
        \DDTrace\trace_method('Symfony\\Component\\HttpKernel\\HttpKernel', 'handleException', $exceptionHandlingTracer);
        \DDTrace\trace_method('Symfony\\Component\\HttpKernel\\HttpKernel', 'handleThrowable', $exceptionHandlingTracer);
        $traceRender = function (SpanData $span, $args) use($integration) {
            $span->name = 'symfony.templating.render';
            $span->service = $integration->appName;
            $span->type = Type::WEB_SERVLET;
            $resourceName = count($args) > 0 ? get_class($this) . ' ' . $args[0] : get_class($this);
            $span->resource = $resourceName;
        };
        \DDTrace\trace_method('Symfony\\Bridge\\Twig\\TwigEngine', 'render', $traceRender);
        \DDTrace\trace_method('Symfony\\Bundle\\FrameworkBundle\\Templating\\TimedPhpEngine', 'render', $traceRender);
        \DDTrace\trace_method('Symfony\\Bundle\\TwigBundle\\TwigEngine', 'render', $traceRender);
        \DDTrace\trace_method('Symfony\\Component\\Templating\\DelegatingEngine', 'render', $traceRender);
        \DDTrace\trace_method('Symfony\\Component\\Templating\\PhpEngine', 'render', $traceRender);
        \DDTrace\trace_method('Twig\\Environment', 'render', $traceRender);
        \DDTrace\trace_method('Twig_Environment', 'render', $traceRender);
    }
    public function loadSymfony2($integration)
    {
        \DDTrace\trace_method('Symfony\\Component\\HttpKernel\\Event\\FilterControllerEvent', 'setController', function (SpanData $span, $args) use($integration) {
            list($controllerInfo) = $args;
            $resourceParts = array();
            if (is_string($controllerInfo)) {
                $resourceParts[] = $controllerInfo;
            } elseif (is_array($controllerInfo) && count($controllerInfo) === 2) {
                if (is_object($controllerInfo[0])) {
                    $resourceParts[] = get_class($controllerInfo[0]);
                } elseif (is_string($controllerInfo[0])) {
                    $resourceParts[] = $controllerInfo[0];
                }
                if (is_string($controllerInfo[1])) {
                    $resourceParts[] = $controllerInfo[1];
                }
            }
            if ($integration->symfonyRequestSpan) {
                if (count($resourceParts) > 0) {
                    $integration->symfonyRequestSpan->setResource(\implode(' ', $resourceParts));
                }
            }
            return false;
        });
    }
    public function injectActionInfo($event, $eventName, Span $requestSpan)
    {
        if (!\defined('\\Symfony\\Component\\HttpKernel\\KernelEvents::CONTROLLER') || $eventName !== KernelEvents::CONTROLLER || !method_exists($event, 'getController')) {
            return;
        }
        $controllerAndAction = $event->getController();
        if (!is_array($controllerAndAction) || count($controllerAndAction) !== 2 || !is_object($controllerAndAction[0])) {
            return;
        }
        $action = get_class($controllerAndAction[0]) . '@' . $controllerAndAction[1];
        $requestSpan->setTag('symfony.route.action', $action);
    }
}
}

namespace DDTrace\Integrations\ElasticSearch\V1 {
class ElasticSearchCommon
{
    public static function buildResourceName($methodName, $params)
    {
        if (!is_array($params)) {
            return $methodName;
        }
        $resourceFragments = array($methodName);
        $relevantParamNames = array('index', 'type');
        foreach ($relevantParamNames as $relevantParamName) {
            if (empty($params[$relevantParamName])) {
                continue;
            }
            $resourceFragments[] = $relevantParamName . ':' . $params[$relevantParamName];
        }
        return implode(' ', $resourceFragments);
    }
}
}

namespace DDTrace\Integrations\ElasticSearch\V1 {
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
class ElasticSearchIntegration extends Integration
{
    const NAME = 'elasticsearch';
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        $this->traceClientMethod('__construct');
        $this->traceClientMethod('count');
        $this->traceClientMethod('delete');
        $this->traceClientMethod('exists');
        $this->traceClientMethod('explain');
        $this->traceClientMethod('get', true);
        $this->traceClientMethod('index');
        $this->traceClientMethod('scroll');
        $this->traceClientMethod('search', true);
        $this->traceClientMethod('update');
        $this->traceSimpleMethod('Elasticsearch\\Serializers\\ArrayToJSONSerializer', 'serialize');
        $this->traceSimpleMethod('Elasticsearch\\Serializers\\ArrayToJSONSerializer', 'deserialize');
        $this->traceSimpleMethod('Elasticsearch\\Serializers\\EverythingToJSONSerializer', 'serialize');
        $this->traceSimpleMethod('Elasticsearch\\Serializers\\EverythingToJSONSerializer', 'deserialize');
        $this->traceSimpleMethod('Elasticsearch\\Serializers\\SmartSerializer', 'serialize');
        $this->traceSimpleMethod('Elasticsearch\\Serializers\\SmartSerializer', 'deserialize');
        $this->traceNamespaceMethod('IndicesNamespace', 'analyze');
        $this->traceNamespaceMethod('IndicesNamespace', 'clearCache');
        $this->traceNamespaceMethod('IndicesNamespace', 'close');
        $this->traceNamespaceMethod('IndicesNamespace', 'create');
        $this->traceNamespaceMethod('IndicesNamespace', 'delete');
        $this->traceNamespaceMethod('IndicesNamespace', 'deleteAlias');
        $this->traceNamespaceMethod('IndicesNamespace', 'deleteMapping');
        $this->traceNamespaceMethod('IndicesNamespace', 'deleteTemplate');
        $this->traceNamespaceMethod('IndicesNamespace', 'deleteWarmer');
        $this->traceNamespaceMethod('IndicesNamespace', 'exists');
        $this->traceNamespaceMethod('IndicesNamespace', 'existsAlias');
        $this->traceNamespaceMethod('IndicesNamespace', 'existsTemplate');
        $this->traceNamespaceMethod('IndicesNamespace', 'existsType');
        $this->traceNamespaceMethod('IndicesNamespace', 'flush');
        $this->traceNamespaceMethod('IndicesNamespace', 'getAlias');
        $this->traceNamespaceMethod('IndicesNamespace', 'getAliases');
        $this->traceNamespaceMethod('IndicesNamespace', 'getFieldMapping');
        $this->traceNamespaceMethod('IndicesNamespace', 'getMapping');
        $this->traceNamespaceMethod('IndicesNamespace', 'getSettings');
        $this->traceNamespaceMethod('IndicesNamespace', 'getTemplate');
        $this->traceNamespaceMethod('IndicesNamespace', 'getWarmer');
        $this->traceNamespaceMethod('IndicesNamespace', 'open');
        $this->traceNamespaceMethod('IndicesNamespace', 'optimize');
        $this->traceNamespaceMethod('IndicesNamespace', 'putAlias');
        $this->traceNamespaceMethod('IndicesNamespace', 'putMapping');
        $this->traceNamespaceMethod('IndicesNamespace', 'putSettings');
        $this->traceNamespaceMethod('IndicesNamespace', 'putTemplate');
        $this->traceNamespaceMethod('IndicesNamespace', 'putWarmer');
        $this->traceNamespaceMethod('IndicesNamespace', 'recovery');
        $this->traceNamespaceMethod('IndicesNamespace', 'refresh');
        $this->traceNamespaceMethod('IndicesNamespace', 'segments');
        $this->traceNamespaceMethod('IndicesNamespace', 'snapshotIndex');
        $this->traceNamespaceMethod('IndicesNamespace', 'stats');
        $this->traceNamespaceMethod('IndicesNamespace', 'status');
        $this->traceNamespaceMethod('IndicesNamespace', 'updateAliases');
        $this->traceNamespaceMethod('IndicesNamespace', 'validateQuery');
        $this->traceNamespaceMethod('CatNamespace', 'aliases');
        $this->traceNamespaceMethod('CatNamespace', 'allocation');
        $this->traceNamespaceMethod('CatNamespace', 'count');
        $this->traceNamespaceMethod('CatNamespace', 'fielddata');
        $this->traceNamespaceMethod('CatNamespace', 'health');
        $this->traceNamespaceMethod('CatNamespace', 'help');
        $this->traceNamespaceMethod('CatNamespace', 'indices');
        $this->traceNamespaceMethod('CatNamespace', 'master');
        $this->traceNamespaceMethod('CatNamespace', 'nodes');
        $this->traceNamespaceMethod('CatNamespace', 'pendingTasks');
        $this->traceNamespaceMethod('CatNamespace', 'recovery');
        $this->traceNamespaceMethod('CatNamespace', 'shards');
        $this->traceNamespaceMethod('CatNamespace', 'threadPool');
        $this->traceNamespaceMethod('SnapshotNamespace', 'create');
        $this->traceNamespaceMethod('SnapshotNamespace', 'createRepository');
        $this->traceNamespaceMethod('SnapshotNamespace', 'delete');
        $this->traceNamespaceMethod('SnapshotNamespace', 'deleteRepository');
        $this->traceNamespaceMethod('SnapshotNamespace', 'get');
        $this->traceNamespaceMethod('SnapshotNamespace', 'getRepository');
        $this->traceNamespaceMethod('SnapshotNamespace', 'restore');
        $this->traceNamespaceMethod('SnapshotNamespace', 'status');
        $this->traceNamespaceMethod('ClusterNamespace', 'getSettings');
        $this->traceNamespaceMethod('ClusterNamespace', 'health');
        $this->traceNamespaceMethod('ClusterNamespace', 'pendingTasks');
        $this->traceNamespaceMethod('ClusterNamespace', 'putSettings');
        $this->traceNamespaceMethod('ClusterNamespace', 'reroute');
        $this->traceNamespaceMethod('ClusterNamespace', 'state');
        $this->traceNamespaceMethod('ClusterNamespace', 'stats');
        $this->traceNamespaceMethod('NodesNamespace', 'hotThreads');
        $this->traceNamespaceMethod('NodesNamespace', 'info');
        $this->traceNamespaceMethod('NodesNamespace', 'shutdown');
        $this->traceNamespaceMethod('NodesNamespace', 'stats');
        \DDTrace\trace_method('Elasticsearch\\Endpoints\\AbstractEndpoint', 'performRequest', function (SpanData $span) {
            $span->name = 'Elasticsearch.Endpoint.performRequest';
            $span->resource = 'performRequest';
            $span->service = ElasticSearchIntegration::NAME;
            $span->type = Type::ELASTICSEARCH;
            try {
                $span->meta[Tag::ELASTICSEARCH_URL] = $this->getURI();
                $span->meta[Tag::ELASTICSEARCH_METHOD] = $this->getMethod();
                if (is_array($this->params)) {
                    $span->meta[Tag::ELASTICSEARCH_PARAMS] = json_encode($this->params);
                }
                if ($this->getMethod() === 'GET' && ($body = $this->getBody())) {
                    $span->meta[Tag::ELASTICSEARCH_BODY] = json_encode($body);
                }
            } catch (\Exception $ex) {
            }
        });
        return Integration::LOADED;
    }
    public function traceClientMethod($name, $isTraceAnalyticsCandidate = false)
    {
        $integration = $this;
        $class = 'Elasticsearch\\Client';
        $hookType = PHP_MAJOR_VERSION >= 7 ? 'prehook' : 'posthook';
        \DDTrace\trace_method($class, $name, array($hookType => function (SpanData $span, $args) use($name, $isTraceAnalyticsCandidate, $integration) {
            $span->name = "Elasticsearch.Client.{$name}";
            if ($isTraceAnalyticsCandidate) {
                $integration->addTraceAnalyticsIfEnabled($span);
            }
            $span->service = ElasticSearchIntegration::NAME;
            $span->type = Type::ELASTICSEARCH;
            $span->resource = ElasticSearchCommon::buildResourceName($name, isset($args[0]) ? $args[0] : array());
        }));
    }
    public function traceSimpleMethod($class, $name)
    {
        \DDTrace\trace_method($class, $name, function (SpanData $span) use($class, $name) {
            $operationName = str_replace('\\', '.', "{$class}.{$name}");
            $span->name = $operationName;
            $span->resource = $operationName;
            $span->service = ElasticSearchIntegration::NAME;
            $span->type = Type::ELASTICSEARCH;
        });
    }
    public function traceNamespaceMethod($namespace, $name)
    {
        $class = 'Elasticsearch\\Namespaces\\' . $namespace;
        \DDTrace\trace_method($class, $name, function (SpanData $span, $args) use($namespace, $name) {
            $params = array();
            if (isset($args[0])) {
                list($params) = $args;
            }
            $span->name = "Elasticsearch.{$namespace}.{$name}";
            $span->resource = ElasticSearchCommon::buildResourceName($name, $params);
            $span->service = ElasticSearchIntegration::NAME;
            $span->type = Type::ELASTICSEARCH;
        });
    }
}
}

namespace DDTrace\Integrations\Laravel {
use DDTrace\Contracts\Span;
use DDTrace\GlobalTracer;
use DDTrace\SpanData;
use DDTrace\Integrations\Integration;
use DDTrace\Tag;
use DDTrace\Type;
class LaravelIntegration extends Integration
{
    const NAME = 'laravel';
    private $serviceName;
    public function getName()
    {
        return self::NAME;
    }
    public function requiresExplicitTraceAnalyticsEnabling()
    {
        return false;
    }
    public function init()
    {
        if (!self::shouldLoad(self::NAME)) {
            return Integration::NOT_LOADED;
        }
        $rootScope = GlobalTracer::get()->getRootScope();
        $rootSpan = null;
        if (null === $rootScope || null === ($rootSpan = $rootScope->getSpan())) {
            return Integration::NOT_LOADED;
        }
        $integration = $this;
        \DDTrace\trace_method('Illuminate\\Foundation\\Application', 'handle', function (SpanData $span, $args, $response) use($rootSpan, $integration) {
            $rootSpan->overwriteOperationName('laravel.request');
            $integration->addTraceAnalyticsIfEnabledLegacy($rootSpan);
            if (\method_exists($response, 'getStatusCode')) {
                $rootSpan->setTag(Tag::HTTP_STATUS_CODE, $response->getStatusCode());
            }
            $rootSpan->setTag(Tag::SERVICE_NAME, $integration->getServiceName());
            $span->name = 'laravel.application.handle';
            $span->type = Type::WEB_SERVLET;
            $span->service = $integration->getServiceName();
            $span->resource = 'Illuminate\\Foundation\\Application@handle';
        });
        \DDTrace\trace_method('Illuminate\\Routing\\Router', 'findRoute', function (SpanData $span, $args, $route) use($rootSpan, $integration) {
            if (null === $route) {
                return false;
            }
            list($request) = $args;
            $integration->addTraceAnalyticsIfEnabledLegacy($rootSpan);
            $rootSpan->setTag(Tag::RESOURCE_NAME, $route->getActionName() . ' ' . ($route->getName() ?: 'unnamed_route'));
            $rootSpan->setTag('laravel.route.name', $route->getName());
            $rootSpan->setTag('laravel.route.action', $route->getActionName());
            $rootSpan->setTag('http.url', $request->url());
            $rootSpan->setTag('http.method', $request->method());
            return false;
        });
        \DDTrace\trace_method('Illuminate\\Routing\\Route', 'run', function (SpanData $span) use($integration) {
            $span->name = 'laravel.action';
            $span->type = Type::WEB_SERVLET;
            $span->service = $integration->getServiceName();
            $span->resource = $this->uri;
        });
        \DDTrace\trace_method('Symfony\\Component\\HttpFoundation\\Response', 'setStatusCode', function (SpanData $span, $args) use($rootSpan) {
            $rootSpan->setTag(Tag::HTTP_STATUS_CODE, $args[0]);
            return false;
        });
        \DDTrace\trace_method('Illuminate\\Events\\Dispatcher', 'fire', function (SpanData $span, $args) use($integration) {
            $span->name = 'laravel.event.handle';
            $span->type = Type::WEB_SERVLET;
            $span->service = $integration->getServiceName();
            $span->resource = $args[0];
        });
        \DDTrace\trace_method('Illuminate\\View\\View', 'render', function (SpanData $span) use($integration) {
            $span->name = 'laravel.view.render';
            $span->type = Type::WEB_SERVLET;
            $span->service = $integration->getServiceName();
            $span->resource = $this->view;
        });
        \DDTrace\trace_method('Illuminate\\View\\Engines\\CompilerEngine', 'get', function (SpanData $span, $args) use($integration, $rootSpan) {
            $span->name = $integration->isLumen($rootSpan) ? 'lumen.view' : 'laravel.view';
            $span->type = Type::WEB_SERVLET;
            $span->service = $integration->getServiceName();
            if (isset($args[0]) && \is_string($args[0])) {
                $span->resource = $args[0];
            }
        });
        \DDTrace\trace_method('Illuminate\\Foundation\\ProviderRepository', 'load', function (SpanData $span) use($rootSpan, $integration) {
            $serviceName = $integration->getServiceName();
            $span->name = 'laravel.provider.load';
            $span->type = Type::WEB_SERVLET;
            $span->service = $serviceName;
            $span->resource = 'Illuminate\\Foundation\\ProviderRepository::load';
            $rootSpan->overwriteOperationName('laravel.request');
            $rootSpan->setTag(Tag::SERVICE_NAME, $serviceName);
        });
        \DDTrace\trace_method('Illuminate\\Console\\Application', '__construct', function () use($rootSpan, $integration) {
            $rootSpan->overwriteOperationName('laravel.artisan');
            $rootSpan->setTag(Tag::RESOURCE_NAME, !empty($_SERVER['argv'][1]) ? 'artisan ' . $_SERVER['argv'][1] : 'artisan');
            return false;
        });
        \DDTrace\trace_method('Symfony\\Component\\Console\\Application', 'renderException', function (SpanData $span, $args) use($rootSpan) {
            $rootSpan->setError($args[0]);
            return false;
        });
        return Integration::LOADED;
    }
    public function getServiceName()
    {
        if (!empty($this->serviceName)) {
            return $this->serviceName;
        }
        $this->serviceName = \ddtrace_config_app_name();
        if (empty($this->serviceName) && is_callable('config')) {
            $this->serviceName = config('app.name');
        }
        return $this->serviceName ?: 'laravel';
    }
    public function isLumen(Span $rootSpan)
    {
        return $rootSpan->getOperationName() === 'lumen.request';
    }
}
}

namespace DDTrace\Integrations\Lumen {
use DDTrace\GlobalTracer;
use DDTrace\SpanData;
use DDTrace\Integrations\Integration;
use DDTrace\Tag;
class LumenIntegration extends Integration
{
    const NAME = 'lumen';
    public function getName()
    {
        return self::NAME;
    }
    public function requiresExplicitTraceAnalyticsEnabling()
    {
        return false;
    }
    public function init()
    {
        if (!self::shouldLoad(self::NAME)) {
            return Integration::NOT_LOADED;
        }
        $rootScope = GlobalTracer::get()->getRootScope();
        $rootSpan = null;
        if (null === $rootScope || null === ($rootSpan = $rootScope->getSpan())) {
            return Integration::NOT_LOADED;
        }
        $integration = $this;
        $appName = \ddtrace_config_app_name(self::NAME);
        \DDTrace\trace_method('Laravel\\Lumen\\Application', 'prepareRequest', function (SpanData $span, $args) use($rootSpan, $integration, $appName) {
            $request = $args[0];
            $rootSpan->overwriteOperationName('lumen.request');
            $rootSpan->setTag(Tag::SERVICE_NAME, $appName);
            $integration->addTraceAnalyticsIfEnabledLegacy($rootSpan);
            $rootSpan->setTag(Tag::HTTP_URL, $request->getUri());
            $rootSpan->setTag(Tag::HTTP_METHOD, $request->getMethod());
            return false;
        });
        $hook = 'posthook';
        \DDTrace\trace_method('Laravel\\Lumen\\Application', 'handleFoundRoute', array($hook => function (SpanData $span, $args) use($rootSpan, $appName) {
            $span->service = $appName;
            $span->type = 'web';
            if (count($args) < 1 || !\is_array($args[0])) {
                return;
            }
            $routeInfo = $args[0];
            $resourceName = null;
            if (isset($routeInfo[1]['uses'])) {
                $rootSpan->setTag('lumen.route.action', $routeInfo[1]['uses']);
                $resourceName = $routeInfo[1]['uses'];
            }
            if (isset($routeInfo[1]['as'])) {
                $rootSpan->setTag('lumen.route.name', $routeInfo[1]['as']);
                $resourceName = $routeInfo[1]['as'];
            }
            if (null !== $resourceName) {
                $rootSpan->setTag(Tag::RESOURCE_NAME, $rootSpan->getTag(Tag::HTTP_METHOD) . ' ' . $resourceName);
            }
        }));
        $exceptionRender = function (SpanData $span, $args) use($rootSpan, $appName) {
            $span->service = $appName;
            $span->type = 'web';
            if (count($args) < 1 || !\is_a($args[0], 'Throwable')) {
                return;
            }
            $exception = $args[0];
            $rootSpan->setError($exception);
        };
        \DDTrace\trace_method('Laravel\\Lumen\\Application', 'handleUncaughtException', array($hook => $exceptionRender));
        \DDTrace\trace_method('Laravel\\Lumen\\Application', 'sendExceptionToHandler', array($hook => $exceptionRender));
        return Integration::LOADED;
    }
}
}

namespace DDTrace\Integrations\Guzzle {
use DDTrace\Format;
use DDTrace\GlobalTracer;
use DDTrace\Http\Urls;
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
use GuzzleHttp;
class GuzzleIntegration extends Integration
{
    const NAME = 'guzzle';
    public function getName()
    {
        return self::NAME;
    }
    public function init()
    {
        if (!self::shouldLoad(self::NAME)) {
            return Integration::NOT_LOADED;
        }
        $tracer = GlobalTracer::get();
        $rootScope = $tracer->getRootScope();
        if (!$rootScope) {
            return Integration::NOT_LOADED;
        }
        $integration = $this;
        if (\PHP_VERSION_ID < 50500) {
            \DDTrace\hook_method('GuzzleHttp\\Client', '__construct', null, function (GuzzleHttp\Client $client, $s, $a) {
                if (!\method_exists($client, 'getEmitter')) {
                    return;
                }
                $emitter = $client->getEmitter();
                $emitter->once('before', function (GuzzleHttp\Event\EventInterface $event) {
                    if (!$event instanceof GuzzleHttp\Event\AbstractRequestEvent) {
                        return;
                    }
                    if (!\ddtrace_config_distributed_tracing_enabled()) {
                        return;
                    }
                    $request = $event->getRequest();
                    $headers = array();
                    \DDTrace\Bridge\inject_distributed_tracing_headers(Format::TEXT_MAP, $headers);
                    $request->addHeaders($headers);
                });
            });
        }
        \DDTrace\trace_method('GuzzleHttp\\Client', 'send', function (SpanData $span, $args, $retval) use($integration) {
            $span->resource = 'send';
            $span->name = 'GuzzleHttp\\Client.send';
            $span->service = 'guzzle';
            $span->type = Type::HTTP_CLIENT;
            if (isset($args[0])) {
                $integration->addRequestInfo($span, $args[0]);
            }
            if (isset($retval)) {
                $response = $retval;
                if (\is_a($response, 'GuzzleHttp\\Message\\ResponseInterface')) {
                    $span->meta[Tag::HTTP_STATUS_CODE] = $response->getStatusCode();
                } elseif (\is_a($response, 'Psr\\Http\\Message\\ResponseInterface')) {
                    $span->meta[Tag::HTTP_STATUS_CODE] = $response->getStatusCode();
                } elseif (\is_a($response, 'GuzzleHttp\\Promise\\PromiseInterface')) {
                    $response->then(function (\Psr\Http\Message\ResponseInterface $response) use($span) {
                        $span->meta[Tag::HTTP_STATUS_CODE] = $response->getStatusCode();
                    });
                }
            }
        });
        \DDTrace\trace_method('GuzzleHttp\\Client', 'transfer', function (SpanData $span, $args, $retval) use($integration) {
            $span->resource = 'transfer';
            $span->name = 'GuzzleHttp\\Client.transfer';
            $span->service = 'guzzle';
            $span->type = Type::HTTP_CLIENT;
            if (isset($args[0])) {
                $integration->addRequestInfo($span, $args[0]);
            }
            if (isset($retval)) {
                $response = $retval;
                if (\is_a($response, 'GuzzleHttp\\Promise\\PromiseInterface')) {
                    $response->then(function (\Psr\Http\Message\ResponseInterface $response) use($span) {
                        $span->meta[Tag::HTTP_STATUS_CODE] = $response->getStatusCode();
                    });
                }
            }
        });
        return Integration::LOADED;
    }
    public function addRequestInfo(SpanData $span, $request)
    {
        if (\is_a($request, 'Psr\\Http\\Message\\RequestInterface')) {
            $url = $request->getUri();
            if (\ddtrace_config_http_client_split_by_domain_enabled()) {
                $span->service = Urls::hostnameForTag($url);
            }
            $span->meta[Tag::HTTP_METHOD] = $request->getMethod();
            $span->meta[Tag::HTTP_URL] = Urls::sanitize($url);
        } elseif (\is_a($request, 'GuzzleHttp\\Message\\RequestInterface')) {
            $url = $request->getUrl();
            if (\ddtrace_config_http_client_split_by_domain_enabled()) {
                $span->service = Urls::hostnameForTag($url);
            }
            $span->meta[Tag::HTTP_METHOD] = $request->getMethod();
            $span->meta[Tag::HTTP_URL] = Urls::sanitize($url);
        }
    }
}
}

namespace DDTrace\Integrations\Yii {
use DDTrace\Contracts\Scope;
use DDTrace\GlobalTracer;
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
use DDTrace\Util\Versions;
use yii\helpers\Url;
class YiiIntegration extends Integration
{
    const NAME = 'yii';
    public function getName()
    {
        return self::NAME;
    }
    public function requiresExplicitTraceAnalyticsEnabling()
    {
        return false;
    }
    public function init()
    {
        if (!self::shouldLoad(self::NAME)) {
            return self::NOT_AVAILABLE;
        }
        $integration = $this;
        \DDTrace\hook_method('yii\\di\\Container', '__construct', null, function () use($integration) {
            if (Versions::versionMatches('2.0', \Yii::getVersion())) {
                $integration->loadV2();
            }
        });
        return self::LOADED;
    }
    public function loadV2()
    {
        $scope = GlobalTracer::get()->getRootScope();
        if (!$scope instanceof Scope) {
            return;
        }
        $root = $scope->getSpan();
        $this->addTraceAnalyticsIfEnabledLegacy($root);
        $service = \ddtrace_config_app_name(YiiIntegration::NAME);
        \DDTrace\trace_method('yii\\web\\Application', 'run', function (SpanData $span) use($service) {
            $span->name = $span->resource = \get_class($this) . '.run';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        $firstController = null;
        \DDTrace\hook_method('yii\\web\\Application', 'createController', null, function ($app, $appClass, $args, $retval) use(&$firstController) {
            if ($firstController === null && isset($args[0], $retval) && \is_array($retval) && !empty($retval)) {
                $firstController = $retval[0];
            }
        });
        \DDTrace\trace_method('yii\\base\\Module', 'runAction', function (SpanData $span, $args) use($service) {
            $span->name = \get_class($this) . '.runAction';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
            $span->resource = isset($args[0]) && \is_string($args[0]) ? $args[0] : $span->name;
        });
        \DDTrace\trace_method('yii\\base\\Controller', 'runAction', function (SpanData $span, $args) use(&$firstController, $service, $root) {
            $span->name = \get_class($this) . '.runAction';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
            $span->resource = isset($args[0]) && \is_string($args[0]) ? $args[0] : $span->name;
            if ($firstController === $this && $root->getTag('app.endpoint') === null && isset($this->action->actionMethod)) {
                $controller = \get_class($this);
                $endpoint = "{$controller}::{$this->action->actionMethod}";
                $root->setTag('app.endpoint', $endpoint);
                $root->setTag(Tag::HTTP_URL, Url::base(true) . Url::current());
            }
            if ($root->getTag('app.route.path') === null) {
                $route = $this->module->requestedRoute;
                $namedParams = array($route);
                $placeholders = array($route);
                if (isset($args[1]) && \is_array($args[1]) && !empty($args[1])) {
                    foreach ($args[1] as $param => $unused) {
                        $namedParams[$param] = ":{$param}";
                        $placeholders[$param] = '?';
                    }
                }
                $routePath = \urldecode(Url::toRoute($namedParams));
                $root->setTag('app.route.path', $routePath);
                $resourceName = \urldecode(Url::toRoute($placeholders));
                $root->setTag(Tag::RESOURCE_NAME, "{$_SERVER['REQUEST_METHOD']} {$resourceName}", true);
            }
        });
        \DDTrace\trace_method('yii\\base\\View', 'renderFile', function (SpanData $span, $args) use($service) {
            $span->name = \get_class($this) . '.renderFile';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
            $span->resource = isset($args[0]) && \is_string($args[0]) ? $args[0] : $span->name;
        });
    }
}
}

namespace DDTrace\Integrations\WordPress {
use DDTrace\Integrations\Integration;
use DDTrace\Integrations\WordPress\V4\WordPressIntegrationLoader;
class WordPressIntegration extends Integration
{
    const NAME = 'wordpress';
    public function getName()
    {
        return self::NAME;
    }
    public function requiresExplicitTraceAnalyticsEnabling()
    {
        return false;
    }
    public function init()
    {
        if (!self::shouldLoad(self::NAME)) {
            return self::NOT_AVAILABLE;
        }
        $integration = $this;
        \DDTrace\hook_method('Requests', 'set_certificate_path', null, function () use($integration) {
            if (!isset($GLOBALS['wp_version']) || !is_string($GLOBALS['wp_version'])) {
                return false;
            }
            $majorVersion = substr($GLOBALS['wp_version'], 0, 2);
            if ('4.' === $majorVersion || '5.' === $majorVersion && PHP_VERSION_ID >= 70000) {
                $loader = new WordPressIntegrationLoader();
                $loader->load($integration);
            }
        });
        return self::LOADED;
    }
}
}

namespace DDTrace\Integrations\WordPress\V4 {
use DDTrace\Contracts\Scope;
use DDTrace\GlobalTracer;
use DDTrace\Http\Urls;
use DDTrace\Integrations\WordPress\WordPressIntegration;
use DDTrace\Integrations\Integration;
use DDTrace\Contracts\Span;
use DDTrace\SpanData;
use DDTrace\Tag;
use DDTrace\Type;
class WordPressIntegrationLoader
{
    public $rootSpan;
    public function load(WordPressIntegration $integration)
    {
        $scope = GlobalTracer::get()->getRootScope();
        if (!$scope instanceof Scope) {
            return Integration::NOT_LOADED;
        }
        $this->rootSpan = $scope->getSpan();
        $integration->addTraceAnalyticsIfEnabledLegacy($this->rootSpan);
        $this->rootSpan->overwriteOperationName('wordpress.request');
        $service = \ddtrace_config_app_name(WordPressIntegration::NAME);
        $this->rootSpan->setTag(Tag::SERVICE_NAME, $service);
        if ('cli' !== PHP_SAPI) {
            $normalizedPath = \DDtrace\Private_\util_uri_normalize_incoming_path($_SERVER['REQUEST_URI']);
            $this->rootSpan->setTag(Tag::RESOURCE_NAME, $_SERVER['REQUEST_METHOD'] . ' ' . $normalizedPath, true);
            $this->rootSpan->setTag(Tag::HTTP_URL, home_url(add_query_arg($_GET)));
        }
        \DDTrace\trace_method('WP', 'main', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'WP.main';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_method('WP', 'init', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'WP.init';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_method('WP', 'parse_request', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'WP.parse_request';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_method('WP', 'send_headers', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'WP.send_headers';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_method('WP', 'query_posts', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'WP.query_posts';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_method('WP', 'handle_404', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'WP.handle_404';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_method('WP', 'register_globals', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'WP.register_globals';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('create_initial_post_types', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'create_initial_post_types';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('create_initial_taxonomies', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'create_initial_taxonomies';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('wp_print_head_scripts', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'wp_print_head_scripts';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('wp_print_footer_scripts', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'wp_print_footer_scripts';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('wp_maybe_load_widgets', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'wp_maybe_load_widgets';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('wp_maybe_load_embeds', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'wp_maybe_load_embeds';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('_wp_customize_include', function (SpanData $span) use($service) {
            $span->name = $span->resource = '_wp_customize_include';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_method('WP_Widget_Factory', '_register_widgets', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'WP_Widget_Factory._register_widgets';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_method('WP_Widget', 'display_callback', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'WP_Widget.display_callback';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_method('wpdb', '__construct', function (SpanData $span, array $args) use($service) {
            $span->name = $span->resource = 'wpdb.__construct';
            $span->type = Type::SQL;
            $span->service = $service;
            $span->meta = array('db.user' => $args[0], 'db.name' => $args[2], 'db.host' => $args[3]);
        });
        \DDTrace\trace_method('wpdb', 'query', function (SpanData $span, array $args) use($service) {
            $span->name = 'wpdb.query';
            $span->resource = $args[0];
            $span->type = Type::SQL;
            $span->service = $service;
        });
        \DDTrace\trace_function('get_header', function (SpanData $span, array $args) use($service) {
            $span->name = 'get_header';
            $span->resource = !empty($args[0]) ? $args[0] : $span->name;
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('wp_head', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'wp_head';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('the_custom_header_markup', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'the_custom_header_markup';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('body_class', function (SpanData $span) use($service) {
            $span->name = $span->resource = 'body_class';
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('load_template', function (SpanData $span, array $args) use($service) {
            $span->name = 'load_template';
            $span->resource = !empty($args[0]) ? $args[0] : $span->name;
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('comments_template', function (SpanData $span, array $args) use($service) {
            $span->name = 'comments_template';
            $span->resource = !empty($args[0]) ? $args[0] : $span->name;
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('get_sidebar', function (SpanData $span, array $args) use($service) {
            $span->name = 'get_sidebar';
            $span->resource = !empty($args[0]) ? $args[0] : $span->name;
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('dynamic_sidebar', function (SpanData $span, array $args) use($service) {
            $span->name = 'dynamic_sidebar';
            $span->resource = !empty($args[0]) ? $args[0] : $span->name;
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        \DDTrace\trace_function('get_footer', function (SpanData $span, array $args) use($service) {
            $span->name = 'get_footer';
            $span->resource = !empty($args[0]) ? $args[0] : $span->name;
            $span->type = Type::WEB_SERVLET;
            $span->service = $service;
        });
        return Integration::LOADED;
    }
}
}

namespace DDTrace\Integrations\ZendFramework {
use DDTrace\GlobalTracer;
use DDTrace\Tag;
use DDTrace\Integrations\Integration;
use DDTrace\SpanData;
use DDTrace\Util\Runtime;
use Zend_Controller_Front;
class ZendFrameworkIntegration extends Integration
{
    const NAME = 'zendframework';
    public function getName()
    {
        return self::NAME;
    }
    public function requiresExplicitTraceAnalyticsEnabling()
    {
        return false;
    }
    public function init()
    {
        if (!self::shouldLoad(self::NAME)) {
            return self::NOT_AVAILABLE;
        }
        if (Runtime::isAutoloaderRegistered('YiiBase', 'autoload')) {
            return self::NOT_AVAILABLE;
        }
        $integration = $this;
        $appName = \ddtrace_config_app_name('zf1');
        \DDTrace\trace_method('Zend_Controller_Plugin_Broker', 'preDispatch', function (SpanData $spanData, $args) use($integration, $appName) {
            $rootScope = GlobalTracer::get()->getRootScope();
            if (null === $rootScope) {
                return false;
            }
            $rootSpan = $rootScope->getSpan();
            if (null === $rootSpan) {
                return false;
            }
            try {
                list($request) = $args;
                $integration->addTraceAnalyticsIfEnabledLegacy($rootSpan);
                $rootSpan->overwriteOperationName($integration->getOperationName());
                $rootSpan->setTag(Tag::SERVICE_NAME, $appName);
                $controller = $request->getControllerName();
                $action = $request->getActionName();
                $route = Zend_Controller_Front::getInstance()->getRouter()->getCurrentRouteName();
                $rootSpan->setTag('zf1.controller', $controller);
                $rootSpan->setTag('zf1.action', $action);
                $rootSpan->setTag('zf1.route_name', $route);
                $rootSpan->setResource($controller . '@' . $action . ' ' . $route);
                $rootSpan->setTag(Tag::HTTP_METHOD, $request->getMethod());
                $rootSpan->setTag(Tag::HTTP_URL, $request->getScheme() . '://' . $request->getHttpHost() . $request->getRequestUri());
            } catch (\Exception $e) {
            }
            return false;
        });
        \DDTrace\trace_method('Zend_Controller_Plugin_Broker', 'postDispatch', function () {
            $rootScope = GlobalTracer::get()->getRootScope();
            if (null === $rootScope || null === ($rootSpan = $rootScope->getSpan())) {
                return false;
            }
            try {
                $rootSpan->setTag(Tag::HTTP_STATUS_CODE, $this->getResponse()->getHttpResponseCode());
            } catch (\Exception $e) {
            }
            return false;
        });
        return Integration::LOADED;
    }
    public static function getOperationName()
    {
        $contextName = 'cli' === PHP_SAPI ? 'command' : 'request';
        return 'zf1' . '.' . $contextName;
    }
}
}

namespace DDTrace\Log {
final class Logger
{
    private static $logger;
    public static function set(LoggerInterface $logger)
    {
        self::$logger = $logger;
    }
    public static function get()
    {
        if (self::$logger === null) {
            self::$logger = \ddtrace_config_debug_enabled() ? new ErrorLogLogger(LogLevel::DEBUG) : new NullLogger(LogLevel::EMERGENCY);
        }
        return self::$logger;
    }
    public static function reset()
    {
        self::$logger = null;
    }
}
}

namespace DDTrace\Log {
interface LoggerInterface
{
    public function debug($message, array $context = array());
    public function warning($message, array $context = array());
    public function error($message, array $context = array());
    public function isLevelActive($level);
}
}

namespace DDTrace\Log {
trait InterpolateTrait
{
    public function interpolate($message, array $context = array())
    {
        $replace = array();
        foreach ($context as $key => $val) {
            if (!is_array($val) && (!is_object($val) || method_exists($val, '__toString'))) {
                $replace['{' . $key . '}'] = $val;
            }
        }
        return strtr($message, $replace);
    }
}
}

namespace DDTrace\Log {
final class LogLevel
{
    const EMERGENCY = 'emergency';
    const ALERT = 'alert';
    const CRITICAL = 'critical';
    const ERROR = 'error';
    const WARNING = 'warning';
    const NOTICE = 'notice';
    const INFO = 'info';
    const DEBUG = 'debug';
    public static function all()
    {
        return array(self::EMERGENCY, self::ALERT, self::CRITICAL, self::ERROR, self::WARNING, self::NOTICE, self::INFO, self::DEBUG);
    }
}
}

namespace DDTrace\Log {
abstract class AbstractLogger implements LoggerInterface
{
    private $enabledLevels = array();
    public function __construct($level)
    {
        $level = trim(strtolower($level));
        $enabled = false;
        foreach (array_reverse(LogLevel::all()) as $knownLevel) {
            $enabled = $enabled || $level === $knownLevel;
            $this->enabledLevels[$knownLevel] = $enabled;
        }
    }
    public function isLevelActive($level)
    {
        return (bool) $this->enabledLevels[$level];
    }
}
}

namespace DDTrace\Log {
class ErrorLogLogger extends AbstractLogger
{
    use InterpolateTrait;
    public function debug($message, array $context = array())
    {
        $this->emit(LogLevel::DEBUG, $message, $context);
    }
    public function warning($message, array $context = array())
    {
        $this->emit(LogLevel::WARNING, $message, $context);
    }
    public function error($message, array $context = array())
    {
        $this->emit(LogLevel::ERROR, $message, $context);
    }
    private function emit($level, $message, array $context = array())
    {
        if (!$this->isLevelActive($level)) {
            return;
        }
        $interpolatedMessage = $this->interpolate($message, $context);
        $date = date(\DateTime::ATOM);
        error_log("[{$date}] [ddtrace] [{$level}] - {$interpolatedMessage}");
    }
}
}

namespace DDTrace {
final class Obfuscation
{
    const REPLACEMENT = '?';
    const DEFAULT_GLUE = ' ';
    public static function toObfuscatedString($keys, $glue = self::DEFAULT_GLUE)
    {
        if (!is_array($keys)) {
            return self::REPLACEMENT;
        }
        $obfuscatedKeys = str_repeat(self::REPLACEMENT . $glue, count($keys));
        return rtrim($obfuscatedKeys, $glue);
    }
    public static function dsn($dsn)
    {
        if (false === strpos($dsn, '@')) {
            return $dsn;
        }
        return preg_replace('/\\/\\/.+@/', '//' . self::REPLACEMENT . ':' . self::REPLACEMENT . '@', $dsn);
    }
}
}

namespace DDTrace {
class Format
{
    const BINARY = 'binary';
    const TEXT_MAP = 'text_map';
    const HTTP_HEADERS = 'http_headers';
    const CURL_HTTP_HEADERS = 'curl_http_headers';
}
}

namespace DDTrace {
use DDTrace\Contracts\ScopeManager as ScopeManagerInterface;
use DDTrace\Contracts\Span as SpanInterface;
use DDTrace\Contracts\SpanContext as SpanContextInterface;
use DDTrace\Exceptions\InvalidReferencesSet;
use DDTrace\Exceptions\InvalidSpanOption;
final class StartSpanOptions
{
    private $references = array();
    private $tags = array();
    private $startTime;
    private $finishSpanOnClose = ScopeManagerInterface::DEFAULT_FINISH_SPAN_ON_CLOSE;
    private $ignoreActiveSpan = false;
    public static function create(array $options)
    {
        $spanOptions = new self();
        foreach ($options as $key => $value) {
            switch ($key) {
                case 'child_of':
                    if (!empty($spanOptions->references)) {
                        throw InvalidSpanOption::forIncludingBothChildOfAndReferences();
                    }
                    $spanOptions->references[] = self::buildChildOf($value);
                    break;
                case 'references':
                    if (!empty($spanOptions->references)) {
                        throw InvalidSpanOption::forIncludingBothChildOfAndReferences();
                    }
                    if ($value instanceof Reference) {
                        $spanOptions->references = array($value);
                    } elseif (is_array($value)) {
                        $spanOptions->references = self::buildReferences($value);
                    } else {
                        throw InvalidSpanOption::forInvalidReferenceSet($value);
                    }
                    break;
                case 'tags':
                    if (!is_array($value)) {
                        throw InvalidSpanOption::forInvalidTags($value);
                    }
                    foreach ($value as $tag => $tagValue) {
                        if ($tag !== (string) $tag) {
                            throw InvalidSpanOption::forInvalidTag($tag);
                        }
                        $spanOptions->tags[$tag] = $tagValue;
                    }
                    break;
                case 'start_time':
                    if (is_scalar($value) && !is_numeric($value)) {
                        throw InvalidSpanOption::forInvalidStartTime();
                    }
                    $spanOptions->startTime = $value;
                    break;
                case 'finish_span_on_close':
                    if (!is_bool($value)) {
                        throw InvalidSpanOption::forFinishSpanOnClose($value);
                    }
                    $spanOptions->finishSpanOnClose = $value;
                    break;
                case 'ignore_active_span':
                    if (!is_bool($value)) {
                        throw InvalidSpanOption::forIgnoreActiveSpan($value);
                    }
                    $spanOptions->ignoreActiveSpan = $value;
                    break;
                default:
                    throw InvalidSpanOption::forUnknownOption($key);
                    break;
            }
        }
        return $spanOptions;
    }
    public function withParent($parent)
    {
        $newSpanOptions = new StartSpanOptions();
        $newSpanOptions->references[] = self::buildChildOf($parent);
        $newSpanOptions->tags = $this->tags;
        $newSpanOptions->startTime = $this->startTime;
        $newSpanOptions->finishSpanOnClose = $this->finishSpanOnClose;
        $newSpanOptions->ignoreActiveSpan = $this->ignoreActiveSpan;
        return $newSpanOptions;
    }
    public function getReferences()
    {
        return $this->references;
    }
    public function getTags()
    {
        return $this->tags;
    }
    public function getStartTime()
    {
        return $this->startTime;
    }
    public function shouldFinishSpanOnClose()
    {
        return $this->finishSpanOnClose;
    }
    public function shouldIgnoreActiveSpan()
    {
        return $this->ignoreActiveSpan;
    }
    private static function buildChildOf($value)
    {
        if ($value instanceof SpanInterface) {
            return Reference::create(Reference::CHILD_OF, $value->getContext());
        }
        if ($value instanceof SpanContextInterface) {
            return Reference::create(Reference::CHILD_OF, $value);
        }
        if ($value instanceof \DDTrace\OpenTracer\SpanContext) {
            return Reference::create(Reference::CHILD_OF, $value->unwrapped());
        }
        throw InvalidSpanOption::forInvalidChildOf($value);
    }
    private static function buildReferences(array $referencesArray)
    {
        $references = array();
        foreach ($referencesArray as $reference) {
            if (!$reference instanceof Reference) {
                throw InvalidSpanOption::forInvalidReference($reference);
            }
            $references[] = $reference;
        }
        return $references;
    }
}
}

