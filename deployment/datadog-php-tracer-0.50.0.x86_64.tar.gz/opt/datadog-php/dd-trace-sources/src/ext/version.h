#ifndef PHP_DDTRACE_VERSION
// Must begin with a number for Debian packaging requirements
#define PHP_DDTRACE_VERSION "0.50.0"
#endif
