#ifndef DD_TRACE_SIGNALS_H
#define DD_TRACE_SIGNALS_H

#include "compatibility.h"

void ddtrace_signals_minit(TSRMLS_D);
void ddtrace_signals_mshutdown(void);

#endif  // DD_TRACE_SIGNALS_H
