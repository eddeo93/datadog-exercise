#include "auto_flush.h"

ZEND_RESULT_CODE ddtrace_flush_tracer(void) { return SUCCESS; }
