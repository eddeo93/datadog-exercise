#include "auto_flush.h"

int ddtrace_flush_tracer(void) { return SUCCESS; }
