#include "distributed_tracing.h"

#include "compatibility.h"

void ddtrace_distributed_tracing_rinit(TSRMLS_D) {}

void ddtrace_distributed_tracing_rshutdown(TSRMLS_D) {}
