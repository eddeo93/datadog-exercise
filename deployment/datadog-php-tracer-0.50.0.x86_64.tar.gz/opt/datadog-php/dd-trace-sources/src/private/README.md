**NOTICE**: this package is intended for internal usage. Api is unstable and can vary without any further notice so
users are not encouraged to use functions from this package for their own custom code.
