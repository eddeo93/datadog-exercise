# Datadog PHP OpenTracing Support

This page has been moved to the [OpenTracing documentation](https://docs.datadoghq.com/tracing/opentracing/php/).
